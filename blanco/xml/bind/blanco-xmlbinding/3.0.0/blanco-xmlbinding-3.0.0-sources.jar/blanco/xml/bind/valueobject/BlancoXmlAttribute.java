package blanco.xml.bind.valueobject;

/**
 * SAXイベントのうち 要素(Element)のなかの 属性(Attribute)を記憶します。このクラスは XML/バリューオブジェクトマッピング (X/Oマッピング) blancoXmlBinding の一部です。
 */
public class BlancoXmlAttribute {
    /**
     * 属性の名前空間URI。
     *
     * フィールド: [uri]。
     */
    private String fUri;

    /**
     * 属性のローカル名。
     *
     * フィールド: [localName]。
     */
    private String fLocalName;

    /**
     * 属性の XML 1.0 修飾名。
     *
     * フィールド: [qName]。
     */
    private String fQName;

    /**
     * 属性の型。&quot;CDATA&quot;, &quot;ID&quot;, &quot;IDREF&quot;, &quot;IDREFS&quot;, &quot;NMTOKEN&quot;, &quot;NMTOKENS&quot;, &quot;ENTITY&quot;, &quot;ENTITIES&quot;, &quot;NOTATION&quot; が格納されます。
     *
     * フィールド: [type]。
     */
    private String fType;

    /**
     * 属性の値。
     *
     * フィールド: [value]。
     */
    private String fValue;

    /**
     * フィールド [uri] の値を設定します。
     *
     * フィールドの説明: [属性の名前空間URI。]。
     *
     * @param argUri フィールド[uri]に設定する値。
     */
    public void setUri(final String argUri) {
        fUri = argUri;
    }

    /**
     * フィールド [uri] の値を取得します。
     *
     * フィールドの説明: [属性の名前空間URI。]。
     *
     * @return フィールド[uri]から取得した値。
     */
    public String getUri() {
        return fUri;
    }

    /**
     * フィールド [localName] の値を設定します。
     *
     * フィールドの説明: [属性のローカル名。]。
     *
     * @param argLocalName フィールド[localName]に設定する値。
     */
    public void setLocalName(final String argLocalName) {
        fLocalName = argLocalName;
    }

    /**
     * フィールド [localName] の値を取得します。
     *
     * フィールドの説明: [属性のローカル名。]。
     *
     * @return フィールド[localName]から取得した値。
     */
    public String getLocalName() {
        return fLocalName;
    }

    /**
     * フィールド [qName] の値を設定します。
     *
     * フィールドの説明: [属性の XML 1.0 修飾名。]。
     *
     * @param argQName フィールド[qName]に設定する値。
     */
    public void setQName(final String argQName) {
        fQName = argQName;
    }

    /**
     * フィールド [qName] の値を取得します。
     *
     * フィールドの説明: [属性の XML 1.0 修飾名。]。
     *
     * @return フィールド[qName]から取得した値。
     */
    public String getQName() {
        return fQName;
    }

    /**
     * フィールド [type] の値を設定します。
     *
     * フィールドの説明: [属性の型。"CDATA", "ID", "IDREF", "IDREFS", "NMTOKEN", "NMTOKENS", "ENTITY", "ENTITIES", "NOTATION" が格納されます。]。
     *
     * @param argType フィールド[type]に設定する値。
     */
    public void setType(final String argType) {
        fType = argType;
    }

    /**
     * フィールド [type] の値を取得します。
     *
     * フィールドの説明: [属性の型。"CDATA", "ID", "IDREF", "IDREFS", "NMTOKEN", "NMTOKENS", "ENTITY", "ENTITIES", "NOTATION" が格納されます。]。
     *
     * @return フィールド[type]から取得した値。
     */
    public String getType() {
        return fType;
    }

    /**
     * フィールド [value] の値を設定します。
     *
     * フィールドの説明: [属性の値。]。
     *
     * @param argValue フィールド[value]に設定する値。
     */
    public void setValue(final String argValue) {
        fValue = argValue;
    }

    /**
     * フィールド [value] の値を取得します。
     *
     * フィールドの説明: [属性の値。]。
     *
     * @return フィールド[value]から取得した値。
     */
    public String getValue() {
        return fValue;
    }

    /**
     * Gets the string representation of this value object.
     *
     * <P>Precautions for use</P>
     * <UL>
     * <LI>Only the shallow range of the object will be subject to the stringification process.
     * <LI>Do not use this method if the object has a circular reference.
     * </UL>
     *
     * @return String representation of a value object.
     */
    @Override
    public String toString() {
        final StringBuffer buf = new StringBuffer();
        buf.append("blanco.xml.bind.valueobject.BlancoXmlAttribute[");
        buf.append("uri=" + fUri);
        buf.append(",localName=" + fLocalName);
        buf.append(",qName=" + fQName);
        buf.append(",type=" + fType);
        buf.append(",value=" + fValue);
        buf.append("]");
        return buf.toString();
    }

    /**
     * Copies this value object to the specified target.
     *
     * <P>Cautions for use</P>
     * <UL>
     * <LI>Only the shallow range of the object will be subject to the copying process.
     * <LI>Do not use this method if the object has a circular reference.
     * </UL>
     *
     * @param target target value object.
     */
    public void copyTo(final BlancoXmlAttribute target) {
        if (target == null) {
            throw new IllegalArgumentException("Bug: BlancoXmlAttribute#copyTo(target): argument 'target' is null");
        }

        // No needs to copy parent class.

        // Name: fUri
        // Type: java.lang.String
        target.fUri = this.fUri;
        // Name: fLocalName
        // Type: java.lang.String
        target.fLocalName = this.fLocalName;
        // Name: fQName
        // Type: java.lang.String
        target.fQName = this.fQName;
        // Name: fType
        // Type: java.lang.String
        target.fType = this.fType;
        // Name: fValue
        // Type: java.lang.String
        target.fValue = this.fValue;
    }
}
