/*
 * blanco Framework
 * Copyright (C) 2004-2009 IGA Tosiki
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 */
/*******************************************************************************
 * Copyright (c) 2009 IGA Tosiki, NTT DATA BUSINESS BRAINS Corp.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    IGA Tosiki (NTT DATA BUSINESS BRAINS Corp.) - initial API and implementation
 *******************************************************************************/
package blanco.xml.bind;

import java.util.ArrayList;
import java.util.List;

import blanco.xml.bind.valueobject.BlancoXmlAttribute;
import blanco.xml.bind.valueobject.BlancoXmlCdata;
import blanco.xml.bind.valueobject.BlancoXmlCharacters;
import blanco.xml.bind.valueobject.BlancoXmlDocument;
import blanco.xml.bind.valueobject.BlancoXmlElement;
import blanco.xml.bind.valueobject.BlancoXmlNode;

/**
 * This is a manipulation support utility for the value object representation of blancoXmlBinding.
 * 
 * @author IGA Tosiki
 */
public class BlancoXmlBindingUtil {
    /**
     * This class is not instantiated.
     */
    protected BlancoXmlBindingUtil() {
    }

    /**
     * Gets an element from the given document.
     * 
     * Returns the element found first.
     * 
     * @param argDocument
     *            A document to be searched.
     * @return The (first) element found. Returns null if the element is not found.
     */
    public static final BlancoXmlElement getDocumentElement(
            final BlancoXmlDocument argDocument) {
        final List<blanco.xml.bind.valueobject.BlancoXmlNode> listRoot = argDocument
                .getChildNodes();
        for (int index = 0; index < listRoot.size(); index++) {
            final BlancoXmlNode objLook = listRoot.get(index);
            if (objLook instanceof BlancoXmlElement == false) {
                continue;
            }
            return (BlancoXmlElement) objLook;
        }

        // Couldn't find any elements.
        return null;
    }

    /**
     * Gets an element from the child node of the given element.
     * 
     * Returns all elements that match the search.
     * 
     * @param argElement
     *            An element to be searched for.
     * @param argTagname
     *            The tag name to search for. (local name)
     * @return A list of found elements. Returns an empty list if no element is found.
     */
    public static final List<blanco.xml.bind.valueobject.BlancoXmlElement> getElementsByTagName(
            final BlancoXmlElement argElement, final String argTagname) {
        if (argElement == null) {
            throw new IllegalArgumentException(
                    "BlancoXmlBindingUtil.getElementsByTagName: The argument (element) was given as null.");
        }

        final List<blanco.xml.bind.valueobject.BlancoXmlElement> listResult = new ArrayList<blanco.xml.bind.valueobject.BlancoXmlElement>();

        final List<blanco.xml.bind.valueobject.BlancoXmlNode> listChild = argElement
                .getChildNodes();
        for (int index = 0; index < listChild.size(); index++) {
            final BlancoXmlNode objLook = listChild.get(index);
            if (objLook instanceof BlancoXmlElement == false) {
                continue;
            }

            final BlancoXmlElement elementLook = (BlancoXmlElement) objLook;
            if (elementLook.getLocalName().equals(argTagname)) {
                listResult.add((BlancoXmlElement) objLook);
            }
        }

        return listResult;
    }

    /**
     * Gets an element from the child node of the given element.
     * 
     * Returns the element found first. The second and subsequent are ignored if more than one element matches.
     * 
     * @param argElement
     *            An element to be searched for.
     * @param argTagname
     *            The tag name to search for. (local name)
     * @return The element found first. Returns null if the element is not found.
     */
    public static final BlancoXmlElement getElement(
            final BlancoXmlElement argElement, final String argTagname) {
        final List<blanco.xml.bind.valueobject.BlancoXmlNode> listChild = argElement
                .getChildNodes();
        for (int index = 0; index < listChild.size(); index++) {
            final BlancoXmlNode objLook = listChild.get(index);
            if (objLook instanceof BlancoXmlElement == false) {
                continue;
            }

            final BlancoXmlElement elementLook = (BlancoXmlElement) objLook;
            if (elementLook.getLocalName().equals(argTagname)) {
                return elementLook;
            }
        }

        // Couldn't find any elements.
        return null;
    }

    /**
     * Gets a string from a selected node (or element).
     * 
     * This is used to retrieve all text data hanging on a node.
     * 
     * @param argElement
     *            Target element.
     * @return Text string to be retrieved. Returns null if it is not retrieved.
     */
    public static final String getTextContent(final BlancoXmlElement argElement) {
        if (argElement == null) {
            throw new IllegalArgumentException(
                    "The method to get the text from a node was given as null. Please try to give it a non-null value.");
        }

        final StringBuffer result = new StringBuffer();
        boolean isProcessed = false;

        final List<blanco.xml.bind.valueobject.BlancoXmlNode> listText = argElement
                .getChildNodes();
        final int sizeChildList = listText.size();
        for (int indexChild = 0; indexChild < sizeChildList; indexChild++) {
            final BlancoXmlNode objLook = listText.get(indexChild);
            if (objLook instanceof BlancoXmlCharacters) {
                final BlancoXmlCharacters textLook = (BlancoXmlCharacters) objLook;
                result.append(textLook.getValue());
                isProcessed = true;
            } else if (objLook instanceof BlancoXmlCdata) {
                final BlancoXmlCdata cdataLook = (BlancoXmlCdata) objLook;
                result.append(getTextContent(cdataLook));
                isProcessed = true;
            }
            // BlancoXmlIgnorableWhitespace is not be processed.
        }

        if (isProcessed == false) {
            return null;
        } else {
            return result.toString();
        }
    }

    /**
     * Reads a string of the specified tag name from an element.
     * 
     * @param elementTarget
     *            Target element.
     * @param tagName
     *            Tag name.
     * @return Text string to be retrieved. Returns null if it is not retrieved.
     */
    public static final String getTextContent(
            final BlancoXmlElement elementTarget, final String tagName) {
        if (elementTarget == null) {
            throw new IllegalArgumentException(
                    "The method to get the text from the element was given null as the element. Please try to give it a non-null value.");
        }
        if (tagName == null) {
            throw new IllegalArgumentException(
                    "The method to get the text from the element was given null as the tag name. Please try to give it a non-null value.");
        }

        final StringBuffer result = new StringBuffer();
        boolean isProcessed = false;

        final List<blanco.xml.bind.valueobject.BlancoXmlElement> listElementTarget = getElementsByTagName(
                elementTarget, tagName);
        final int sizeList = listElementTarget.size();
        for (int index = 0; index < sizeList; index++) {
            final BlancoXmlNode nodeLook = listElementTarget.get(index);
            if (nodeLook instanceof BlancoXmlElement) {
                final BlancoXmlElement elementLook = (BlancoXmlElement) nodeLook;

                final List<blanco.xml.bind.valueobject.BlancoXmlNode> listText = elementLook
                        .getChildNodes();
                final int sizeChildList = listText.size();
                for (int indexChild = 0; indexChild < sizeChildList; indexChild++) {
                    final BlancoXmlNode nodeChild = listText.get(indexChild);
                    if (nodeChild instanceof BlancoXmlCharacters) {
                        final BlancoXmlCharacters textLook = (BlancoXmlCharacters) nodeChild;
                        result.append(textLook.getValue());
                        isProcessed = true;
                    } else if (nodeChild instanceof BlancoXmlCdata) {
                        final BlancoXmlCdata cdataLook = (BlancoXmlCdata) nodeChild;
                        result.append(getTextContent(cdataLook));
                        isProcessed = true;
                    }
                    // BlancoXmlIgnorableWhitespace is not be processed.
                }
            }
        }

        if (isProcessed == false) {
            return null;
        } else {
            return result.toString();
        }
    }

    /**
     * Reads the text from the given CDATA.
     * 
     * @param argCdata
     *            CDATA.
     * @return The text.
     */
    public static final String getTextContent(final BlancoXmlCdata argCdata) {
        if (argCdata == null) {
            throw new IllegalArgumentException(
                    "The method to get the text from the CDATA was given null. Please try to give it a non-null value.");
        }

        final StringBuffer result = new StringBuffer();
        boolean isProcessed = false;

        final List<blanco.xml.bind.valueobject.BlancoXmlNode> listText = argCdata
                .getChildNodes();
        final int sizeChildList = listText.size();
        for (int indexChild = 0; indexChild < sizeChildList; indexChild++) {
            final BlancoXmlNode objLook = listText.get(indexChild);
            if (objLook instanceof BlancoXmlCharacters) {
                final BlancoXmlCharacters textLook = (BlancoXmlCharacters) objLook;
                result.append(textLook.getValue());
                isProcessed = true;
            } else if (objLook instanceof BlancoXmlCdata) {
                final BlancoXmlCdata cdataLook = (BlancoXmlCdata) objLook;
                for (int index = 0; index < cdataLook.getChildNodes().size(); index++) {

                    result.append(getTextContent(cdataLook));
                }
                isProcessed = true;
            }
            // BlancoXmlIgnorableWhitespace is not be processed.
        }

        if (isProcessed == false) {
            return null;
        } else {
            return result.toString();
        }
    }

    /**
     * Gets the attribute value by QName given by the element.
     * 
     * @param argElement
     *            An element.
     * @param argQName
     *            The name.
     * @return An Attribute value.
     */
    public static final String getAttribute(final BlancoXmlElement argElement,
            final String argQName) {
        for (int indexAttr = 0; indexAttr < argElement.getAtts().size(); indexAttr++) {
            final BlancoXmlAttribute attr = argElement.getAtts().get(indexAttr);
            if (argQName.equals(attr.getQName())) {
                return attr.getValue();
            }
        }

        // Couldn't find it.
        return null;
    }
}
