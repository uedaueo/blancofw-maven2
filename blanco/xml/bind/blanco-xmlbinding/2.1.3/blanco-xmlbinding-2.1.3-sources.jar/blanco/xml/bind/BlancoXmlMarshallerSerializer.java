/*
 * blanco Framework
 * Copyright (C) 2004-2009 IGA Tosiki
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 */
/*******************************************************************************
 * Copyright (c) 2009 IGA Tosiki, NTT DATA BUSINESS BRAINS Corp.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    IGA Tosiki (NTT DATA BUSINESS BRAINS Corp.) - initial API and implementation
 *******************************************************************************/
package blanco.xml.bind;

import javax.xml.transform.sax.TransformerHandler;

import org.xml.sax.Locator;
import org.xml.sax.SAXException;

import blanco.commons.util.BlancoStringUtil;
import blanco.xml.bind.valueobject.BlancoXmlAttribute;
import blanco.xml.bind.valueobject.BlancoXmlCdata;
import blanco.xml.bind.valueobject.BlancoXmlCharacters;
import blanco.xml.bind.valueobject.BlancoXmlComment;
import blanco.xml.bind.valueobject.BlancoXmlDocument;
import blanco.xml.bind.valueobject.BlancoXmlDtd;
import blanco.xml.bind.valueobject.BlancoXmlElement;
import blanco.xml.bind.valueobject.BlancoXmlIgnorableWhitespace;
import blanco.xml.bind.valueobject.BlancoXmlNode;
import blanco.xml.bind.valueobject.BlancoXmlPrefixMapping;

/**
 * This is a serializer implementation for generating XML from the value object representation of blancoXmlBinding.
 * 
 * This class is part of the XML/value object mapping (X/O mapping) blancoXmlBinding.
 * 
 * @author IGA Tosiki
 */
public class BlancoXmlMarshallerSerializer {
    /**
     * SAX handler for output to be used internally.<br>
     * The concatenated stream needs to be closed externally.
     */
    private TransformerHandler fSaxHandler;

    /**
     * Generates a serialized class using SAX serializer.
     * 
     * @param argHandler
     *            A handler for the SAX serializer.
     */
    public BlancoXmlMarshallerSerializer(final TransformerHandler argHandler) {
        fSaxHandler = argHandler;
    }

    /**
     * Expands the given Document to the SAX serializer.
     * 
     * @param document
     *            Document object.
     * @throws SAXException
     *             If a SAX exception occurs.
     */
    public void serialize(final BlancoXmlDocument document) throws SAXException {
        expandLocator(document);

        fSaxHandler.startDocument();

        // Expands prefix mapping.
        for (final BlancoXmlPrefixMapping prefixMapping : document
                .getPrefixMappings()) {
            fSaxHandler.startPrefixMapping(BlancoStringUtil
                    .null2Blank(prefixMapping.getPrefix()), BlancoStringUtil
                    .null2Blank(prefixMapping.getUri()));
            fSaxHandler.endPrefixMapping(BlancoStringUtil
                    .null2Blank(prefixMapping.getPrefix()));
        }

        // First line break.
        // Point: Outputs \n without regard to the newline code of the local system.
        fSaxHandler.characters("\n".toCharArray(), 0, 1);

        final int sizeChildNodes = document.getChildNodes().size();
        for (int index = 0; index < sizeChildNodes; index++) {
            final BlancoXmlNode objLook = document.getChildNodes().get(index);
            if (objLook instanceof BlancoXmlDtd) {
                expandDtd((BlancoXmlDtd) objLook);
            } else if (objLook instanceof BlancoXmlElement) {
                expandElement((BlancoXmlElement) objLook);
            } else {
                throw new IllegalArgumentException(
                        "BlancoXmlMarshallerSerializer: It passed through unexpected places.");
            }
        }

        fSaxHandler.endDocument();
    }

    /**
     * Expands a locator.
     * 
     * @param document
     *            Document object.
     */
    private void expandLocator(final BlancoXmlDocument document) {
        if (document.getLocator() != null) {
            fSaxHandler.setDocumentLocator(new Locator() {
                public String getPublicId() {
                    // Each method of Locator may return null.
                    return document.getLocator().getPublicId();
                }

                public String getSystemId() {
                    // Each method of Locator may return null.
                    return document.getLocator().getSystemId();
                }

                public int getLineNumber() {
                    return document.getLocator().getLineNumber();
                }

                public int getColumnNumber() {
                    return document.getLocator().getColumnNumber();
                }
            });
        }
    }

    /**
     * Expands the DTD.
     * 
     * @param argDtd
     *            DTD information.
     * @throws SAXException
     *             If a SAX exception occurs.
     */
    private void expandDtd(final BlancoXmlDtd argDtd) throws SAXException {
        fSaxHandler.startDTD(argDtd.getName(), argDtd.getPublicId(), argDtd
                .getSystemId());
        fSaxHandler.endDTD();
    }

    /**
     * Expands an element.
     * 
     * @param element
     *            An element.
     * @throws SAXException
     *            If a SAX exception occurs.
     */
    private void expandElement(final BlancoXmlElement element)
            throws SAXException {
        if (BlancoStringUtil.null2Blank(element.getLocalName()).length() == 0
                && BlancoStringUtil.null2Blank(element.getQName()).length() == 0) {
            throw new IllegalArgumentException(
                    "There is an Element for which neither localName nor QName has been specified. The process will be aborted.");
        }

        String qName = element.getQName();
        if (BlancoStringUtil.null2Blank(qName).length() == 0) {
            // The value of localName is set if nothing is specified for QName.
            qName = element.getLocalName();
        }

        // Also for attributes, it takes measures to prevent null such as  copying localName if QName is not specified.
        for (int index = 0; index < element.getAtts().size(); index++) {
            final BlancoXmlAttribute attrLook = (BlancoXmlAttribute) element
                    .getAtts().get(index);
            attrLook.setLocalName(BlancoStringUtil.null2Blank(attrLook
                    .getLocalName()));
            attrLook.setType(BlancoStringUtil.null2Blank(attrLook.getType()));
            attrLook.setValue(BlancoStringUtil.null2Blank(attrLook.getValue()));

            if (BlancoStringUtil.null2Blank(attrLook.getQName()).length() == 0) {
                // The value of localName is set if nothing is specified for QName.
                attrLook.setQName(attrLook.getLocalName());
            }
            if (attrLook.getQName().length() == 0) {
                // If QName is still blank.
                throw new IllegalArgumentException(
                        "The QName of the attribute was still null, and could not be derived from localName either.:"
                                + element.toString());
            }
        }

        // Note that if it is not specified, an empty string must be passed instead of null.
        fSaxHandler.startElement(BlancoStringUtil.null2Blank(element.getUri()),
                BlancoStringUtil.null2Blank(element.getLocalName()), qName,
                new BlancoXmlAttributesImpl(element.getAtts()));

        // Expands the child node.
        final int sizeChildNodes = element.getChildNodes().size();
        for (int index = 0; index < sizeChildNodes; index++) {
            final BlancoXmlNode objLook = element.getChildNodes().get(index);
            if (objLook instanceof BlancoXmlElement) {
                expandElement((BlancoXmlElement) objLook);
            } else if (objLook instanceof BlancoXmlCharacters) {
                expandCharacters((BlancoXmlCharacters) objLook);
            } else if (objLook instanceof BlancoXmlIgnorableWhitespace) {
                expandIgnorableWhitespace((BlancoXmlIgnorableWhitespace) objLook);
            } else if (objLook instanceof BlancoXmlComment) {
                expandComment((BlancoXmlComment) objLook);
            } else if (objLook instanceof BlancoXmlCdata) {
                expandCdata((BlancoXmlCdata) objLook);
            } else {
                throw new IllegalArgumentException(
                        "BlancoXmlMarshallerSerializer: It passed through unexpected places.");
            }
        }

        // Note that if it is not specified, an empty string must be passed instead of null.
        fSaxHandler.endElement(BlancoStringUtil.null2Blank(element.getUri()),
                BlancoStringUtil.null2Blank(element.getLocalName()), qName);
    }

    /**
     * Expands character data.
     * 
     * @param argCharacters
     *            Character data.
     * @throws SAXException
     *             If a SAX exception occurs.
     */
    private void expandCharacters(final BlancoXmlCharacters argCharacters)
            throws SAXException {
        if (argCharacters == null) {
            throw new IllegalArgumentException(
                    "The argument of expandCharacters was given as null.");
        }
        if (argCharacters.getValue() == null) {
            // Assigns "" to avoid raising an exception if null is specified.
            argCharacters.setValue("");
        }

        final char[] buf = argCharacters.getValue().toCharArray();
        fSaxHandler.characters(buf, 0, buf.length);
    }

    /**
     * Expands ignorable blank data.
     * 
     * @param argIgnorableWhitespace
     *            Ignorable blank data.
     * @throws SAXException
     *            If a SAX exception occurs.
     */
    private void expandIgnorableWhitespace(
            final BlancoXmlIgnorableWhitespace argIgnorableWhitespace)
            throws SAXException {
        final char[] buf = argIgnorableWhitespace.getValue().toCharArray();
        fSaxHandler.ignorableWhitespace(buf, 0, buf.length);
    }

    /**
     * Expands comments.
     * 
     * @param argComment
     *            Comment object.
     * @throws SAXException
     *            If a SAX exception occurs.
     */
    private void expandComment(final BlancoXmlComment argComment)
            throws SAXException {
        final char[] buf = argComment.getValue().toCharArray();
        fSaxHandler.comment(buf, 0, buf.length);
    }

    /**
     * Expands CDATA.
     * 
     * @param argCdata
     *            CDATA object.
     * @throws SAXException
     *            If a SAX exception occurs.
     */
    private void expandCdata(final BlancoXmlCdata argCdata) throws SAXException {
        fSaxHandler.startCDATA();

        // Expands the child node.
        final int sizeChildNodes = argCdata.getChildNodes().size();
        for (int index = 0; index < sizeChildNodes; index++) {
            final BlancoXmlNode objLook = argCdata.getChildNodes().get(index);
            if (objLook instanceof BlancoXmlElement) {
                expandElement((BlancoXmlElement) objLook);
            } else if (objLook instanceof BlancoXmlCharacters) {
                expandCharacters((BlancoXmlCharacters) objLook);
            } else if (objLook instanceof BlancoXmlIgnorableWhitespace) {
                expandIgnorableWhitespace((BlancoXmlIgnorableWhitespace) objLook);
            } else if (objLook instanceof BlancoXmlComment) {
                expandComment((BlancoXmlComment) objLook);
            } else {
                throw new IllegalArgumentException(
                        "BlancoXmlMarshallerSerializer: It passed through unexpected places.");
            }
        }

        fSaxHandler.endCDATA();
    }
}
