/*
 * blanco Framework
 * Copyright (C) 2004-2009 IGA Tosiki
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 */
/*******************************************************************************
 * Copyright (c) 2009 IGA Tosiki, NTT DATA BUSINESS BRAINS Corp.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    IGA Tosiki (NTT DATA BUSINESS BRAINS Corp.) - initial API and implementation
 *******************************************************************************/
package blanco.xml.bind;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.logging.Logger;

import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.sax.SAXResult;
import javax.xml.transform.stream.StreamSource;

import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.SAXNotRecognizedException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;

import blanco.xml.bind.valueobject.BlancoXmlDocument;

/**
 * A class to generate blancoXmlBinding value object repsresentations from XML.
 * 
 * This class is part of the XML/value object mapping (X/O mapping) blancoXmlBinding.
 * 
 * @author IGA Tosiki
 */
public class BlancoXmlUnmarshaller {
    /**
     * Generates a Java object from XML.
     * 
     * cf. http://java.sun.com/webservices/docs/1.6/api/javax/xml/bind/
     * Unmarshaller.html
     * 
     * @param fileInput
     *           XML file.
     * @return An object as blancoXml.
     */
    public BlancoXmlDocument unmarshal(final File fileInput) {
        if (fileInput.exists() == false) {
            throw new IllegalArgumentException("File["
                    + fileInput.getAbsolutePath() + "] is not found.");
        }
        if (fileInput.isDirectory()) {
            throw new IllegalArgumentException("File["
                    + fileInput.getAbsolutePath() + "] is actually a directory.");
        }
        if (fileInput.canRead() == false) {
            throw new IllegalArgumentException("File["
                    + fileInput.getAbsolutePath() + "] cannot be read.");
        }

        InputStream inStream = null;

        try {
            inStream = new BufferedInputStream(new FileInputStream(fileInput));

            return unmarshal(inStream);
        } catch (IOException e) {
            throw new IllegalArgumentException("An I/O exception has occurred during processing.: "
                    + e.toString(), e);
        } finally {
            if (inStream != null) {
                try {
                    inStream.close();
                } catch (IOException e) {
                    throw new IllegalArgumentException(
                            "An I/O exception has occurred during the input stream closing process.: " + e.toString(), e);
                }
            }
        }
    }

    /**
     * Generates a Java object from XML.
     * 
     * Reference: http://java.sun.com/webservices/docs/1.6/api/javax/xml/bind/
     * Unmarshaller.html
     * 
     * @param inStream
     *            XML input stream.
     * @return An object as blancoXml
     */
    public BlancoXmlDocument unmarshal(final InputStream inStream) {
        if (inStream == null) {
            throw new IllegalArgumentException(
                    "BlancoXmlUnmarshaller#unmarshal: The input stream was given null.");
        }

        final BlancoXmlUnmarshallerContentHandler handler = new BlancoXmlUnmarshallerContentHandler();

        try {
            // We want to control the settings of the XML parser, so we prioritize using XMLReader.
            XMLReader reader = null;
            try {
                reader = XMLReaderFactory.createXMLReader();
            } catch (SAXException e) {
                Logger.getLogger("blanco.xml.bind").fine(
                        "Failed to get XMLReader: " + e.toString());

                // In some environments (rare in JDK 1.4.2?), the XMLReader may fail to be retrieved.

                // When calling XMLReaderFactory.createXMLReader(),
                // "org.xml.sax.SAXException: System property org.xml.sax.driver not specified"
                // has been observed.
                final SAXResult result = new SAXResult(handler);
                result.setHandler(handler);
                result.setLexicalHandler(handler);
                final TransformerFactory tf = TransformerFactory.newInstance();
                try {
                    final Transformer transformer = tf.newTransformer();
                    transformer.transform(new StreamSource(inStream), result);
                    return handler.getDocument();

                } catch (TransformerException e2) {
                    throw new IllegalArgumentException("An XML parsing exception has occurred during processing."
                            + e2.toString(), e2);
                }
            }

            //  It will go through here if XMLReader is obtained successfully.

            try {
                // A "magic" to prevent external DTDs from being read.
                reader
                        .setFeature(
                                "http://apache.org/xml/features/nonvalidating/load-external-dtd",
                                false);
            } catch (SAXNotRecognizedException e) {
                Logger.getLogger("blanco.xml.bind").finest(
                        "An exception has occurred during the implementation of the setting to disable reading of external DTDs: " + e.toString());
            }

            reader.setContentHandler(handler);
            reader.setDTDHandler(handler);
            // Sets properties to handle comments.
            reader.setProperty("http://xml.org/sax/properties/lexical-handler",
                    handler);

            // DTD declarations are not currently processed.
            // This is because the current processing scope is limited to
            // javax.xml.transform.sax.TransformerHandler.
            
            // reader.setProperty(
            // "http://xml.org/sax/properties/declaration-handler",
            // handler);

            reader.parse(new InputSource(inStream));
            return handler.getDocument();

        } catch (SAXException e) {
            throw new IllegalArgumentException("An XML parsing exception has occurred during processing.: "
                    + e.toString(), e);
        } catch (IOException e) {
            throw new IllegalArgumentException("An I/O exception has occurred during processing.: "
                    + e.toString(), e);
        } finally {
            if (inStream != null) {
                try {
                    inStream.close();
                } catch (IOException e) {
                    throw new IllegalArgumentException(
                            "An I/O exception has occurred during the input stream closing process.: " + e.toString(), e);
                }
            }
        }
    }
}
