package blanco.xml.bind.valueobject;

import java.util.List;

/**
 * SAXイベントのうち ドキュメントを記憶します。このクラスは XML/バリューオブジェクトマッピング (X/Oマッピング) blancoXmlBinding の一部です。
 */
public class BlancoXmlDocument extends BlancoXmlNode {
    /**
     * このドキュメントに連なる子ノードを格納します。ドキュメントは多くの場合ひとつのルートエレメントを格納しています。場合により DTD関連情報なども格納されます。
     *
     * フィールド: [childNodes]。
     * デフォルト: [new java.util.ArrayList&lt;blanco.xml.bind.valueobject.BlancoXmlNode&gt;()]。
     */
    private List<BlancoXmlNode> fChildNodes = new java.util.ArrayList<blanco.xml.bind.valueobject.BlancoXmlNode>();

    /**
     * ロケーション。
     *
     * フィールド: [locator]。
     */
    private BlancoXmlLocator fLocator;

    /**
     * prefixMappingのリストを格納します。
     *
     * フィールド: [prefixMappings]。
     * デフォルト: [new java.util.ArrayList&lt;blanco.xml.bind.valueobject.BlancoXmlPrefixMapping&gt;()]。
     */
    private List<BlancoXmlPrefixMapping> fPrefixMappings = new java.util.ArrayList<blanco.xml.bind.valueobject.BlancoXmlPrefixMapping>();

    /**
     * XML のバージョン。1.1 などを指定。
     *
     * フィールド: [version]。
     */
    private String fVersion;

    /**
     * XML のエンコーディング
     *
     * フィールド: [encoding]。
     */
    private String fEncoding;

    /**
     * フィールド [childNodes] の値を設定します。
     *
     * フィールドの説明: [このドキュメントに連なる子ノードを格納します。ドキュメントは多くの場合ひとつのルートエレメントを格納しています。場合により DTD関連情報なども格納されます。]。
     *
     * @param argChildNodes フィールド[childNodes]に設定する値。
     */
    public void setChildNodes(final List<BlancoXmlNode> argChildNodes) {
        fChildNodes = argChildNodes;
    }

    /**
     * フィールド [childNodes] の値を取得します。
     *
     * フィールドの説明: [このドキュメントに連なる子ノードを格納します。ドキュメントは多くの場合ひとつのルートエレメントを格納しています。場合により DTD関連情報なども格納されます。]。
     * デフォルト: [new java.util.ArrayList&lt;blanco.xml.bind.valueobject.BlancoXmlNode&gt;()]。
     *
     * @return フィールド[childNodes]から取得した値。
     */
    public List<BlancoXmlNode> getChildNodes() {
        return fChildNodes;
    }

    /**
     * フィールド [locator] の値を設定します。
     *
     * フィールドの説明: [ロケーション。]。
     *
     * @param argLocator フィールド[locator]に設定する値。
     */
    public void setLocator(final BlancoXmlLocator argLocator) {
        fLocator = argLocator;
    }

    /**
     * フィールド [locator] の値を取得します。
     *
     * フィールドの説明: [ロケーション。]。
     *
     * @return フィールド[locator]から取得した値。
     */
    public BlancoXmlLocator getLocator() {
        return fLocator;
    }

    /**
     * フィールド [prefixMappings] の値を設定します。
     *
     * フィールドの説明: [prefixMappingのリストを格納します。]。
     *
     * @param argPrefixMappings フィールド[prefixMappings]に設定する値。
     */
    public void setPrefixMappings(final List<BlancoXmlPrefixMapping> argPrefixMappings) {
        fPrefixMappings = argPrefixMappings;
    }

    /**
     * フィールド [prefixMappings] の値を取得します。
     *
     * フィールドの説明: [prefixMappingのリストを格納します。]。
     * デフォルト: [new java.util.ArrayList&lt;blanco.xml.bind.valueobject.BlancoXmlPrefixMapping&gt;()]。
     *
     * @return フィールド[prefixMappings]から取得した値。
     */
    public List<BlancoXmlPrefixMapping> getPrefixMappings() {
        return fPrefixMappings;
    }

    /**
     * フィールド [version] の値を設定します。
     *
     * フィールドの説明: [XML のバージョン。1.1 などを指定。]。
     *
     * @param argVersion フィールド[version]に設定する値。
     */
    public void setVersion(final String argVersion) {
        fVersion = argVersion;
    }

    /**
     * フィールド [version] の値を取得します。
     *
     * フィールドの説明: [XML のバージョン。1.1 などを指定。]。
     *
     * @return フィールド[version]から取得した値。
     */
    public String getVersion() {
        return fVersion;
    }

    /**
     * フィールド [encoding] の値を設定します。
     *
     * フィールドの説明: [XML のエンコーディング]。
     *
     * @param argEncoding フィールド[encoding]に設定する値。
     */
    public void setEncoding(final String argEncoding) {
        fEncoding = argEncoding;
    }

    /**
     * フィールド [encoding] の値を取得します。
     *
     * フィールドの説明: [XML のエンコーディング]。
     *
     * @return フィールド[encoding]から取得した値。
     */
    public String getEncoding() {
        return fEncoding;
    }

    /**
     * Gets the string representation of this value object.
     *
     * <P>Precautions for use</P>
     * <UL>
     * <LI>Only the shallow range of the object will be subject to the stringification process.
     * <LI>Do not use this method if the object has a circular reference.
     * </UL>
     *
     * @return String representation of a value object.
     */
    @Override
    public String toString() {
        final StringBuffer buf = new StringBuffer();
        buf.append("blanco.xml.bind.valueobject.BlancoXmlDocument[");
        buf.append("childNodes=" + fChildNodes);
        buf.append(",locator=" + fLocator);
        buf.append(",prefixMappings=" + fPrefixMappings);
        buf.append(",version=" + fVersion);
        buf.append(",encoding=" + fEncoding);
        buf.append("]");
        return buf.toString();
    }

    /**
     * このバリューオブジェクトを指定のターゲットに複写します。
     *
     * <P>使用上の注意</P>
     * <UL>
     * <LI>オブジェクトのシャロー範囲のみ複写処理対象となります。
     * <LI>オブジェクトが循環参照している場合には、このメソッドは使わないでください。
     * </UL>
     *
     * @param target target value object.
     */
    public void copyTo(final BlancoXmlDocument target) {
        if (target == null) {
            throw new IllegalArgumentException("Bug: BlancoXmlDocument#copyTo(target): argument 'target' is null");
        }

        // No needs to copy parent class.

        // Name: fChildNodes
        // Type: java.util.List
        // フィールド[fChildNodes]はサポート外の型[java.util.Listblanco.xml.bind.valueobject.BlancoXmlNode]です。
        // Name: fLocator
        // Type: blanco.xml.bind.valueobject.BlancoXmlLocator
        // フィールド[fLocator]はサポート外の型[blanco.xml.bind.valueobject.BlancoXmlLocator]です。
        // Name: fPrefixMappings
        // Type: java.util.List
        // フィールド[fPrefixMappings]はサポート外の型[java.util.Listblanco.xml.bind.valueobject.BlancoXmlPrefixMapping]です。
        // Name: fVersion
        // Type: java.lang.String
        target.fVersion = this.fVersion;
        // Name: fEncoding
        // Type: java.lang.String
        target.fEncoding = this.fEncoding;
    }
}
