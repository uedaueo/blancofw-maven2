/*
 * blanco Framework
 * Copyright (C) 2004-2009 IGA Tosiki
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 */
/*******************************************************************************
 * Copyright (c) 2009 IGA Tosiki, NTT DATA BUSINESS BRAINS Corp.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    IGA Tosiki (NTT DATA BUSINESS BRAINS Corp.) - initial API and implementation
 *******************************************************************************/
package blanco.xml.bind;

import java.util.Stack;

import org.xml.sax.Attributes;
import org.xml.sax.ContentHandler;
import org.xml.sax.DTDHandler;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.ext.LexicalHandler;

import blanco.xml.bind.valueobject.BlancoXmlAttribute;
import blanco.xml.bind.valueobject.BlancoXmlCdata;
import blanco.xml.bind.valueobject.BlancoXmlCharacters;
import blanco.xml.bind.valueobject.BlancoXmlComment;
import blanco.xml.bind.valueobject.BlancoXmlDocument;
import blanco.xml.bind.valueobject.BlancoXmlDtd;
import blanco.xml.bind.valueobject.BlancoXmlElement;
import blanco.xml.bind.valueobject.BlancoXmlIgnorableWhitespace;
import blanco.xml.bind.valueobject.BlancoXmlLocator;
import blanco.xml.bind.valueobject.BlancoXmlNode;
import blanco.xml.bind.valueobject.BlancoXmlPrefixMapping;

/**
 * This is a content handler implementation for generating blancoXmlBinding value object representations from XML.
 * 
 * This class is part of the XML/value object mapping (X/O mapping) blancoXmlBinding.
 * 
 * It is the flip side of javax.xml.transform.sax.TransformerHandler.
 * 
 * @author IGA Tosiki
 */
public class BlancoXmlUnmarshallerContentHandler implements ContentHandler,
        LexicalHandler, DTDHandler {
    /**
     * We experimented with caching strings for memory efficiency, etc., but it made things worse. <br>
     * For now, we will focus on improving the processing without doing any tricks.
     * 
     * An ineffective implementation is string sharing with Map, as shown below.  // private Map<String, String>
     * fStringMap = new HashMap<String, String>();
     */

    /**
     * Memorizes the root document.
     */
    protected final BlancoXmlDocument fDocument = new BlancoXmlDocument();

    /**
     * Memorizes the point currently being processed.
     */
    protected final Stack<BlancoXmlNode> fDocumentElementStack = new Stack<BlancoXmlNode>();

    /**
     * Creates a new content handler obejct.
     */
    public BlancoXmlUnmarshallerContentHandler() {
        fDocumentElementStack.push(fDocument);
    }

    /**
     * Gets the root document.
     * 
     * @return XML document.
     */
    public BlancoXmlDocument getDocument() {
        return fDocument;
    }

    // ------------------------------------------------
    // It is a methods for ContentHandler from here.
    // ------------------------------------------------

    /**
     * Start-of-document event of ContentHandler.
     */
    public void startDocument() throws SAXException {
        // It has already been pushed.
    }

    /**
     * End-of-document event of ContentHandler.
     */
    public void endDocument() throws SAXException {
        fDocumentElementStack.pop();
    }

    /**
     * Locator event of ContentHandler.
     * 
     * @param argLocator
     *            Location of the SAX document event.
     */
    public void setDocumentLocator(final Locator argLocator) {
        final BlancoXmlLocator locator = new BlancoXmlLocator();

        // Gets the object currently being processed.
        final BlancoXmlNode objCurrent = fDocumentElementStack.peek();
        if (objCurrent instanceof BlancoXmlDocument == false) {
            throw new IllegalArgumentException(
                    "BlancoXmlUnmarshallerContentHandler: You tried to set a Locator for something that is not Document.");
        }

        ((BlancoXmlDocument) objCurrent).setLocator(locator);

        locator.setPublicId(argLocator.getPublicId());
        locator.setSystemId(argLocator.getSystemId());
        locator.setLineNumber(argLocator.getLineNumber());
        locator.setColumnNumber(argLocator.getColumnNumber());
    }

    /**
     * Start-of-PrefixMapping event of ContentHandler.
     * 
     * @param prefix
     *            Namespace prefix.
     * @param uri
     *            The namespace URI to which the prefix is mapped.
     */
    public void startPrefixMapping(final String prefix, final String uri)
            throws SAXException {
        final BlancoXmlPrefixMapping prefixMapping = new BlancoXmlPrefixMapping();
        prefixMapping.setPrefix(prefix);
        prefixMapping.setUri(uri);

        // Gets the object currently begin processed.
        final BlancoXmlNode objCurrent = fDocumentElementStack.peek();
        if (objCurrent instanceof BlancoXmlDocument) {
            ((BlancoXmlDocument) objCurrent).getPrefixMappings().add(
                    prefixMapping);
        } else if (objCurrent instanceof BlancoXmlElement) {
            // Ignores startPrefixMapping in the case of elements.
        } else {
            throw new IllegalArgumentException(
                    "BlancoXmlUnmarshallerContentHandler: You tried to set a prefixMapping for something that is neither a Document nor an Element.");
        }
    }

    /**
     * End-of-PrefixMapping event of ContentHandler.
     * 
     * @param prefix
     *            Namespace prefix.
     */
    public void endPrefixMapping(final String prefix) throws SAXException {
    }

    /**
     * Start-of-Element event of ContentHandler.
     * 
     * @param uri
     *            The namespace URI to which the prefix is mapped.
     * @param localName
     *            Local name.
     * @param qName
     *            A prefixed qualified name.
     * @param atts
     *            Attribute list.
     */
    public void startElement(final String uri, final String localName,
            final String qName, final Attributes atts) throws SAXException {
        final BlancoXmlElement element = new BlancoXmlElement();

        // Gets the object currently being processed.
        final BlancoXmlNode objCurrent = fDocumentElementStack.peek();
        if (objCurrent instanceof BlancoXmlElement) {
            final BlancoXmlElement elementParent = ((BlancoXmlElement) objCurrent);
            elementParent.getChildNodes().add(element);
        } else if (objCurrent instanceof BlancoXmlDocument) {
            ((BlancoXmlDocument) objCurrent).getChildNodes().add(element);
        } else {
            throw new IllegalArgumentException(
                    "BlancoXmlUnmarshallerContentHandler: You tried to add an Element for an unexpected type["
                            + objCurrent.getClass().getName()
                            + "].");
        }

        // Copies the element.
        element.setUri(uri);
        element.setLocalName(localName);
        element.setQName(qName);

        // Copies the attributes.
        copyAttributes(atts, element);

        fDocumentElementStack.push(element);
    }

    /**
     * Copies the attributes.
     * 
     * @param atts
     *            Attribute list.
     * @param element
     *            An element of destination to copy.
     */
    protected void copyAttributes(final Attributes atts,
            final BlancoXmlElement element) {
        final int attrLength = atts.getLength();
        for (int index = 0; index < attrLength; index++) {
            final BlancoXmlAttribute attribute = new BlancoXmlAttribute();
            element.getAtts().add(attribute);

            attribute.setUri(atts.getURI(index));
            attribute.setLocalName(atts.getLocalName(index));
            attribute.setQName(atts.getQName(index));
            attribute.setType(atts.getType(index));
            attribute.setValue(atts.getValue(index));
        }
    }

    /**
     * End-of-element event of ContentHandler.
     * 
     * @param uri
     *            The namespace URI to which the prefix is mapped.
     * @param localName
     *            Local name.
     * @param qName
     *            A prefixed qualified name.
     */
    public void endElement(final String uri, final String localName,
            final String qName) throws SAXException {
        fDocumentElementStack.pop();
    }

    /**
     * Character event of ContentHandler.
     * 
     * @param ch
     * @param start
     * @param length
     */
    public void characters(final char[] ch, final int start, final int length)
            throws SAXException {
        final BlancoXmlCharacters characters = new BlancoXmlCharacters();

        // Gets the object currently being processed.
        final BlancoXmlNode objCurrent = fDocumentElementStack.peek();
        if (objCurrent instanceof BlancoXmlElement) {
            ((BlancoXmlElement) objCurrent).getChildNodes().add(characters);
        } else if (objCurrent instanceof BlancoXmlCdata) {
            ((BlancoXmlCdata) objCurrent).getChildNodes().add(characters);
        } else if (objCurrent instanceof BlancoXmlDocument) {
            ((BlancoXmlDocument) objCurrent).getChildNodes().add(characters);
        } else {
            throw new IllegalArgumentException(
                    "BlancoXmlUnmarshallerContentHandler: You tried to add Characters for an unexpected type["
                            + objCurrent.getClass().getName()
                            + "].");
        }

        characters.setValue(new String(ch, start, length));
    }

    /**
     * Ignorable character event of ContentHandler.
     * 
     * @param ch
     * @param start
     * @param length
     */
    public void ignorableWhitespace(final char[] ch, final int start,
            final int length) throws SAXException {
        final BlancoXmlIgnorableWhitespace ignorableWhitespace = new BlancoXmlIgnorableWhitespace();

        // Gets the object currently being processed.
        final BlancoXmlNode objCurrent = fDocumentElementStack.peek();
        if (objCurrent instanceof BlancoXmlElement) {
            ((BlancoXmlElement) objCurrent).getChildNodes().add(
                    ignorableWhitespace);
        } else if (objCurrent instanceof BlancoXmlCdata) {
            ((BlancoXmlDocument) objCurrent).getChildNodes().add(
                    ignorableWhitespace);
        } else if (objCurrent instanceof BlancoXmlDocument) {
            ((BlancoXmlDocument) objCurrent).getChildNodes().add(
                    ignorableWhitespace);
        } else {
            throw new IllegalArgumentException(
                    "BlancoXmlUnmarshallerContentHandler: You tried to add BlancoXmlIgnorableWhitespace for an unexpected type["
                            + objCurrent.getClass().getName()
                            + "].");
        }

        ignorableWhitespace.setValue(new String(ch, start, length));
    }

    /**
     * processingInstruction of ContentHandler.
     * 
     * @param target
     * @param data
     */
    public void processingInstruction(final String target, final String data)
            throws SAXException {
        // This event will be ignored in the current specification.
    }

    /**
     * skippedEntity of ContentHandler.
     * 
     * @param name
     */
    public void skippedEntity(final String name) throws SAXException {
        // This event will be ignored in the current specification.
    }

    // ------------------------------------------------
    // It is a method for LexicalHandler from here.
    // ------------------------------------------------

    /**
     * Start-of-DTD event of LexicalHandler.
     * 
     * @param name
     * @param publicId
     * @param systemId
     */
    public void startDTD(final String name, final String publicId,
            final String systemId) throws SAXException {
        final BlancoXmlDtd dtd = new BlancoXmlDtd();

        // Gets the object currently being processed.
        final BlancoXmlNode objCurrent = fDocumentElementStack.peek();
        if (objCurrent instanceof BlancoXmlDocument) {
            ((BlancoXmlDocument) objCurrent).getChildNodes().add(dtd);
        } else {
            throw new IllegalArgumentException(
                    "BlancoXmlUnmarshallerContentHandler: You tried to add BlancoXmlDtd for an unexpected type["
                            + objCurrent.getClass().getName()
                            + "].");
        }
    }

    /**
     * End-of-DTD event of LexicalHandler.
     */
    public void endDTD() throws SAXException {
    }

    /**
     * Start-of-Entity event of LexicalHandler.
     * 
     * @param name
     *            Entity name.
     */
    public void startEntity(final String name) throws SAXException {
        // This is not supported in the current specification.
    }

    /**
     * End-of-Entity event of LexicalHandler.
     * 
     * @param name
     *            Entity name.
     */
    public void endEntity(final String name) throws SAXException {
        // This is not supported in the current specification.
    }

    /**
     * Start-of-CDATA event of LexicalHandler.
     */
    public void startCDATA() throws SAXException {
        final BlancoXmlCdata cdata = new BlancoXmlCdata();

        // Gets the object currently being processed.
        final BlancoXmlNode objCurrent = fDocumentElementStack.peek();
        if (objCurrent instanceof BlancoXmlElement) {
            final BlancoXmlElement elementParent = ((BlancoXmlElement) objCurrent);
            elementParent.getChildNodes().add(cdata);
        } else if (objCurrent instanceof BlancoXmlDocument) {
            ((BlancoXmlDocument) objCurrent).getChildNodes().add(cdata);
        } else {
            throw new IllegalArgumentException(
                    "BlancoXmlUnmarshallerContentHandler: You tried to add CDATA for an unexpected type["
                            + objCurrent.getClass().getName()
                            + "].");
        }

        fDocumentElementStack.push(cdata);
    }

    /**
     * End-of-CDATA event of LexicalHandler.
     */
    public void endCDATA() throws SAXException {
        fDocumentElementStack.pop();
    }

    /**
     * Comment event of LexicalHandler.
     * 
     * @param ch
     * @param start
     * @param length
     */
    public void comment(final char[] ch, final int start, final int length)
            throws SAXException {
        final BlancoXmlComment comment = new BlancoXmlComment();

        // Gets the object currently being processed.
        final BlancoXmlNode objCurrent = fDocumentElementStack.peek();
        if (objCurrent instanceof BlancoXmlElement) {
            ((BlancoXmlElement) objCurrent).getChildNodes().add(comment);
        } else if (objCurrent instanceof BlancoXmlDocument) {
            ((BlancoXmlDocument) objCurrent).getChildNodes().add(comment);
        } else {
            throw new IllegalArgumentException(
                    "BlancoXmlUnmarshallerContentHandler: You tried to add BlancoXmlComment for an unexpected type["
                            + objCurrent.getClass().getName()
                            + "].");
        }

        comment.setValue(new String(ch, start, length));
    }

    // ------------------------------------------------
    // It is a method for DTDHandler from here.
    // ------------------------------------------------

    public void notationDecl(final String name, final String publicId,
            final String systemId) throws SAXException {
        // TODO Not implemented.
    }

    public void unparsedEntityDecl(final String name, final String publicId,
            final String systemId, final String notationName)
            throws SAXException {
        // TODO Not implemented.
    }
}
