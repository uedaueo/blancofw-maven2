/*
 * blanco Framework
 * Copyright (C) 2004-2009 IGA Tosiki
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 */
/*******************************************************************************
 * Copyright (c) 2009 IGA Tosiki, NTT DATA BUSINESS BRAINS Corp.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    IGA Tosiki (NTT DATA BUSINESS BRAINS Corp.) - initial API and implementation
 *******************************************************************************/
package blanco.xml.bind;

import java.util.List;

import org.xml.sax.Attributes;

import blanco.commons.util.BlancoStringUtil;
import blanco.xml.bind.valueobject.BlancoXmlAttribute;

/**
 * This is the attribute implementation used by blancoXmlBinding.
 * 
 * This class is part of the XML/value object mapping (X/O mapping) blancoXmlBinding.
 * 
 * @author IGA Tosiki
 */
public class BlancoXmlAttributesImpl implements Attributes {
    /**
     * A list of actual attributes.
     */
    private List<BlancoXmlAttribute> fAttrs = null;

    /**
     * Generates an instance of the attribute implementation.
     * 
     * @param attrs
     *            The list of attributes.
     */
    public BlancoXmlAttributesImpl(final List<BlancoXmlAttribute> attrs) {
        if (attrs == null) {
            throw new IllegalArgumentException(
                    "The constructor of BlancoXmlMarshallerAttributesImpl was given a null argument.");
        }

        fAttrs = attrs;
    }

    /**
     * Returns the number of attributes in the list.
     * 
     * @return The number of attributes.
     */
    public int getLength() {
        return fAttrs.size();
    }

    /**
     * Searches for the namespace URI of an attribute.
     * 
     * @param index
     *            Attribute index.
     * @return Namespace URI.
     */
    public String getURI(int index) {
        final BlancoXmlAttribute attribute = getAttr(index);
        if (attribute == null) {
            return null;
        }

        return attribute.getUri();
    }

    /**
     * Searches for the local name of an attribute.
     * 
     * @param index
     *            Attribute index.
     * @return Local name.
     */
    public String getLocalName(int index) {
        final BlancoXmlAttribute attribute = getAttr(index);
        if (attribute == null) {
            return null;
        }

        return attribute.getLocalName();
    }

    /**
     * Searches for XML 1.0 qualified name for attributes.
     * 
     * @param index
     *            Attribute index.
     * @return Qualified name.
     */
    public String getQName(int index) {
        final BlancoXmlAttribute attribute = getAttr(index);
        if (attribute == null) {
            return null;
        }

        final String qName = BlancoStringUtil.null2Blank(attribute.getQName());
        if (qName.length() == 0) {
            // Returns localName if no value is specified for qName.
            return getLocalName(index);
        }

        return attribute.getQName();
    }

    /**
     * Searches for the type of an attribute.
     * 
     * @param index
     *            Attribute index.
     * @return The type of an attribute.
     */
    public String getType(int index) {
        final BlancoXmlAttribute attribute = getAttr(index);
        if (attribute == null) {
            return null;
        }

        return attribute.getType();
    }

    /**
     * Searches for the value of an attribute.
     * 
     * @param index
     *            Attribute index.
     * @return The value of an attribute.
     */
    public String getValue(int index) {
        final BlancoXmlAttribute attribute = getAttr(index);
        if (attribute == null) {
            return null;
        }

        return attribute.getValue();
    }

    /**
     * Searches for the index of an attribute.
     * 
     * @param uri
     *            Namespace URI.
     * @param localName
     *            Local name.
     * @return Attribute index. Returns -1 if the corresponding attribute does not exist in the list.
     */
    public int getIndex(final String uri, final String localName) {
        final int attrSize = fAttrs.size();
        for (int index = 0; index < attrSize; index++) {
            final BlancoXmlAttribute attrLook = (BlancoXmlAttribute) fAttrs
                    .get(index);
            if (BlancoStringUtil.null2Blank(attrLook.getUri()).equals(uri)
                    && BlancoStringUtil.null2Blank(attrLook.getLocalName())
                            .equals(localName)) {
                return index;
            }
        }

        // Couldn't find it.
        return -1;
    }

    /**
     * Searches for the index of an attribute.
     * 
     * @param qName
     *            Qualified name.
     * @return Attribute index. Returns -1 if the corresponding attribute does not exist in the list.
     */
    public int getIndex(final String qName) {
        final int attrSize = fAttrs.size();
        for (int index = 0; index < attrSize; index++) {
            final BlancoXmlAttribute attrLook = (BlancoXmlAttribute) fAttrs
                    .get(index);
            if (BlancoStringUtil.null2Blank(attrLook.getQName()).equals(qName)) {
                return index;
            }
        }

        // Couldn't find it.
        return -1;
    }

    /**
     * Searches for the type of an attribute.
     * 
     * @param uri
     *            Namespace URI.
     * @param localName
     *            Local name.
     * @return The type of an attribute.
     */
    public String getType(final String uri, final String localName) {
        final BlancoXmlAttribute attrFound = findByUriLocalName(uri, localName);
        if (attrFound == null) {
            // Couldn't find it.
            return null;
        }

        return attrFound.getType();
    }

    /**
     * Searches for the type of an attribute.
     * 
     * @param qName
     *            Qualified name.
     * @return The type of an attribute.
     */
    public String getType(final String qName) {
        final BlancoXmlAttribute attrFound = findByQName(qName);
        if (attrFound == null) {
            // Couldn't find it.
            return null;
        }

        return attrFound.getType();
    }

    /**
     * Searches for the value of an attribute.
     * 
     * @param uri
     *            Namespace URI.
     * @param localName
     *            Local name.
     * @return The value of an attribute.
     */
    public String getValue(final String uri, final String localName) {
        final BlancoXmlAttribute attrFound = findByUriLocalName(uri, localName);
        if (attrFound == null) {
            // Couldn't find it.
            return null;
        }

        return attrFound.getValue();
    }

    /**
     * Searches for the value of an attribute.
     * 
     * @param qName
     *            Qualified name.
     * @return The value of an attribute.
     */
    public String getValue(final String qName) {
        final BlancoXmlAttribute attrFound = findByQName(qName);
        if (attrFound == null) {
            // Couldn't find it.
            return null;
        }

        return attrFound.getValue();
    }

    /**
     * A specially prepared method for exposing the internals.
     * 
     * Normally, this method is not used.
     * 
     * @return Attribute list.
     */
    public List<BlancoXmlAttribute> getList() {
        return fAttrs;
    }

    /**
     * Gets the attribute in the specified index.
     * 
     * @param index
     *            Attribute index.
     * @return An attribute. Returns null if the specified index is out of range.
     */
    private BlancoXmlAttribute getAttr(int index) {
        if (index >= fAttrs.size()) {
            return null;
        }

        return (BlancoXmlAttribute) fAttrs.get(index);
    }

    /**
     * Searches for an attribute using namespace URI and local name.
     * 
     * @param uri
     *            Namespace URI.
     * @param localName
     *            Local name.
     * @return An attribute.
     */
    private BlancoXmlAttribute findByUriLocalName(final String uri,
            final String localName) {
        final int attrSize = fAttrs.size();
        for (int index = 0; index < attrSize; index++) {
            final BlancoXmlAttribute attrLook = (BlancoXmlAttribute) fAttrs
                    .get(index);
            if (BlancoStringUtil.null2Blank(attrLook.getUri()).equals(uri)
                    && BlancoStringUtil.null2Blank(attrLook.getLocalName())
                            .equals(localName)) {
                return attrLook;
            }
        }

        // Couldn't find it.
        return null;
    }

    /**
     * Searches for an attribute using thier qualified name.
     * 
     * @param qName
     *            Qualified name.
     * @return An attribute.
     */
    private BlancoXmlAttribute findByQName(final String qName) {
        final int attrSize = fAttrs.size();
        for (int index = 0; index < attrSize; index++) {
            final BlancoXmlAttribute attrLook = (BlancoXmlAttribute) fAttrs
                    .get(index);
            if (BlancoStringUtil.null2Blank(attrLook.getUri()).equals(qName)) {
                return attrLook;
            }
        }

        // Couldn't find it.
        return null;
    }
}
