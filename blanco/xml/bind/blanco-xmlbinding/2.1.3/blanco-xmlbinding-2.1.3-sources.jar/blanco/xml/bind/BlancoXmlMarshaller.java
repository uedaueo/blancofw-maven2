/*
 * blanco Framework
 * Copyright (C) 2004-2009 IGA Tosiki
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 */
/*******************************************************************************
 * Copyright (c) 2009 IGA Tosiki, NTT DATA BUSINESS BRAINS Corp.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    IGA Tosiki (NTT DATA BUSINESS BRAINS Corp.) - initial API and implementation
 *******************************************************************************/
package blanco.xml.bind;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.sax.SAXTransformerFactory;
import javax.xml.transform.sax.TransformerHandler;
import javax.xml.transform.stream.StreamResult;

import org.xml.sax.SAXException;

import blanco.commons.util.BlancoStringUtil;
import blanco.xml.bind.valueobject.BlancoXmlDocument;

/**
 * This is a class for generating XML from the value object representation of blancoXmlBinding.
 * 
 * This class is part of the XML/value object mapping (X/O mapping) blancoXmlBinding.
 * 
 * @author IGA Tosiki
 */
public class BlancoXmlMarshaller {
    /**
     * SAX handler for output to be used internally.
     * 
     * The concatenated stream needs to be closed or otherwise processed externally.
     */
    private TransformerHandler fSaxHandler;

    /**
     * Generates XML from Java objects.
     * 
     * @param document
     *            An object as blancoXml.
     * @param outFile
     *            Output XML file.
     */
    public void marshal(final BlancoXmlDocument document, final File outFile) {
        if (document == null) {
            throw new IllegalArgumentException(
                    "BlancoXmlMarshaller#marshal: The input XML document was given as null.");
        }
        if (outFile == null) {
            throw new IllegalArgumentException(
                    "BlancoXmlMarshaller#marshal: The output XML file was given as null.");
        }
        if (outFile.exists()) {
            if (outFile.canWrite() == false) {
                throw new IllegalArgumentException("The output XML file["
                        + outFile.getName() + "] cannot be written.");
            }
        }

        try {
            final OutputStream outStream = new BufferedOutputStream(
                    new FileOutputStream(outFile));
            try {
                marshal(document, outStream);

                outStream.flush();
            } finally {
                outStream.close();
            }
        } catch (IOException ex) {
            throw new IllegalArgumentException(
                    "BlancoXmlMarshaller#marshal: Failed to output file."
                            + ex.toString(), ex);
        }
    }

    /**
     * Generates XML from Java objects.
     * 
     * Reference:
     * http://java.sun.com/webservices/docs/1.6/api/javax/xml/bind/Marshaller.html
     * 
     * @param document
     *            An object as blancoXml.
     * @param outStream
     *            XML output destination stream.
     */
    public void marshal(final BlancoXmlDocument document,
            final OutputStream outStream) {
        final TransformerFactory tf = TransformerFactory.newInstance();
        final SAXTransformerFactory saxTf = (SAXTransformerFactory) tf;
        try {
            fSaxHandler = saxTf.newTransformerHandler();
            if (BlancoStringUtil.null2Blank(document.getVersion()).length() > 0) {
                fSaxHandler.getTransformer().setOutputProperty("version",
                        document.getVersion());
            }
            if (BlancoStringUtil.null2Blank(document.getEncoding()).length() > 0) {
                fSaxHandler.getTransformer().setOutputProperty("encoding",
                        document.getEncoding());
            }
        } catch (TransformerConfigurationException e) {
            throw new IllegalArgumentException(
                    "BlancoXmlMarshaller#marshal: Failed to generate transformer handler.: "
                            + e.toString(), e);
        }

        fSaxHandler.setResult(new StreamResult(outStream));

        try {
            new BlancoXmlMarshallerSerializer(fSaxHandler).serialize(document);
        } catch (SAXException e) {
            throw new IllegalArgumentException(
                    "BlancoXmlMarshaller#marshal: An exception has occurred during the object to XML conversion process.: "
                            + e.toString(), e);
        }

        // Finally, releases the handler.
        fSaxHandler = null;
    }
}
