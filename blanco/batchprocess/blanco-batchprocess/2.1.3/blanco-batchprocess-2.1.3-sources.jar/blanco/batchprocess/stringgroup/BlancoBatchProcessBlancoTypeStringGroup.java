package blanco.batchprocess.stringgroup;

/**
 * サポートするblanco型の一覧をあらわします。
 */
public class BlancoBatchProcessBlancoTypeStringGroup {
    /**
     * No.1 説明:文字列。
     */
    public static final int BLANCO_STRING = 1;

    /**
     * No.2 説明:整数(int)。
     */
    public static final int BLANCO_INT = 2;

    /**
     * No.3 説明:整数(long)。
     */
    public static final int BLANCO_LONG = 3;

    /**
     * No.4 説明:数値(decimal)。
     */
    public static final int BLANCO_DECIMAL = 4;

    /**
     * No.5 説明:真偽。
     */
    public static final int BLANCO_BOOLEAN = 5;

    /**
     * Undefined. A string or constant other than a string group that is undefined.
     */
    public static final int NOT_DEFINED = -1;

    /**
     * Determines if a string is part of a string group.
     *
     * @param argCheck A string to be checked.
     * @return true is the string is part of a string group, false otherwise.
     */
    public boolean match(final String argCheck) {
        // No.1
        // 説明:文字列。
        if ("blanco:string".equals(argCheck)) {
            return true;
        }
        // No.2
        // 説明:整数(int)。
        if ("blanco:int".equals(argCheck)) {
            return true;
        }
        // No.3
        // 説明:整数(long)。
        if ("blanco:long".equals(argCheck)) {
            return true;
        }
        // No.4
        // 説明:数値(decimal)。
        if ("blanco:decimal".equals(argCheck)) {
            return true;
        }
        // No.5
        // 説明:真偽。
        if ("blanco:boolean".equals(argCheck)) {
            return true;
        }
        return false;
    }

    /**
     * Determines if a string is part of a string group in a case-insentive manner.
     *
     * @param argCheck A string to be checked.
     * @return true is the string is part of a string group, false otherwise.
     */
    public boolean matchIgnoreCase(final String argCheck) {
        // No.1
        // 説明:文字列。
        if ("blanco:string".equalsIgnoreCase(argCheck)) {
            return true;
        }
        // No.2
        // 説明:整数(int)。
        if ("blanco:int".equalsIgnoreCase(argCheck)) {
            return true;
        }
        // No.3
        // 説明:整数(long)。
        if ("blanco:long".equalsIgnoreCase(argCheck)) {
            return true;
        }
        // No.4
        // 説明:数値(decimal)。
        if ("blanco:decimal".equalsIgnoreCase(argCheck)) {
            return true;
        }
        // No.5
        // 説明:真偽。
        if ("blanco:boolean".equalsIgnoreCase(argCheck)) {
            return true;
        }
        return false;
    }

    /**
     * Converts a string to a constant.
     *
     * Returns NOT_DEFINED if the constant is undefined or if the given string is outside the string group.
     *
     * @param argCheck A string to be converted.
     * @return The value after conversion to a constant.
     */
    public int convertToInt(final String argCheck) {
        // No.1
        // 説明:文字列。
        if ("blanco:string".equals(argCheck)) {
            return BLANCO_STRING;
        }
        // No.2
        // 説明:整数(int)。
        if ("blanco:int".equals(argCheck)) {
            return BLANCO_INT;
        }
        // No.3
        // 説明:整数(long)。
        if ("blanco:long".equals(argCheck)) {
            return BLANCO_LONG;
        }
        // No.4
        // 説明:数値(decimal)。
        if ("blanco:decimal".equals(argCheck)) {
            return BLANCO_DECIMAL;
        }
        // No.5
        // 説明:真偽。
        if ("blanco:boolean".equals(argCheck)) {
            return BLANCO_BOOLEAN;
        }

        // No matching constants were found.
        return NOT_DEFINED;
    }

    /**
     * Converts a constant to a string.
     *
     * Converts to a string corresponding to a constant.
     *
     * @param argCheck A constant to be converted.
     * @return The value after conversion to a string, or a zero-length string if NOT_DEFINED.
     */
    public String convertToString(final int argCheck) {
        // No.1
        // 説明:文字列。
        if (argCheck == BLANCO_STRING) {
            return "blanco:string";
        }
        // No.2
        // 説明:整数(int)。
        if (argCheck == BLANCO_INT) {
            return "blanco:int";
        }
        // No.3
        // 説明:整数(long)。
        if (argCheck == BLANCO_LONG) {
            return "blanco:long";
        }
        // No.4
        // 説明:数値(decimal)。
        if (argCheck == BLANCO_DECIMAL) {
            return "blanco:decimal";
        }
        // No.5
        // 説明:真偽。
        if (argCheck == BLANCO_BOOLEAN) {
            return "blanco:boolean";
        }
        // Undefined.
        if (argCheck == NOT_DEFINED) {
            return "";
        }

        // None of them were applicable.
        throw new IllegalArgumentException("The given value (" + argCheck + ") is a value that is not defined in the string group [BlancoBatchProcessBlancoType].");
    }
}
