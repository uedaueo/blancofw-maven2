package blanco.valueobjectphp;

import blanco.cg.BlancoCgSupportedLang;
import blanco.commons.util.BlancoNameUtil;
import blanco.commons.util.BlancoStringUtil;
import blanco.valueobjectphp.resourcebundle.BlancoValueObjectPhpResourceBundle;
import blanco.valueobjectphp.valueobject.BlancoValueObjectPhpFieldStructure;
import blanco.valueobjectphp.valueobject.BlancoValueObjectPhpStructure;
import blanco.xml.bind.BlancoXmlBindingUtil;
import blanco.xml.bind.BlancoXmlUnmarshaller;
import blanco.xml.bind.valueobject.BlancoXmlAttribute;
import blanco.xml.bind.valueobject.BlancoXmlDocument;
import blanco.xml.bind.valueobject.BlancoXmlElement;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class BlancoValueObjectPhpXmlParser {

    /**
     * Resource bundle object for blancoValueObject.
     */
    private final static BlancoValueObjectPhpResourceBundle fBundle = new BlancoValueObjectPhpResourceBundle();

    public static Map<String, Integer> mapCommons = new HashMap<String, Integer>() {
        {put(fBundle.getMeta2xmlElementCommon(), BlancoCgSupportedLang.JAVA);}
        {put(fBundle.getMeta2xmlElementCommonCs(), BlancoCgSupportedLang.CS);}
        {put(fBundle.getMeta2xmlElementCommonJs(), BlancoCgSupportedLang.JS);}
        {put(fBundle.getMeta2xmlElementCommonVb(), BlancoCgSupportedLang.VB);}
        {put(fBundle.getMeta2xmlElementCommonPhp(), BlancoCgSupportedLang.PHP8);}
        {put(fBundle.getMeta2xmlElementCommonRuby(), BlancoCgSupportedLang.RUBY);}
        {put(fBundle.getMeta2xmlElementCommonPython(), BlancoCgSupportedLang.PYTHON);}
        {put(fBundle.getMeta2xmlElementCommonKt(), BlancoCgSupportedLang.KOTLIN);}
        {put(fBundle.getMeta2xmlElementCommonTs(), BlancoCgSupportedLang.TS);}
    };

    /**
     * Parses an XML document in an intermediate XML file to get an array of information.
     *
     * @param argMetaXmlSourceFile
     *            An intermediate XML file.
     * @return An array of information obtained as a result of parsing.
     */
    public BlancoValueObjectPhpStructure[] parse(
            final File argMetaXmlSourceFile) {
        final BlancoXmlDocument documentMeta = new BlancoXmlUnmarshaller()
                .unmarshal(argMetaXmlSourceFile);
        if (documentMeta == null) {
            return null;
        }

        return parse(documentMeta);
    }

    /**
     * Parses an XML document in an intermediate XML file to get an array of value object information.
     *
     * @param argXmlDocument
     *            XML document of an intermediate XML file.
     * @return An array of value object information obtained as a result of parsing.
     */
    public BlancoValueObjectPhpStructure[] parse(
            final BlancoXmlDocument argXmlDocument) {
        final List<BlancoValueObjectPhpStructure> listStructure = new ArrayList<>();

        // Gets the root element.
        final BlancoXmlElement elementRoot = BlancoXmlBindingUtil
                .getDocumentElement(argXmlDocument);
        if (elementRoot == null) {
            // The process is aborted if there is no root element.
            return null;
        }

        // Gets a list of sheets (Excel sheets).
        final List<BlancoXmlElement> listSheet = BlancoXmlBindingUtil
                .getElementsByTagName(elementRoot, "sheet");

        final int sizeListSheet = listSheet.size();
        for (int index = 0; index < sizeListSheet; index++) {
            final BlancoXmlElement elementSheet = listSheet.get(index);

            /*
             * Supports sheets written for languages other than Java.
             */
            List<BlancoXmlElement> listCommon = null;
            int sheetLang = BlancoCgSupportedLang.JAVA;
            for (String common : mapCommons.keySet()) {
                listCommon = BlancoXmlBindingUtil
                        .getElementsByTagName(elementSheet,
                                common);
                if (listCommon.size() != 0) {
                    BlancoXmlAttribute attr = new BlancoXmlAttribute();
                    attr.setType("CDATA");
                    attr.setQName("style");
                    attr.setLocalName("style");

                    sheetLang = mapCommons.get(common);
                    attr.setValue(new BlancoCgSupportedLang().convertToString(sheetLang));

                    elementSheet.getAtts().add(attr);

                    /* tueda DEBUG */
                    if (BlancoValueObjectPhpUtil.isVerbose) {
                        System.out.println("/* tueda */ style = " + BlancoXmlBindingUtil.getAttribute(elementSheet, "style"));
                    }

                    break;
                }
            }

            if (listCommon == null || listCommon.size() == 0) {
                // Skips if there is no common.
                continue;
            }

            // Processes only the first item.
            final BlancoXmlElement elementCommon = listCommon.get(0);
            final String name = BlancoXmlBindingUtil.getTextContent(
                    elementCommon, "name");
            if (BlancoStringUtil.null2Blank(name).trim().length() == 0) {
                continue;
            }

            BlancoValueObjectPhpStructure objClassStructure = null;
            switch (sheetLang) {
                case BlancoCgSupportedLang.PHP8:
                    objClassStructure = parseElementSheet(elementSheet);
                    /* NOT YET SUPPORT ANOTHER LANGUAGES */
            }

            if (objClassStructure != null) {
                // Memorizes the obtained information.
                listStructure.add(objClassStructure);
            }
        }

        final BlancoValueObjectPhpStructure[] result = new BlancoValueObjectPhpStructure[listStructure
                .size()];
        listStructure.toArray(result);
        return result;
    }

    /**
     * Parse a Sheet
     *
     * @param argElementSheet
     * @return
     */
    public BlancoValueObjectPhpStructure parseElementSheet(
            final BlancoXmlElement argElementSheet) {

        final BlancoValueObjectPhpStructure objClassStructure = new BlancoValueObjectPhpStructure();
        final List<BlancoXmlElement> listCommon = BlancoXmlBindingUtil
                .getElementsByTagName(argElementSheet,
                        "blancovalueobjectphp-common");
        if (listCommon == null || listCommon.size() == 0) {
            // Skips if there is no common.
            return null;
        }

        // Remember whether to generate toJSON or not.
        objClassStructure.setGenerateToJson(BlancoValueObjectPhpUtil.generateToJson);
        objClassStructure.setGenerateToArray(BlancoValueObjectPhpUtil.generateToArray);
        objClassStructure.setApiTelegram(BlancoValueObjectPhpUtil.apiTelegram);
        objClassStructure.setGenerateForRestApi(BlancoValueObjectPhpUtil.generateForRestApi);

        /* parse elementCommon */
        final BlancoXmlElement elementCommon = listCommon.get(0);
        parseElementCommon(elementCommon, objClassStructure);

        if (BlancoStringUtil.null2Blank(objClassStructure.getName()).trim()
                .length() == 0) {
            // Skips if name is empty.
            return null;
        }

        /* parse elementExtends */
        final List<BlancoXmlElement> extendsList = BlancoXmlBindingUtil
                .getElementsByTagName(argElementSheet,
                        "blancovalueobjectphp-extends");
        if (extendsList != null && extendsList.size() != 0) {
            final BlancoXmlElement elementExtendsRoot = extendsList.get(0);
            String className = BlancoXmlBindingUtil.getTextContent(elementExtendsRoot, "name");
            String name = BlancoXmlBindingUtil
                    .getTextContent(elementExtendsRoot, "name");
            String mypackage = BlancoXmlBindingUtil
                    .getTextContent(elementExtendsRoot, "package");
            if (name != null) {
                String namespace = name;
                if (mypackage != null) {
                    namespace = mypackage + "\\" + namespace;
                }
                objClassStructure.setExtends(namespace);
            }
        }

        /* parse filed list */
        final List<BlancoXmlElement> listList = BlancoXmlBindingUtil
                .getElementsByTagName(argElementSheet, "blancovalueobjectphp-list");
        if (listList != null && listList.size() != 0) {
            final BlancoXmlElement elementListRoot = listList.get(0);
            parseElementList(elementListRoot, objClassStructure);
        }

        return objClassStructure;
    }

    /**
     *
     *
     * @param argElementList
     * @param argObjClassStructure
     */
    private void parseElementList(
            final BlancoXmlElement argElementList,
            final BlancoValueObjectPhpStructure argObjClassStructure
    ) {
        final List<BlancoXmlElement> listField = BlancoXmlBindingUtil
                .getElementsByTagName(argElementList, "field");
        for (int indexField = 0; indexField < listField.size(); indexField++) {
            final Object nodeField = listField.get(indexField);

            if (nodeField instanceof BlancoXmlElement == false) {
                continue;
            }

            final BlancoXmlElement elementField = (BlancoXmlElement) nodeField;
            BlancoValueObjectPhpFieldStructure field = new BlancoValueObjectPhpFieldStructure();
            field
                    .setNo(BlancoXmlBindingUtil.getTextContent(elementField,
                            "no"));

            field.setName(BlancoXmlBindingUtil.getTextContent(elementField,
                    "name"));
            if (BlancoStringUtil.null2Blank(field.getName()).length() == 0) {
                continue;
            }

            // 既に同じ内容が登録されていないかどうかのチェック。
            for (int indexPast = 0; indexPast < argObjClassStructure.getListField()
                    .size(); indexPast++) {
                final BlancoValueObjectPhpFieldStructure fieldPast = argObjClassStructure
                        .getListField().get(indexPast);
                if (fieldPast.getName().equals(field.getName())) {
                    throw new IllegalArgumentException(
                            fBundle.getXml2sourceFileErr003(argObjClassStructure
                                    .getName(), field.getName()));
                }
            }


            String strType = BlancoXmlBindingUtil.getTextContent(elementField,
                    "type");
            if (BlancoStringUtil.null2Blank(strType).isEmpty()) {
                // ここで異常終了。
                continue;
            }
            field.setType(BlancoValueObjectPhpUtil.convertType(strType, argObjClassStructure));

            String strGeneric = BlancoXmlBindingUtil.getTextContent(elementField,
                    "generic");
            if (!BlancoStringUtil.null2Blank(strGeneric).isEmpty()) {
                field.setGeneric(BlancoValueObjectPhpUtil.convertType(strGeneric, argObjClassStructure));
            }

            /* debug */
            if (BlancoStringUtil.null2Blank(field.getGeneric()).length() != 0) {
                System.out.println("/* tueda */ generic = " + field.getGeneric());
            }

            String strFieldRequired = BlancoXmlBindingUtil.getTextContent(
                    elementField, "fieldRequired");
            field.setFieldRequired("true".equalsIgnoreCase(strFieldRequired));

            field.setDefault(BlancoXmlBindingUtil.getTextContent(elementField,
                    "default"));
            field.setDefaultPhp(BlancoXmlBindingUtil.getTextContent(elementField, "defaultPhp"));
            String strFieldExcludeToArray = BlancoXmlBindingUtil.getTextContent(elementField, "excludeToArray");
            field.setExcludeToArray("true".equalsIgnoreCase(strFieldExcludeToArray));

            try {
                String strMinLength = BlancoXmlBindingUtil.getTextContent(
                        elementField, "minLength");
                field.setMinLength(Integer.parseInt(strMinLength));

                /* debug */
                if (BlancoStringUtil.null2Blank(strMinLength).length() != 0) {
                    System.out.println("/* ama */ minLength = " + field.getMinLength());
                }

                String strMaxLength = BlancoXmlBindingUtil.getTextContent(
                        elementField, "maxLength");
                field.setMaxLength(Integer.parseInt(strMaxLength));
            } catch (NumberFormatException e) {
                // 値がセットされていなかったり数値でなかった場合は無視
            }

            field.setMinInclusive(BlancoXmlBindingUtil.getTextContent(
                    elementField, "minInclusive"));
            field.setMaxInclusive(BlancoXmlBindingUtil.getTextContent(
                    elementField, "maxInclusive"));

            field.setPattern(BlancoXmlBindingUtil.getTextContent(
                    elementField, "pattern"));

            field.setDescription(BlancoXmlBindingUtil.getTextContent(
                    elementField, "description"));

            argObjClassStructure.getListField().add(field);
        }
    }

    private void parseElementCommon(
            final BlancoXmlElement argElementCommon,
            final BlancoValueObjectPhpStructure argObjClassStructure
    ) {
        argObjClassStructure.setName(BlancoXmlBindingUtil.getTextContent(
                argElementCommon, "name"));
        String myNamespace = BlancoXmlBindingUtil.getTextContent(
                argElementCommon, "namespace");
        if (myNamespace == null) {
            myNamespace = "";
        }
        argObjClassStructure.setNamespace(myNamespace);

        String myPackage = BlancoXmlBindingUtil.getTextContent(argElementCommon,"package");
        if (myPackage == null) {
            myPackage = "";
        }
        argObjClassStructure.setPackage(myPackage);

        argObjClassStructure.setDescription(BlancoXmlBindingUtil.getTextContent(
                argElementCommon, "description"));
        if (BlancoStringUtil.null2Blank(argObjClassStructure.getDescription())
                .length() > 0) {
            final String[] lines = BlancoNameUtil.splitString(argObjClassStructure
                    .getDescription(), '\n');
            for (int index = 0; index < lines.length; index++) {
                if (index == 0) {
                    argObjClassStructure.setDescription(lines[index]);
                } else {
                    // For a multi-line description, it will be split and stored.
                    // From the second line, assumes that character reference encoding has been properly implemented.
                    argObjClassStructure.getDescriptionList().add(lines[index]);
                }
            }
        }

        if (BlancoXmlBindingUtil.getTextContent(argElementCommon,
                "fileDescription") != null) {
            argObjClassStructure.setFileDescription(BlancoXmlBindingUtil
                    .getTextContent(argElementCommon, "fileDescription"));
        }

        String strAccess = BlancoXmlBindingUtil.getTextContent(argElementCommon, "access");
        if (!BlancoStringUtil.null2Blank(strAccess).isEmpty()) {
            argObjClassStructure.setAccess(strAccess);
        }

        String strAbstract = BlancoXmlBindingUtil.getTextContent(argElementCommon, "abstract");
        if (!BlancoStringUtil.null2Blank(strAbstract).isEmpty()) {
            argObjClassStructure.setAbstract("true".equalsIgnoreCase(strAbstract));
        }

        String strImport = BlancoXmlBindingUtil.getTextContent(argElementCommon, "createImportList");
        if (!BlancoStringUtil.null2Blank(strImport).isEmpty()) {
            argObjClassStructure.setCreateImportList("true".equalsIgnoreCase(strImport));
        }
    }
}
