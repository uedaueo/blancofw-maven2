package blanco.valueobjectphp.valueobject;

/**
 * BlancoValueObjectPhpのなかで利用されるValueObjectです。
 */
public class BlancoValueObjectPhpFieldStructure {
    /**
     * 項目番号。省略可能です。
     *
     * フィールド: [no]。
     */
    private String fNo;

    /**
     * フィールド名を指定します。必須項目です。
     *
     * フィールド: [name]。
     */
    private String fName;

    /**
     * 型名をパッケージ名のフル修飾付で指定します。必須項目です。
     *
     * フィールド: [type]。
     */
    private String fType;

    /**
     * フィールドの別名を指定します。
     *
     * フィールド: [alias]。
     */
    private String fAlias;

    /**
     * 型が期待する総称型の具体的な型名を指定します．
     *
     * フィールド: [generic]。
     */
    private String fGeneric;

    /**
     * 必須項目の場合はtrue
     *
     * フィールド: [fieldRequired]。
     */
    private Boolean fFieldRequired;

    /**
     * trueの場合はtoArrayから除外
     *
     * フィールド: [excludeToArray]。
     */
    private Boolean fExcludeToArray;

    /**
     * デフォルト値を指定します。
     *
     * フィールド: [default]。
     */
    private String fDefault;

    /**
     * デフォルト値を指定します。
     *
     * フィールド: [defaultPhp]。
     */
    private String fDefaultPhp;

    /**
     * 長さmin
     *
     * フィールド: [minLength]。
     */
    private Integer fMinLength;

    /**
     * 長さmax
     *
     * フィールド: [maxLength]。
     */
    private Integer fMaxLength;

    /**
     * 値範囲min
     *
     * フィールド: [minInclusive]。
     */
    private String fMinInclusive;

    /**
     * 値範囲max
     *
     * フィールド: [maxInclusive]。
     */
    private String fMaxInclusive;

    /**
     * 形式Check正規表現
     *
     * フィールド: [pattern]。
     */
    private String fPattern;

    /**
     * フィールドへの説明を指定します。
     *
     * フィールド: [description]。
     */
    private String fDescription;

    /**
     * フィールド [no] の値を設定します。
     *
     * フィールドの説明: [項目番号。省略可能です。]。
     *
     * @param argNo フィールド[no]に設定する値。
     */
    public void setNo(final String argNo) {
        fNo = argNo;
    }

    /**
     * フィールド [no] の値を取得します。
     *
     * フィールドの説明: [項目番号。省略可能です。]。
     *
     * @return フィールド[no]から取得した値。
     */
    public String getNo() {
        return fNo;
    }

    /**
     * フィールド [name] の値を設定します。
     *
     * フィールドの説明: [フィールド名を指定します。必須項目です。]。
     *
     * @param argName フィールド[name]に設定する値。
     */
    public void setName(final String argName) {
        fName = argName;
    }

    /**
     * フィールド [name] の値を取得します。
     *
     * フィールドの説明: [フィールド名を指定します。必須項目です。]。
     *
     * @return フィールド[name]から取得した値。
     */
    public String getName() {
        return fName;
    }

    /**
     * フィールド [type] の値を設定します。
     *
     * フィールドの説明: [型名をパッケージ名のフル修飾付で指定します。必須項目です。]。
     *
     * @param argType フィールド[type]に設定する値。
     */
    public void setType(final String argType) {
        fType = argType;
    }

    /**
     * フィールド [type] の値を取得します。
     *
     * フィールドの説明: [型名をパッケージ名のフル修飾付で指定します。必須項目です。]。
     *
     * @return フィールド[type]から取得した値。
     */
    public String getType() {
        return fType;
    }

    /**
     * フィールド [alias] の値を設定します。
     *
     * フィールドの説明: [フィールドの別名を指定します。]。
     *
     * @param argAlias フィールド[alias]に設定する値。
     */
    public void setAlias(final String argAlias) {
        fAlias = argAlias;
    }

    /**
     * フィールド [alias] の値を取得します。
     *
     * フィールドの説明: [フィールドの別名を指定します。]。
     *
     * @return フィールド[alias]から取得した値。
     */
    public String getAlias() {
        return fAlias;
    }

    /**
     * フィールド [generic] の値を設定します。
     *
     * フィールドの説明: [型が期待する総称型の具体的な型名を指定します．]。
     *
     * @param argGeneric フィールド[generic]に設定する値。
     */
    public void setGeneric(final String argGeneric) {
        fGeneric = argGeneric;
    }

    /**
     * フィールド [generic] の値を取得します。
     *
     * フィールドの説明: [型が期待する総称型の具体的な型名を指定します．]。
     *
     * @return フィールド[generic]から取得した値。
     */
    public String getGeneric() {
        return fGeneric;
    }

    /**
     * フィールド [fieldRequired] の値を設定します。
     *
     * フィールドの説明: [必須項目の場合はtrue]。
     *
     * @param argFieldRequired フィールド[fieldRequired]に設定する値。
     */
    public void setFieldRequired(final Boolean argFieldRequired) {
        fFieldRequired = argFieldRequired;
    }

    /**
     * フィールド [fieldRequired] の値を取得します。
     *
     * フィールドの説明: [必須項目の場合はtrue]。
     *
     * @return フィールド[fieldRequired]から取得した値。
     */
    public Boolean getFieldRequired() {
        return fFieldRequired;
    }

    /**
     * フィールド [excludeToArray] の値を設定します。
     *
     * フィールドの説明: [trueの場合はtoArrayから除外]。
     *
     * @param argExcludeToArray フィールド[excludeToArray]に設定する値。
     */
    public void setExcludeToArray(final Boolean argExcludeToArray) {
        fExcludeToArray = argExcludeToArray;
    }

    /**
     * フィールド [excludeToArray] の値を取得します。
     *
     * フィールドの説明: [trueの場合はtoArrayから除外]。
     *
     * @return フィールド[excludeToArray]から取得した値。
     */
    public Boolean getExcludeToArray() {
        return fExcludeToArray;
    }

    /**
     * フィールド [default] の値を設定します。
     *
     * フィールドの説明: [デフォルト値を指定します。]。
     *
     * @param argDefault フィールド[default]に設定する値。
     */
    public void setDefault(final String argDefault) {
        fDefault = argDefault;
    }

    /**
     * フィールド [default] の値を取得します。
     *
     * フィールドの説明: [デフォルト値を指定します。]。
     *
     * @return フィールド[default]から取得した値。
     */
    public String getDefault() {
        return fDefault;
    }

    /**
     * フィールド [defaultPhp] の値を設定します。
     *
     * フィールドの説明: [デフォルト値を指定します。]。
     *
     * @param argDefaultPhp フィールド[defaultPhp]に設定する値。
     */
    public void setDefaultPhp(final String argDefaultPhp) {
        fDefaultPhp = argDefaultPhp;
    }

    /**
     * フィールド [defaultPhp] の値を取得します。
     *
     * フィールドの説明: [デフォルト値を指定します。]。
     *
     * @return フィールド[defaultPhp]から取得した値。
     */
    public String getDefaultPhp() {
        return fDefaultPhp;
    }

    /**
     * フィールド [minLength] の値を設定します。
     *
     * フィールドの説明: [長さmin]。
     *
     * @param argMinLength フィールド[minLength]に設定する値。
     */
    public void setMinLength(final Integer argMinLength) {
        fMinLength = argMinLength;
    }

    /**
     * フィールド [minLength] の値を取得します。
     *
     * フィールドの説明: [長さmin]。
     *
     * @return フィールド[minLength]から取得した値。
     */
    public Integer getMinLength() {
        return fMinLength;
    }

    /**
     * フィールド [maxLength] の値を設定します。
     *
     * フィールドの説明: [長さmax]。
     *
     * @param argMaxLength フィールド[maxLength]に設定する値。
     */
    public void setMaxLength(final Integer argMaxLength) {
        fMaxLength = argMaxLength;
    }

    /**
     * フィールド [maxLength] の値を取得します。
     *
     * フィールドの説明: [長さmax]。
     *
     * @return フィールド[maxLength]から取得した値。
     */
    public Integer getMaxLength() {
        return fMaxLength;
    }

    /**
     * フィールド [minInclusive] の値を設定します。
     *
     * フィールドの説明: [値範囲min]。
     *
     * @param argMinInclusive フィールド[minInclusive]に設定する値。
     */
    public void setMinInclusive(final String argMinInclusive) {
        fMinInclusive = argMinInclusive;
    }

    /**
     * フィールド [minInclusive] の値を取得します。
     *
     * フィールドの説明: [値範囲min]。
     *
     * @return フィールド[minInclusive]から取得した値。
     */
    public String getMinInclusive() {
        return fMinInclusive;
    }

    /**
     * フィールド [maxInclusive] の値を設定します。
     *
     * フィールドの説明: [値範囲max]。
     *
     * @param argMaxInclusive フィールド[maxInclusive]に設定する値。
     */
    public void setMaxInclusive(final String argMaxInclusive) {
        fMaxInclusive = argMaxInclusive;
    }

    /**
     * フィールド [maxInclusive] の値を取得します。
     *
     * フィールドの説明: [値範囲max]。
     *
     * @return フィールド[maxInclusive]から取得した値。
     */
    public String getMaxInclusive() {
        return fMaxInclusive;
    }

    /**
     * フィールド [pattern] の値を設定します。
     *
     * フィールドの説明: [形式Check正規表現]。
     *
     * @param argPattern フィールド[pattern]に設定する値。
     */
    public void setPattern(final String argPattern) {
        fPattern = argPattern;
    }

    /**
     * フィールド [pattern] の値を取得します。
     *
     * フィールドの説明: [形式Check正規表現]。
     *
     * @return フィールド[pattern]から取得した値。
     */
    public String getPattern() {
        return fPattern;
    }

    /**
     * フィールド [description] の値を設定します。
     *
     * フィールドの説明: [フィールドへの説明を指定します。]。
     *
     * @param argDescription フィールド[description]に設定する値。
     */
    public void setDescription(final String argDescription) {
        fDescription = argDescription;
    }

    /**
     * フィールド [description] の値を取得します。
     *
     * フィールドの説明: [フィールドへの説明を指定します。]。
     *
     * @return フィールド[description]から取得した値。
     */
    public String getDescription() {
        return fDescription;
    }

    /**
     * Gets the string representation of this value object.
     *
     * <P>Precautions for use</P>
     * <UL>
     * <LI>Only the shallow range of the object will be subject to the stringification process.
     * <LI>Do not use this method if the object has a circular reference.
     * </UL>
     *
     * @return String representation of a value object.
     */
    @Override
    public String toString() {
        final StringBuffer buf = new StringBuffer();
        buf.append("blanco.valueobjectphp.valueobject.BlancoValueObjectPhpFieldStructure[");
        buf.append("no=" + fNo);
        buf.append(",name=" + fName);
        buf.append(",type=" + fType);
        buf.append(",alias=" + fAlias);
        buf.append(",generic=" + fGeneric);
        buf.append(",fieldRequired=" + fFieldRequired);
        buf.append(",excludeToArray=" + fExcludeToArray);
        buf.append(",default=" + fDefault);
        buf.append(",defaultPhp=" + fDefaultPhp);
        buf.append(",minLength=" + fMinLength);
        buf.append(",maxLength=" + fMaxLength);
        buf.append(",minInclusive=" + fMinInclusive);
        buf.append(",maxInclusive=" + fMaxInclusive);
        buf.append(",pattern=" + fPattern);
        buf.append(",description=" + fDescription);
        buf.append("]");
        return buf.toString();
    }

    /**
     * Copies this value object to the specified target.
     *
     * <P>Cautions for use</P>
     * <UL>
     * <LI>Only the shallow range of the object will be subject to the copying process.
     * <LI>Do not use this method if the object has a circular reference.
     * </UL>
     *
     * @param target target value object.
     */
    public void copyTo(final BlancoValueObjectPhpFieldStructure target) {
        if (target == null) {
            throw new IllegalArgumentException("Bug: BlancoValueObjectPhpFieldStructure#copyTo(target): argument 'target' is null");
        }

        // No needs to copy parent class.

        // Name: fNo
        // Type: java.lang.String
        target.fNo = this.fNo;
        // Name: fName
        // Type: java.lang.String
        target.fName = this.fName;
        // Name: fType
        // Type: java.lang.String
        target.fType = this.fType;
        // Name: fAlias
        // Type: java.lang.String
        target.fAlias = this.fAlias;
        // Name: fGeneric
        // Type: java.lang.String
        target.fGeneric = this.fGeneric;
        // Name: fFieldRequired
        // Type: java.lang.Boolean
        target.fFieldRequired = this.fFieldRequired;
        // Name: fExcludeToArray
        // Type: java.lang.Boolean
        target.fExcludeToArray = this.fExcludeToArray;
        // Name: fDefault
        // Type: java.lang.String
        target.fDefault = this.fDefault;
        // Name: fDefaultPhp
        // Type: java.lang.String
        target.fDefaultPhp = this.fDefaultPhp;
        // Name: fMinLength
        // Type: java.lang.Integer
        target.fMinLength = this.fMinLength;
        // Name: fMaxLength
        // Type: java.lang.Integer
        target.fMaxLength = this.fMaxLength;
        // Name: fMinInclusive
        // Type: java.lang.String
        target.fMinInclusive = this.fMinInclusive;
        // Name: fMaxInclusive
        // Type: java.lang.String
        target.fMaxInclusive = this.fMaxInclusive;
        // Name: fPattern
        // Type: java.lang.String
        target.fPattern = this.fPattern;
        // Name: fDescription
        // Type: java.lang.String
        target.fDescription = this.fDescription;
    }
}
