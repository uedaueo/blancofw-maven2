package blanco.valueobjectphp;

/**
 * BlancoValueObjectPhp が利用する定数を蓄えます。
 */
public class BlancoValueObjectPhpConstants {
    /**
     * 項目番号:1<br>
     * プロダクト名。英字で指定します。
     */
    public static final String PRODUCT_NAME = "blancoValueObjectPhp";

    /**
     * 項目番号:2<br>
     * プロダクト名の小文字版。英字で指定します。
     */
    public static final String PRODUCT_NAME_LOWER = "blancovalueobjectphp";

    /**
     * 項目番号:3<br>
     * バージョン番号。
     */
    public static final String VERSION = "3.0.0";

    /**
     * 項目番号:4<br>
     * 処理の過程で利用されるサブディレクトリ。
     */
    public static final String TARGET_SUBDIRECTORY = "/valueobjectphp";

    /**
     * 項目番号:5<br>
     * バリデーター arrayMinLengthのゲッターメソッド
     */
    public static final String API_VGETARRAYMINLENGTH_METHOD = "vgetArrayMinLength";

    /**
     * 項目番号:6<br>
     * バリデーター arrayMaxLengthのゲッターメソッド
     */
    public static final String API_VGETARRAYMAXLENGTH_METHOD = "vgetArrayMaxLength";

    /**
     * 項目番号:7<br>
     * バリデーター arrayMinInclusiveのゲッターメソッド
     */
    public static final String API_VGETARRAYMININCLUSIVE_METHOD = "vgetArrayMinInclusive";

    /**
     * 項目番号:8<br>
     * バリデーター arrayMaxInclusiveのゲッターメソッド
     */
    public static final String API_VGETARRAYMAXINCLUSIVE_METHOD = "vgetArrayMaxInclusive";

    /**
     * 項目番号:9<br>
     * バリデーター arrayPatternのゲッターメソッド
     */
    public static final String API_VGETARRAYPATTARN_METHOD = "vgetArrayPattern";

    /**
     * 項目番号:10<br>
     * バリデーター arrayFieldRequiredのゲッターメソッド
     */
    public static final String API_VGETARRAYFIELDREQUIRED_METHOD = "vgetArrayFieldRequired";

    /**
     * 項目番号:11<br>
     * targetdirに設定される文字列
     */
    public static final String TARGET_STYLE_BLANCO = "blanco";

    /**
     * 項目番号:12<br>
     * targetdirに設定される文字列
     */
    public static final String TARGET_STYLE_MAVEN = "maven";

    /**
     * 項目番号:13<br>
     * targetdirに設定される文字列
     */
    public static final String TARGET_STYLE_FREE = "free";

    /**
     * 項目番号:14<br>
     * 生成したソースコードを保管するディレクトリのsuffix
     */
    public static final String TARGET_DIR_SUFFIX_BLANCO = "main";

    /**
     * 項目番号:15<br>
     * 生成したソースコードを保管するディレクトリのsuffix
     */
    public static final String TARGET_DIR_SUFFIX_MAVEN = "main/php";
}
