package blanco.valueobjectphp;

import blanco.commons.util.BlancoStringUtil;
import blanco.valueobjectphp.resourcebundle.BlancoValueObjectPhpResourceBundle;
import blanco.valueobjectphp.valueobject.BlancoValueObjectPhpStructure;

import java.io.File;
import java.io.IOException;
import java.util.*;

public class BlancoValueObjectPhpUtil {
    static public boolean isVerbose = false;
    static public String encoding = "UTF-8";
    static public int tabs = 4;
    static public boolean generateToJson = false;
    static public boolean generateToArray = false;
    static public boolean generateForRestApi = false;
    static public String apiTelegram = null;
    static public String targetNamespace = "Blanco";
    private boolean isXmlRootElement = false;

    static public Map<String, BlancoValueObjectPhpStructure> objects = new HashMap<>();
    static public Map<String, List<String>> importHeaderList = new HashMap<>();

    /**
     * Resource bundle object for blancoValueObject.
     */
    static private final BlancoValueObjectPhpResourceBundle fBundle = new BlancoValueObjectPhpResourceBundle();

    static public void processValueObjects(
            final String baseTmpdir,
            final String searchTmpdirs,
            final Map<String, BlancoValueObjectPhpStructure> argObjects
    ) throws IOException {
        if (isVerbose) {
            System.out.println("BlancoValueObjectTsUtil : processValueObjects start !, tmpDir = " + baseTmpdir + ", serachTmpdir = " + searchTmpdirs);
        }

        if (argObjects == null) {
            throw new IllegalArgumentException(fBundle.getXml2sourceFileErr007());
        }

        /* searchTmpdir is comma separated. */
        List<String> searchTmpdirList = null;
        if (searchTmpdirs != null && !searchTmpdirs.equals(baseTmpdir)) {
            String[] searchTmpdirArray = searchTmpdirs.split(",");
            searchTmpdirList = new ArrayList<>(Arrays.asList(searchTmpdirArray));
        }
        if (searchTmpdirList == null) {
            searchTmpdirList = new ArrayList<>();
        }
        if (baseTmpdir != null) {
            searchTmpdirList.add(baseTmpdir);
        }

        for (String tmpdir : searchTmpdirList) {
            searchTmpdir(tmpdir.trim(), argObjects);
        }
    }

    static private void searchTmpdir(
            final String tmpdir,
            final Map<String, BlancoValueObjectPhpStructure> argObjects
    ) {

        // Reads information from XML-ized intermediate files.
        final File[] fileMeta3 = new File(tmpdir
                + BlancoValueObjectPhpConstants.TARGET_SUBDIRECTORY)
                .listFiles();

        if (fileMeta3 == null) {
            System.out.println("!!! NO FILES in " + tmpdir
                    + BlancoValueObjectPhpConstants.TARGET_SUBDIRECTORY);
            throw new IllegalArgumentException("!!! NO FILES in " + tmpdir
                    + BlancoValueObjectPhpConstants.TARGET_SUBDIRECTORY);
        }

        for (int index = 0; index < fileMeta3.length; index++) {
            if (fileMeta3[index].getName().endsWith(".xml") == false) {
                continue;
            }

            BlancoValueObjectPhpXmlParser parser = new BlancoValueObjectPhpXmlParser();
            /*
             * The first step is to search all the sheets and make a list of class and package names.
             * This is because the package name is not specified when specifying a class in the PHP format definition.
             */
            final BlancoValueObjectPhpStructure[] structures = parser.parse(fileMeta3[index]);

            if (structures != null ) {
                for (int index2 = 0; index2 < structures.length; index2++) {
                    BlancoValueObjectPhpStructure structure = structures[index2];
                    if (structure != null) {
                        if (isVerbose) {
                            System.out.println("processValueObjects: " + structure.getName());
                        }
                        argObjects.put(structure.getName(), structure);
                    } else {
                        System.out.println("processValueObjects: a structure is NULL!!!");
                    }
                }
            } else {
                System.out.println("processValueObjects: structures are NULL!!!");
            }
        }
    }


    /**
     * Make canonical classname into Simple.
     *
     * @param argClassNameCanon
     * @return simpleName
     */
    static public String getSimpleClassName(final String argClassNameCanon) {
        if (argClassNameCanon == null) {
            return "";
        }

        String simpleName = "";
        final int findLastDot = argClassNameCanon.lastIndexOf('\\');
        if (findLastDot == -1) {
            simpleName = argClassNameCanon;
        } else if (findLastDot != argClassNameCanon.length() - 1) {
            simpleName = argClassNameCanon.substring(findLastDot + 1);
        }
        return simpleName;
    }

    static public String getPackageName(final String argClassNameCanon) {
        if (argClassNameCanon == null) {
            return "";
        }

        String simpleName = "";
        final int findLastDot = argClassNameCanon.lastIndexOf('.');
        if (findLastDot > 0) {
            simpleName = argClassNameCanon.substring(0, findLastDot);
        }
        return simpleName;
    }

    static public String getNamespace(final String argClassNameCanon) {
        if (argClassNameCanon == null) {
            return "";
        }

        String simpleName = "";
        final int findLastDot = argClassNameCanon.lastIndexOf('\\');
        if (findLastDot > 0) {
            simpleName = argClassNameCanon.substring(0, findLastDot);
        }
        return simpleName;
    }


    static public String convertType(String phpType, BlancoValueObjectPhpStructure argObjClassStructure) {
        String targetType = phpType;
        if ("boolean".equalsIgnoreCase(phpType)) {
            targetType = "bool";
        } else
        if ("integer".equalsIgnoreCase(phpType)) {
            targetType = "int";
        } else
        if ("double".equalsIgnoreCase(phpType)) {
            targetType = "float";
        } else
        if ("float".equalsIgnoreCase(phpType)) {
            targetType = "float";
        } else
        if ("string".equalsIgnoreCase(phpType)) {
            targetType = "string";
        } else
        if ("array".equalsIgnoreCase(phpType)) {
            targetType = "array";
        } else
        if ("object".equalsIgnoreCase(phpType)) {
            targetType = "object";
        } else {
            /* Searches for a package with this name. */
            String namespace = getNamespace(phpType);
            String className = getSimpleClassName(phpType);
            BlancoValueObjectPhpStructure voStructure = BlancoValueObjectPhpUtil.objects.get(className);
            if (isVerbose) {
                System.out.println("### namespace = " + namespace);
                System.out.println("### className = " + className);
                System.out.println("### voStructure = " + voStructure);
            }
            if (BlancoStringUtil.null2Blank(namespace).isEmpty() && voStructure != null) {
                namespace = voStructure.getNamespace();
            }
            targetType = className;
            /* Others are written as is. */
            if (isVerbose) {
                System.out.println("/* tueda */ Unknown php type: " + targetType);
                System.out.println("/* tueda */ namespace is: " + namespace);
            }

            /* Add it to importlist */
            String importClass = className;
            if (!BlancoStringUtil.null2Blank(namespace).isEmpty()) {
                importClass = namespace + "\\" + className;
            }
            if (isVerbose) {
                System.out.println("/* tueda */ importClass is: " + importClass);
            }
            if (argObjClassStructure.getCreateImportList()) {
                argObjClassStructure.getImportList().add(importClass);
            }
        }
        return targetType;
    }

    /**
     * Generates import statement.
     * @param argClassName
     * @param argObjClassStructure
     * @param argTargetBasedir
     */
    static public void makeImportHeaderList(String argNamespace, String argClassName, BlancoValueObjectPhpStructure argObjClassStructure) {
        if (argObjClassStructure == null) {
            throw new IllegalArgumentException("argObjClassStructure should not be NULL.");
        }
        if (argClassName == null || argClassName.length() == 0) {
            System.out.println("/* tueda */ argClassName is not specified. SKIP.");
            return;
        }
        if (argClassName.equals(argObjClassStructure.getName())) {
            System.out.println("/* tueda */ Maybe recursive defition. SKIP : " + argClassName);
            return;
        }
        if (isVerbose) {
            System.out.println("makeImportHeaderList: baseDir = " + argObjClassStructure.getBasedir() + "]");
        }
        String importFrom = argClassName;
        if (argNamespace != null &&
                argNamespace.length() != 0 &&
                (argNamespace.equals(argObjClassStructure.getNamespace()) != true)
        ) {
            String classNameCanon = argNamespace + "\\" + argClassName;
            importFrom = classNameCanon;
        }

        List<String> importClassList = importHeaderList.get(importFrom);
        if (importClassList == null) {
            importClassList = new ArrayList<>();
            importHeaderList.put(importFrom, importClassList);
        }
        boolean isMatch = false;
        for (String myClass : importClassList) {
            if (argClassName.equals(myClass)) {
                isMatch = true;
                break;
            }
        }
        if (!isMatch) {
            importClassList.add(argClassName);
            if (isVerbose) {
                System.out.println("/* tueda */ new import { " + argClassName + " } from \"" + importFrom + "\"");
            }
        }
    }

}
