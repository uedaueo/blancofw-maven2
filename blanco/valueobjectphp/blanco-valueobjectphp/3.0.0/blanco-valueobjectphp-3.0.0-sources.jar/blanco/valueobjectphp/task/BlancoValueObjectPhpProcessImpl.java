/*
 * blanco Framework
 * Copyright (C) 2004-2009 IGA Tosiki
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 */
package blanco.valueobjectphp.task;

import blanco.cg.BlancoCgSupportedLang;
import blanco.valueobjectphp.BlancoValueObjectPhpConstants;
import blanco.valueobjectphp.BlancoValueObjectPhpMeta2Xml;
import blanco.valueobjectphp.BlancoValueObjectPhpUtil;
import blanco.valueobjectphp.BlancoValueObjectPhpXml2SourceFile;
import blanco.valueobjectphp.resourcebundle.BlancoValueObjectPhpResourceBundle;
import blanco.valueobjectphp.task.valueobject.BlancoValueObjectPhpProcessInput;

import javax.xml.transform.TransformerException;
import java.io.File;
import java.io.IOException;

public class BlancoValueObjectPhpProcessImpl implements
        BlancoValueObjectPhpProcess {
    /**
     * resource bundle object
     */
    private final BlancoValueObjectPhpResourceBundle fBundle = new BlancoValueObjectPhpResourceBundle();

    /**
     * {@inheritDoc}
     */
    public int execute(final BlancoValueObjectPhpProcessInput input) throws IOException {
        System.out.println("- " + BlancoValueObjectPhpConstants.PRODUCT_NAME
                + " (" + BlancoValueObjectPhpConstants.VERSION + ")");

        try {
            final File fileMetadir = new File(input.getMetadir());
            if (fileMetadir.exists() == false) {
                throw new IllegalArgumentException(fBundle
                        .getAnttaskErr001(input.getMetadir()));
            }

            /*
             * Determines the newline code.
             */
            String LF = "\n";
            String CR = "\r";
            String CRLF = CR + LF;
            String lineSeparatorMark = input.getLineSeparator();
            String lineSeparator = "";
            if ("LF".equals(lineSeparatorMark)) {
                lineSeparator = LF;
            } else if ("CR".equals(lineSeparatorMark)) {
                lineSeparator = CR;
            } else if ("CRLF".equals(lineSeparatorMark)) {
                lineSeparator = CRLF;
            }
            if (lineSeparator.length() != 0) {
                System.setProperty("line.separator", lineSeparator);
                if (input.getVerbose()) {
                    System.out.println("lineSeparator try to change to " + lineSeparatorMark);
                    String newProp = System.getProperty("line.separator");
                    String newMark = "other";
                    if (LF.equals(newProp)) {
                        newMark = "LF";
                    } else if (CR.equals(newProp)) {
                        newMark = "CR";
                    } else if (CRLF.equals(newProp)) {
                        newMark = "CRLF";
                    }
                    System.out.println("New System Props = " + newMark);
                }
            }

            /*
             * Processes targetdir and targetStyle.
             * Sets the storage location for the generated code.
             * targetstyle = blanco:
             *  Creates a main directory under targetdir.
             * targetstyle = maven:
             *  Creates a main/java directory under targetdir.
             * targetstyle = free:
             *  Creates a directory using targetdir as is.
             *  However, if targetdir is empty, the default string (blanco) is used.
             * by tueda, 2019/08/30
             */
            String strTarget = input.getTargetdir();
            String style = input.getTargetStyle();
            // Always true when passing through here.
            boolean isTargetStyleAdvanced = true;
            if (style != null && BlancoValueObjectPhpConstants.TARGET_STYLE_MAVEN.equals(style)) {
                strTarget = strTarget + "/" + BlancoValueObjectPhpConstants.TARGET_DIR_SUFFIX_MAVEN;
            } else if (style == null ||
                    !BlancoValueObjectPhpConstants.TARGET_STYLE_FREE.equals(style)) {
                strTarget = strTarget + "/" + BlancoValueObjectPhpConstants.TARGET_DIR_SUFFIX_BLANCO;
            }
            /* If style is free, uses targetdir as is. */
            if (input.getVerbose()) {
                System.out.println("/* tueda */ TARGETDIR = " + strTarget);
            }

            BlancoValueObjectPhpUtil.generateToJson = input.getGenerateToJson();
            BlancoValueObjectPhpUtil.generateToArray = input.getGenerateToArray();
            BlancoValueObjectPhpUtil.apiTelegram = input.getApiTelegram();
            BlancoValueObjectPhpUtil.generateForRestApi = input.getGenerateForRestApi();
            BlancoValueObjectPhpUtil.targetNamespace = input.getTargetNamspace();
            BlancoValueObjectPhpUtil.apiTelegram = input.getApiTelegram();
            BlancoValueObjectPhpUtil.encoding = input.getEncoding();
            BlancoValueObjectPhpUtil.tabs = input.getTabs();

            // テンポラリディレクトリを作成。
            new File(input.getTmpdir()
                    + BlancoValueObjectPhpConstants.TARGET_SUBDIRECTORY)
                    .mkdirs();

            /*
             * First, searches all the sheets and makes a list of structures from the class names.
             * The reason is that in the PHP-style definitions, the package name is not specified when specifying a class.
             *  In TypeScript, the object placement directory has to be searched from the structure, so a list of package names is not sufficient.
             */
            BlancoValueObjectPhpUtil.isVerbose = input.getVerbose();
            BlancoValueObjectPhpUtil.processValueObjects(input.getTmpdir(), input.getSearchTmpdir(), BlancoValueObjectPhpUtil.objects);

            // 指定されたメタディレクトリを処理します。
            new BlancoValueObjectPhpMeta2Xml()
                    .processDirectory(fileMetadir, input.getTmpdir()
                            + BlancoValueObjectPhpConstants.TARGET_SUBDIRECTORY);

            // XML化された中間ファイルからソースコードを生成
            final File[] fileMeta2 = new File(input.getTmpdir()
                    + BlancoValueObjectPhpConstants.TARGET_SUBDIRECTORY)
                    .listFiles();
            for (int index = 0; index < fileMeta2.length; index++) {
                if (fileMeta2[index].getName().endsWith(".xml") == false) {
                    continue;
                }

                final BlancoValueObjectPhpXml2SourceFile xml2source = new BlancoValueObjectPhpXml2SourceFile();
                xml2source.setTargetStyleAdvanced(isTargetStyleAdvanced);
                xml2source.setSheetLang(new BlancoCgSupportedLang().convertToInt(input.getSheetType()));
                xml2source.process(fileMeta2[index], false, new File(input.getTargetdir()));
            }
        } catch (IOException ex) {
            throw new IllegalArgumentException(ex.toString());
        } catch (TransformerException ex) {
            throw new IllegalArgumentException(ex.toString());
        } catch (IllegalArgumentException ex) {
            ex.printStackTrace();
            throw ex;
        }
        return 0;
    }

    /**
     * {@inheritDoc}
     */
    public boolean progress(final String argProgressMessage) {
        System.out.println(argProgressMessage);
        return false;
    }
}
