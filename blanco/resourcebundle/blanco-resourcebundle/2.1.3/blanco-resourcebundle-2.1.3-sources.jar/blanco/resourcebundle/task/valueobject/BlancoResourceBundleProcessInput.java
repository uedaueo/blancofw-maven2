package blanco.resourcebundle.task.valueobject;

/**
 * An input value object class for the processing class [BlancoResourceBundleProcess].
 */
public class BlancoResourceBundleProcessInput {
    /**
     * Whether to run in verbose mode.
     *
     * フィールド: [verbose]。
     * デフォルト: [false]。
     */
    private boolean fVerbose = false;

    /**
     * メタディレクトリ
     *
     * フィールド: [metadir]。
     */
    private String fMetadir;

    /**
     * 出力先フォルダを指定します。無指定の場合にはカレント直下のblancoを用います。
     *
     * フィールド: [targetdir]。
     * デフォルト: [blanco]。
     */
    private String fTargetdir = "blanco";

    /**
     * テンポラリフォルダを指定します。無指定の場合には、カレント直下のtmpを用います。
     *
     * フィールド: [tmpdir]。
     * デフォルト: [tmp]。
     */
    private String fTmpdir = "tmp";

    /**
     * 自動生成するソースファイルの文字エンコーディングを指定します。
     *
     * フィールド: [encoding]。
     */
    private String fEncoding;

    /**
     * プロパティファイルの生成時刻について、プロパティファイルのコメントに出力するかどうかフラグ。
     *
     * フィールド: [commenttimestamp]。
     * デフォルト: [true]。
     */
    private boolean fCommenttimestamp = true;

    /**
     * リソースバンドル文字列をMessageFormatによるパースを行った際に、例外が発生したら処理を中断するかどうかのフラグ。trueなら処理中断して例外を発生させます。falseなら処理続行し、置換文字列は無いものとみなします。Javaのソースコードを処理する際などに、あえて falseに設定して波括弧を扱うことができるように切り替える場合があります。
     *
     * フィールド: [failonmessageformaterror]。
     * デフォルト: [true]。
     */
    private boolean fFailonmessageformaterror = true;

    /**
     * ログ出力を自動生成されるソースコードに含めるかどうかのフラグ。出力する場合には java.util.logging.Loggerのみに対応。
     *
     * フィールド: [log]。
     * デフォルト: [false]。
     */
    private boolean fLog = false;

    /**
     * プロパティファイルをディレクトリ付きで出力するかどうかのフラグ。
     *
     * フィールド: [propertieswithdirectory]。
     * デフォルト: [true]。
     */
    private boolean fPropertieswithdirectory = true;

    /**
     * 出力先フォルダの書式を指定します。&amp;lt;br&amp;gt;\nblanco: [targetdir]/main&amp;lt;br&amp;gt;\nmaven: [targetdir]/main/java&amp;lt;br&amp;gt;\nfree: [targetdir](targetdirが無指定の場合はblanco/main)
     *
     * フィールド: [targetStyle]。
     * デフォルト: [blanco]。
     */
    private String fTargetStyle = "blanco";

    /**
     * 行末記号をしていします。LF=0x0a, CR=0x0d, CFLF=0x0d0x0a とします。LFがデフォルトです。
     *
     * フィールド: [lineSeparator]。
     * デフォルト: [LF]。
     */
    private String fLineSeparator = "LF";

    /**
     * フィールド [verbose] の値を設定します。
     *
     * フィールドの説明: [Whether to run in verbose mode.]。
     *
     * @param argVerbose フィールド[verbose]に設定する値。
     */
    public void setVerbose(final boolean argVerbose) {
        fVerbose = argVerbose;
    }

    /**
     * フィールド [verbose] の値を取得します。
     *
     * フィールドの説明: [Whether to run in verbose mode.]。
     * デフォルト: [false]。
     *
     * @return フィールド[verbose]から取得した値。
     */
    public boolean getVerbose() {
        return fVerbose;
    }

    /**
     * フィールド [metadir] の値を設定します。
     *
     * フィールドの説明: [メタディレクトリ]。
     *
     * @param argMetadir フィールド[metadir]に設定する値。
     */
    public void setMetadir(final String argMetadir) {
        fMetadir = argMetadir;
    }

    /**
     * フィールド [metadir] の値を取得します。
     *
     * フィールドの説明: [メタディレクトリ]。
     *
     * @return フィールド[metadir]から取得した値。
     */
    public String getMetadir() {
        return fMetadir;
    }

    /**
     * フィールド [targetdir] の値を設定します。
     *
     * フィールドの説明: [出力先フォルダを指定します。無指定の場合にはカレント直下のblancoを用います。]。
     *
     * @param argTargetdir フィールド[targetdir]に設定する値。
     */
    public void setTargetdir(final String argTargetdir) {
        fTargetdir = argTargetdir;
    }

    /**
     * フィールド [targetdir] の値を取得します。
     *
     * フィールドの説明: [出力先フォルダを指定します。無指定の場合にはカレント直下のblancoを用います。]。
     * デフォルト: [blanco]。
     *
     * @return フィールド[targetdir]から取得した値。
     */
    public String getTargetdir() {
        return fTargetdir;
    }

    /**
     * フィールド [tmpdir] の値を設定します。
     *
     * フィールドの説明: [テンポラリフォルダを指定します。無指定の場合には、カレント直下のtmpを用います。]。
     *
     * @param argTmpdir フィールド[tmpdir]に設定する値。
     */
    public void setTmpdir(final String argTmpdir) {
        fTmpdir = argTmpdir;
    }

    /**
     * フィールド [tmpdir] の値を取得します。
     *
     * フィールドの説明: [テンポラリフォルダを指定します。無指定の場合には、カレント直下のtmpを用います。]。
     * デフォルト: [tmp]。
     *
     * @return フィールド[tmpdir]から取得した値。
     */
    public String getTmpdir() {
        return fTmpdir;
    }

    /**
     * フィールド [encoding] の値を設定します。
     *
     * フィールドの説明: [自動生成するソースファイルの文字エンコーディングを指定します。]。
     *
     * @param argEncoding フィールド[encoding]に設定する値。
     */
    public void setEncoding(final String argEncoding) {
        fEncoding = argEncoding;
    }

    /**
     * フィールド [encoding] の値を取得します。
     *
     * フィールドの説明: [自動生成するソースファイルの文字エンコーディングを指定します。]。
     *
     * @return フィールド[encoding]から取得した値。
     */
    public String getEncoding() {
        return fEncoding;
    }

    /**
     * フィールド [commenttimestamp] の値を設定します。
     *
     * フィールドの説明: [プロパティファイルの生成時刻について、プロパティファイルのコメントに出力するかどうかフラグ。]。
     *
     * @param argCommenttimestamp フィールド[commenttimestamp]に設定する値。
     */
    public void setCommenttimestamp(final boolean argCommenttimestamp) {
        fCommenttimestamp = argCommenttimestamp;
    }

    /**
     * フィールド [commenttimestamp] の値を取得します。
     *
     * フィールドの説明: [プロパティファイルの生成時刻について、プロパティファイルのコメントに出力するかどうかフラグ。]。
     * デフォルト: [true]。
     *
     * @return フィールド[commenttimestamp]から取得した値。
     */
    public boolean getCommenttimestamp() {
        return fCommenttimestamp;
    }

    /**
     * フィールド [failonmessageformaterror] の値を設定します。
     *
     * フィールドの説明: [リソースバンドル文字列をMessageFormatによるパースを行った際に、例外が発生したら処理を中断するかどうかのフラグ。trueなら処理中断して例外を発生させます。falseなら処理続行し、置換文字列は無いものとみなします。Javaのソースコードを処理する際などに、あえて falseに設定して波括弧を扱うことができるように切り替える場合があります。]。
     *
     * @param argFailonmessageformaterror フィールド[failonmessageformaterror]に設定する値。
     */
    public void setFailonmessageformaterror(final boolean argFailonmessageformaterror) {
        fFailonmessageformaterror = argFailonmessageformaterror;
    }

    /**
     * フィールド [failonmessageformaterror] の値を取得します。
     *
     * フィールドの説明: [リソースバンドル文字列をMessageFormatによるパースを行った際に、例外が発生したら処理を中断するかどうかのフラグ。trueなら処理中断して例外を発生させます。falseなら処理続行し、置換文字列は無いものとみなします。Javaのソースコードを処理する際などに、あえて falseに設定して波括弧を扱うことができるように切り替える場合があります。]。
     * デフォルト: [true]。
     *
     * @return フィールド[failonmessageformaterror]から取得した値。
     */
    public boolean getFailonmessageformaterror() {
        return fFailonmessageformaterror;
    }

    /**
     * フィールド [log] の値を設定します。
     *
     * フィールドの説明: [ログ出力を自動生成されるソースコードに含めるかどうかのフラグ。出力する場合には java.util.logging.Loggerのみに対応。]。
     *
     * @param argLog フィールド[log]に設定する値。
     */
    public void setLog(final boolean argLog) {
        fLog = argLog;
    }

    /**
     * フィールド [log] の値を取得します。
     *
     * フィールドの説明: [ログ出力を自動生成されるソースコードに含めるかどうかのフラグ。出力する場合には java.util.logging.Loggerのみに対応。]。
     * デフォルト: [false]。
     *
     * @return フィールド[log]から取得した値。
     */
    public boolean getLog() {
        return fLog;
    }

    /**
     * フィールド [propertieswithdirectory] の値を設定します。
     *
     * フィールドの説明: [プロパティファイルをディレクトリ付きで出力するかどうかのフラグ。]。
     *
     * @param argPropertieswithdirectory フィールド[propertieswithdirectory]に設定する値。
     */
    public void setPropertieswithdirectory(final boolean argPropertieswithdirectory) {
        fPropertieswithdirectory = argPropertieswithdirectory;
    }

    /**
     * フィールド [propertieswithdirectory] の値を取得します。
     *
     * フィールドの説明: [プロパティファイルをディレクトリ付きで出力するかどうかのフラグ。]。
     * デフォルト: [true]。
     *
     * @return フィールド[propertieswithdirectory]から取得した値。
     */
    public boolean getPropertieswithdirectory() {
        return fPropertieswithdirectory;
    }

    /**
     * フィールド [targetStyle] の値を設定します。
     *
     * フィールドの説明: [出力先フォルダの書式を指定します。&lt;br&gt;\nblanco: [targetdir]/main&lt;br&gt;\nmaven: [targetdir]/main/java&lt;br&gt;\nfree: [targetdir](targetdirが無指定の場合はblanco/main)]。
     *
     * @param argTargetStyle フィールド[targetStyle]に設定する値。
     */
    public void setTargetStyle(final String argTargetStyle) {
        fTargetStyle = argTargetStyle;
    }

    /**
     * フィールド [targetStyle] の値を取得します。
     *
     * フィールドの説明: [出力先フォルダの書式を指定します。&lt;br&gt;\nblanco: [targetdir]/main&lt;br&gt;\nmaven: [targetdir]/main/java&lt;br&gt;\nfree: [targetdir](targetdirが無指定の場合はblanco/main)]。
     * デフォルト: [blanco]。
     *
     * @return フィールド[targetStyle]から取得した値。
     */
    public String getTargetStyle() {
        return fTargetStyle;
    }

    /**
     * フィールド [lineSeparator] の値を設定します。
     *
     * フィールドの説明: [行末記号をしていします。LF=0x0a, CR=0x0d, CFLF=0x0d0x0a とします。LFがデフォルトです。]。
     *
     * @param argLineSeparator フィールド[lineSeparator]に設定する値。
     */
    public void setLineSeparator(final String argLineSeparator) {
        fLineSeparator = argLineSeparator;
    }

    /**
     * フィールド [lineSeparator] の値を取得します。
     *
     * フィールドの説明: [行末記号をしていします。LF=0x0a, CR=0x0d, CFLF=0x0d0x0a とします。LFがデフォルトです。]。
     * デフォルト: [LF]。
     *
     * @return フィールド[lineSeparator]から取得した値。
     */
    public String getLineSeparator() {
        return fLineSeparator;
    }

    /**
     * このバリューオブジェクトの文字列表現を取得します。
     *
     * <P>使用上の注意</P>
     * <UL>
     * <LI>オブジェクトのシャロー範囲のみ文字列化の処理対象となります。
     * <LI>オブジェクトが循環参照している場合には、このメソッドは使わないでください。
     * </UL>
     *
     * @return バリューオブジェクトの文字列表現。
     */
    @Override
    public String toString() {
        final StringBuffer buf = new StringBuffer();
        buf.append("blanco.resourcebundle.task.valueobject.BlancoResourceBundleProcessInput[");
        buf.append("verbose=" + fVerbose);
        buf.append(",metadir=" + fMetadir);
        buf.append(",targetdir=" + fTargetdir);
        buf.append(",tmpdir=" + fTmpdir);
        buf.append(",encoding=" + fEncoding);
        buf.append(",commenttimestamp=" + fCommenttimestamp);
        buf.append(",failonmessageformaterror=" + fFailonmessageformaterror);
        buf.append(",log=" + fLog);
        buf.append(",propertieswithdirectory=" + fPropertieswithdirectory);
        buf.append(",targetStyle=" + fTargetStyle);
        buf.append(",lineSeparator=" + fLineSeparator);
        buf.append("]");
        return buf.toString();
    }

    /**
     * このバリューオブジェクトを指定のターゲットに複写します。
     *
     * <P>使用上の注意</P>
     * <UL>
     * <LI>オブジェクトのシャロー範囲のみ複写処理対象となります。
     * <LI>オブジェクトが循環参照している場合には、このメソッドは使わないでください。
     * </UL>
     *
     * @param target target value object.
     */
    public void copyTo(final BlancoResourceBundleProcessInput target) {
        if (target == null) {
            throw new IllegalArgumentException("Bug: BlancoResourceBundleProcessInput#copyTo(target): argument 'target' is null");
        }

        // No needs to copy parent class.

        // Name: fVerbose
        // Type: boolean
        target.fVerbose = this.fVerbose;
        // Name: fMetadir
        // Type: java.lang.String
        target.fMetadir = this.fMetadir;
        // Name: fTargetdir
        // Type: java.lang.String
        target.fTargetdir = this.fTargetdir;
        // Name: fTmpdir
        // Type: java.lang.String
        target.fTmpdir = this.fTmpdir;
        // Name: fEncoding
        // Type: java.lang.String
        target.fEncoding = this.fEncoding;
        // Name: fCommenttimestamp
        // Type: boolean
        target.fCommenttimestamp = this.fCommenttimestamp;
        // Name: fFailonmessageformaterror
        // Type: boolean
        target.fFailonmessageformaterror = this.fFailonmessageformaterror;
        // Name: fLog
        // Type: boolean
        target.fLog = this.fLog;
        // Name: fPropertieswithdirectory
        // Type: boolean
        target.fPropertieswithdirectory = this.fPropertieswithdirectory;
        // Name: fTargetStyle
        // Type: java.lang.String
        target.fTargetStyle = this.fTargetStyle;
        // Name: fLineSeparator
        // Type: java.lang.String
        target.fLineSeparator = this.fLineSeparator;
    }
}
