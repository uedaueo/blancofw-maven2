/*
 * このソースコードは blanco Frameworkによって自動生成されています。
 */
package blanco.resourcebundle.message;

/**
 * blancoResourceBundleのメッセージクラス。
 */
public class BlancoResourceBundleMessage {
    /**
     * メッセージをプロパティファイル対応させるための内部的に利用するリソースバンドルクラス。
     */
    protected final BlancoResourceBundleMessageResourceBundle fBundle = new BlancoResourceBundleMessageResourceBundle();

    /**
     * メッセージ定義ID[BlancoResourceBundle]、キー[MBRBI001]の文字列を取得します。
     *
     * No.2:
     * 文字列[リソース定義[{0}]のパッケージの指定が見つかりません。]
     *
     * @param arg0 置換文字列{0}の値。
     * @return メッセージ文字列。
     */
    public String getMbrbi001(final String arg0) {
        if (arg0 == null) {
            throw new IllegalArgumentException("The parameter [arg0] of the method [getMbrbi001] has been given null. However, null cannot be given to this parameter.");
        }

        return "[MBRBI001] " + fBundle.getMbrbi001(arg0);
    }

    /**
     * メッセージ定義ID[BlancoResourceBundle]、キー[MBRBI002]の文字列を取得します。
     *
     * No.3:
     * 文字列[リソース定義[{0}]に異なるパッケージの指定[{1}]と[{2}]が見つかりました。]
     *
     * @param arg0 置換文字列{0}の値。
     * @param arg1 置換文字列{1}の値。
     * @param arg2 置換文字列{2}の値。
     * @return メッセージ文字列。
     */
    public String getMbrbi002(final String arg0, final String arg1, final String arg2) {
        if (arg0 == null) {
            throw new IllegalArgumentException("The parameter [arg0] of the method [getMbrbi002] has been given null. However, null cannot be given to this parameter.");
        }
        if (arg1 == null) {
            throw new IllegalArgumentException("The parameter [arg1] of the method [getMbrbi002] has been given null. However, null cannot be given to this parameter.");
        }
        if (arg2 == null) {
            throw new IllegalArgumentException("The parameter [arg2] of the method [getMbrbi002] has been given null. However, null cannot be given to this parameter.");
        }

        return "[MBRBI002] " + fBundle.getMbrbi002(arg0, arg1, arg2);
    }

    /**
     * メッセージ定義ID[BlancoResourceBundle]、キー[MBRBI003]の文字列を取得します。
     *
     * No.4:
     * 文字列[異なるサフィックス[{0}]と[{1}]が同一の設定ファイル上に見つかりました。]
     *
     * @param arg0 置換文字列{0}の値。
     * @param arg1 置換文字列{1}の値。
     * @return メッセージ文字列。
     */
    public String getMbrbi003(final String arg0, final String arg1) {
        if (arg0 == null) {
            throw new IllegalArgumentException("The parameter [arg0] of the method [getMbrbi003] has been given null. However, null cannot be given to this parameter.");
        }
        if (arg1 == null) {
            throw new IllegalArgumentException("The parameter [arg1] of the method [getMbrbi003] has been given null. However, null cannot be given to this parameter.");
        }

        return "[MBRBI003] " + fBundle.getMbrbi003(arg0, arg1);
    }

    /**
     * メッセージ定義ID[BlancoResourceBundle]、キー[MBRBI004]の文字列を取得します。
     *
     * No.5:
     * 文字列[リソース定義[{0}]のロケールの指定が見つかりません。]
     *
     * @param arg0 置換文字列{0}の値。
     * @return メッセージ文字列。
     */
    public String getMbrbi004(final String arg0) {
        if (arg0 == null) {
            throw new IllegalArgumentException("The parameter [arg0] of the method [getMbrbi004] has been given null. However, null cannot be given to this parameter.");
        }

        return "[MBRBI004] " + fBundle.getMbrbi004(arg0);
    }

    /**
     * メッセージ定義ID[BlancoResourceBundle]、キー[MBRBI005]の文字列を取得します。
     *
     * No.6:
     * 文字列[基底名[{0}] は既にロケール[{1}]で処理されています。]
     *
     * @param arg0 置換文字列{0}の値。
     * @param arg1 置換文字列{1}の値。
     * @return メッセージ文字列。
     */
    public String getMbrbi005(final String arg0, final String arg1) {
        if (arg0 == null) {
            throw new IllegalArgumentException("The parameter [arg0] of the method [getMbrbi005] has been given null. However, null cannot be given to this parameter.");
        }
        if (arg1 == null) {
            throw new IllegalArgumentException("The parameter [arg1] of the method [getMbrbi005] has been given null. However, null cannot be given to this parameter.");
        }

        return "[MBRBI005] " + fBundle.getMbrbi005(arg0, arg1);
    }

    /**
     * メッセージ定義ID[BlancoResourceBundle]、キー[MBRBI006]の文字列を取得します。
     *
     * No.7:
     * 文字列[リソースバンドル定義[{0}]のロケール[{1}]が重複して定義されています。]
     *
     * @param arg0 置換文字列{0}の値。
     * @param arg1 置換文字列{1}の値。
     * @return メッセージ文字列。
     */
    public String getMbrbi006(final String arg0, final String arg1) {
        if (arg0 == null) {
            throw new IllegalArgumentException("The parameter [arg0] of the method [getMbrbi006] has been given null. However, null cannot be given to this parameter.");
        }
        if (arg1 == null) {
            throw new IllegalArgumentException("The parameter [arg1] of the method [getMbrbi006] has been given null. However, null cannot be given to this parameter.");
        }

        return "[MBRBI006] " + fBundle.getMbrbi006(arg0, arg1);
    }

    /**
     * メッセージ定義ID[BlancoResourceBundle]、キー[MBRBI007]の文字列を取得します。
     *
     * No.8:
     * 文字列[リソースバンドル定義[{0}]のロケール[{1}]のリソースID[{2}]が重複して定義されています。]
     *
     * @param arg0 置換文字列{0}の値。
     * @param arg1 置換文字列{1}の値。
     * @param arg2 置換文字列{2}の値。
     * @return メッセージ文字列。
     */
    public String getMbrbi007(final String arg0, final String arg1, final String arg2) {
        if (arg0 == null) {
            throw new IllegalArgumentException("The parameter [arg0] of the method [getMbrbi007] has been given null. However, null cannot be given to this parameter.");
        }
        if (arg1 == null) {
            throw new IllegalArgumentException("The parameter [arg1] of the method [getMbrbi007] has been given null. However, null cannot be given to this parameter.");
        }
        if (arg2 == null) {
            throw new IllegalArgumentException("The parameter [arg2] of the method [getMbrbi007] has been given null. However, null cannot be given to this parameter.");
        }

        return "[MBRBI007] " + fBundle.getMbrbi007(arg0, arg1, arg2);
    }

    /**
     * メッセージ定義ID[BlancoResourceBundle]、キー[MBRBI008]の文字列を取得します。
     *
     * No.9:
     * 文字列[基底名[{0}] ロケール[{1}] キー[{2}] 文字列[{3}]の解析に失敗しました。文字列が不正である可能性があります。]
     *
     * @param arg0 置換文字列{0}の値。
     * @param arg1 置換文字列{1}の値。
     * @param arg2 置換文字列{2}の値。
     * @param arg3 置換文字列{3}の値。
     * @return メッセージ文字列。
     */
    public String getMbrbi008(final String arg0, final String arg1, final String arg2, final String arg3) {
        if (arg0 == null) {
            throw new IllegalArgumentException("The parameter [arg0] of the method [getMbrbi008] has been given null. However, null cannot be given to this parameter.");
        }
        if (arg1 == null) {
            throw new IllegalArgumentException("The parameter [arg1] of the method [getMbrbi008] has been given null. However, null cannot be given to this parameter.");
        }
        if (arg2 == null) {
            throw new IllegalArgumentException("The parameter [arg2] of the method [getMbrbi008] has been given null. However, null cannot be given to this parameter.");
        }
        if (arg3 == null) {
            throw new IllegalArgumentException("The parameter [arg3] of the method [getMbrbi008] has been given null. However, null cannot be given to this parameter.");
        }

        return "[MBRBI008] " + fBundle.getMbrbi008(arg0, arg1, arg2, arg3);
    }

    /**
     * メッセージ定義ID[BlancoResourceBundle]、キー[MBRBI009]の文字列を取得します。
     *
     * No.10:
     * 文字列[リソースバンドル定義[{0}]のロケール[{1}]のリソースID[{2}]のメッセージ内においてパラメータの指定が({3})個ありますが、これまで現れていた文字列にはパラメータの指定がありませんでした。]
     *
     * @param arg0 置換文字列{0}の値。
     * @param arg1 置換文字列{1}の値。
     * @param arg2 置換文字列{2}の値。
     * @param arg3 置換文字列{3}の値。
     * @return メッセージ文字列。
     */
    public String getMbrbi009(final String arg0, final String arg1, final String arg2, final String arg3) {
        if (arg0 == null) {
            throw new IllegalArgumentException("The parameter [arg0] of the method [getMbrbi009] has been given null. However, null cannot be given to this parameter.");
        }
        if (arg1 == null) {
            throw new IllegalArgumentException("The parameter [arg1] of the method [getMbrbi009] has been given null. However, null cannot be given to this parameter.");
        }
        if (arg2 == null) {
            throw new IllegalArgumentException("The parameter [arg2] of the method [getMbrbi009] has been given null. However, null cannot be given to this parameter.");
        }
        if (arg3 == null) {
            throw new IllegalArgumentException("The parameter [arg3] of the method [getMbrbi009] has been given null. However, null cannot be given to this parameter.");
        }

        return "[MBRBI009] " + fBundle.getMbrbi009(arg0, arg1, arg2, arg3);
    }

    /**
     * メッセージ定義ID[BlancoResourceBundle]、キー[MBRBI010]の文字列を取得します。
     *
     * No.11:
     * 文字列[リソースバンドル定義[{0}]のロケール[{1}]のリソースID[{2}]のメッセージ内においてパラメータの指定がありませんが、これまで現れていた文字列には({3})個のパラメータの指定がありました。]
     *
     * @param arg0 置換文字列{0}の値。
     * @param arg1 置換文字列{1}の値。
     * @param arg2 置換文字列{2}の値。
     * @param arg3 置換文字列{3}の値。
     * @return メッセージ文字列。
     */
    public String getMbrbi010(final String arg0, final String arg1, final String arg2, final String arg3) {
        if (arg0 == null) {
            throw new IllegalArgumentException("The parameter [arg0] of the method [getMbrbi010] has been given null. However, null cannot be given to this parameter.");
        }
        if (arg1 == null) {
            throw new IllegalArgumentException("The parameter [arg1] of the method [getMbrbi010] has been given null. However, null cannot be given to this parameter.");
        }
        if (arg2 == null) {
            throw new IllegalArgumentException("The parameter [arg2] of the method [getMbrbi010] has been given null. However, null cannot be given to this parameter.");
        }
        if (arg3 == null) {
            throw new IllegalArgumentException("The parameter [arg3] of the method [getMbrbi010] has been given null. However, null cannot be given to this parameter.");
        }

        return "[MBRBI010] " + fBundle.getMbrbi010(arg0, arg1, arg2, arg3);
    }

    /**
     * メッセージ定義ID[BlancoResourceBundle]、キー[MBRBI011]の文字列を取得します。
     *
     * No.12:
     * 文字列[リソースバンドル定義[{0}]のロケール[{1}]のリソースID[{2}]のメッセージ内におけるパラメータの数({3})が、これまで現れていたパラメータの数({4})と一致しません。]
     *
     * @param arg0 置換文字列{0}の値。
     * @param arg1 置換文字列{1}の値。
     * @param arg2 置換文字列{2}の値。
     * @param arg3 置換文字列{3}の値。
     * @param arg4 置換文字列{4}の値。
     * @return メッセージ文字列。
     */
    public String getMbrbi011(final String arg0, final String arg1, final String arg2, final String arg3, final String arg4) {
        if (arg0 == null) {
            throw new IllegalArgumentException("The parameter [arg0] of the method [getMbrbi011] has been given null. However, null cannot be given to this parameter.");
        }
        if (arg1 == null) {
            throw new IllegalArgumentException("The parameter [arg1] of the method [getMbrbi011] has been given null. However, null cannot be given to this parameter.");
        }
        if (arg2 == null) {
            throw new IllegalArgumentException("The parameter [arg2] of the method [getMbrbi011] has been given null. However, null cannot be given to this parameter.");
        }
        if (arg3 == null) {
            throw new IllegalArgumentException("The parameter [arg3] of the method [getMbrbi011] has been given null. However, null cannot be given to this parameter.");
        }
        if (arg4 == null) {
            throw new IllegalArgumentException("The parameter [arg4] of the method [getMbrbi011] has been given null. However, null cannot be given to this parameter.");
        }

        return "[MBRBI011] " + fBundle.getMbrbi011(arg0, arg1, arg2, arg3, arg4);
    }

    /**
     * メッセージ定義ID[BlancoResourceBundle]、キー[MBRBI012]の文字列を取得します。
     *
     * No.13:
     * 文字列[リソースバンドル定義[{0}]のロケール[{1}]のリソースID[{2}]のメッセージ内におけるパラメータの型({3})が、これまで現れていたパラメータの型({4})と一致しません。]
     *
     * @param arg0 置換文字列{0}の値。
     * @param arg1 置換文字列{1}の値。
     * @param arg2 置換文字列{2}の値。
     * @param arg3 置換文字列{3}の値。
     * @param arg4 置換文字列{4}の値。
     * @return メッセージ文字列。
     */
    public String getMbrbi012(final String arg0, final String arg1, final String arg2, final String arg3, final String arg4) {
        if (arg0 == null) {
            throw new IllegalArgumentException("The parameter [arg0] of the method [getMbrbi012] has been given null. However, null cannot be given to this parameter.");
        }
        if (arg1 == null) {
            throw new IllegalArgumentException("The parameter [arg1] of the method [getMbrbi012] has been given null. However, null cannot be given to this parameter.");
        }
        if (arg2 == null) {
            throw new IllegalArgumentException("The parameter [arg2] of the method [getMbrbi012] has been given null. However, null cannot be given to this parameter.");
        }
        if (arg3 == null) {
            throw new IllegalArgumentException("The parameter [arg3] of the method [getMbrbi012] has been given null. However, null cannot be given to this parameter.");
        }
        if (arg4 == null) {
            throw new IllegalArgumentException("The parameter [arg4] of the method [getMbrbi012] has been given null. However, null cannot be given to this parameter.");
        }

        return "[MBRBI012] " + fBundle.getMbrbi012(arg0, arg1, arg2, arg3, arg4);
    }

    /**
     * メッセージ定義ID[BlancoResourceBundle]、キー[MBRBA001]の文字列を取得します。
     *
     * No.15:
     * 文字列[指定のmetadir[{0}]が見つかりません。]
     *
     * @param arg0 置換文字列{0}の値。
     * @return メッセージ文字列。
     */
    public String getMbrba001(final String arg0) {
        if (arg0 == null) {
            throw new IllegalArgumentException("The parameter [arg0] of the method [getMbrba001] has been given null. However, null cannot be given to this parameter.");
        }

        return "[MBRBA001] " + fBundle.getMbrba001(arg0);
    }
}
