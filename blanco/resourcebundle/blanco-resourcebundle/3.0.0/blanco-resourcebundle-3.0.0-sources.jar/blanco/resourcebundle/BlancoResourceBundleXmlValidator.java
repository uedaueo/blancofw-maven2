/*
 * blanco Framework
 * Copyright (C) 2004-2007 IGA Tosiki
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 */
package blanco.resourcebundle;

import java.io.File;
import java.text.Format;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.transform.dom.DOMResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;

import blanco.commons.util.BlancoJavaSourceUtil;
import blanco.commons.util.BlancoStringUtil;
import blanco.commons.util.BlancoXmlUtil;
import blanco.resourcebundle.message.BlancoResourceBundleMessage;
import blanco.resourcebundle.resourcebundle.BlancoResourceBundleResourceBundle;
import blanco.resourcebundle.valueobject.BlancoResourceBundleBundleStructure;

/**
 * Checks the validity of the content of the aggregated intermediate XML file.
 *
 * This source code is part of the blancoResourceBundle.<br>
 *
 * @author IGA Tosiki
 */
public class BlancoResourceBundleXmlValidator {
    /**
     * A message.
     */
    private final BlancoResourceBundleMessage fMsg = new BlancoResourceBundleMessage();

    /**
     * An instance of a resource bundle accessor.
     */
    private final BlancoResourceBundleResourceBundle fBundle = new BlancoResourceBundleResourceBundle();

    /**
     * Flag whether or not to abort the process if an exception occurs when parsing a resource bundle string with MessageFormat.
     *
     * If true, processing will be aborted and an exception will be raised. <br>
     * If false, continues processing and assumes there is no replacement string. <br>
     * In some cases, such as when processing Java source code, you may want to set this flag to false so that braces can be handled. <br>
     * The default value [true] is set.
     */
    private boolean fIsFailOnMessageFormatError = true;



    /**
     * Sets the flag whether or not to abort the process if an exception occurs when parsing a resource bundle string with MessageFormat.
     *
     * If true, processing will be aborted and an exception will be raised. <br>
     * If false, continues processing and assumes there is no replacement string. <br>
     * In some cases, such as when processing Java source code, you may want to set this flag to false so that braces can be handled. <br>
     * The default value [true] is set.
     *
     * @param argIsFailOnMessageFormatError
     */
    public void setFailOnMessageFormatError(
            final boolean argIsFailOnMessageFormatError) {
        fIsFailOnMessageFormatError = argIsFailOnMessageFormatError;
    }

    /**
     * Style of the source code generation destination directory.
     */
    private boolean fTargetStyleAdvanced = false;
    public void setTargetStyleAdvanced(boolean argTargetStyleAdvanced) {
        this.fTargetStyleAdvanced = argTargetStyleAdvanced;
    }
    public boolean isTargetStyleAdvanced() {
        return this.fTargetStyleAdvanced;
    }

    /**
     * Generates Java source code for property file access from an intermediate XML file.
     *
     * @param argFileSource
     *            An intermediate XML file as input.
     * @param argDirectoryTarget
     *            Output directory of the source code.
     */
    public void process(final File argFileSource, final File argDirectoryTarget) {
        final DOMResult result = BlancoXmlUtil.transformFile2Dom(argFileSource);

        final Node rootNode = result.getNode();
        if (rootNode instanceof Document) {
            // This is the normal system. Gets the document root.
            final Document rootDocument = (Document) rootNode;
            final NodeList listSheet = rootDocument
                    .getElementsByTagName("sheet");
            final int sizeListSheet = listSheet.getLength();
            final Map<java.lang.String, java.lang.String> mapProcessedBaseName = new HashMap<java.lang.String, java.lang.String>(
                    64);
            for (int index = 0; index < sizeListSheet; index++) {
                final Element elementSheet = (Element) listSheet.item(index);

                final NodeList listCommon = elementSheet
                        .getElementsByTagName(fBundle
                                .getMeta2xmlElementCommon());
                if (listCommon == null || listCommon.getLength() == 0) {
                    // Skips if there is no common.
                    continue;
                }

                final Element elementCommon = (Element) listCommon.item(0);

                final BlancoResourceBundleBundleStructure structure = new BlancoResourceBundleBundleStructure();

                structure.setName(BlancoXmlUtil.getTextContent(elementCommon,
                        "baseName"));
                if (structure.getName() == null) {
                    continue;
                }

                if (BlancoXmlUtil.getTextContent(elementCommon, "packageName") == null) {
                    // TODO: Missing packages should be treated as an error.
                    continue;
                }

                final List<java.lang.String> listLocale = new ArrayList<java.lang.String>();
                final NodeList nodeListCommon = elementCommon
                        .getElementsByTagName("locale");
                if (nodeListCommon == null || nodeListCommon.getLength() == 0) {
                    continue;
                }

                final int sizeNodeListCommon = nodeListCommon.getLength();
                for (int indexLocale = 0; indexLocale < sizeNodeListCommon; indexLocale++) {
                    final Node nodeLook = nodeListCommon.item(indexLocale);
                    if (nodeLook instanceof Element == false) {
                        continue;
                    }

                    final Element elementLook = (Element) nodeLook;
                    final NodeList nodeChilds = elementLook.getChildNodes();
                    if (nodeChilds == null) {
                        continue;
                    }

                    final int nodeChildsLength = nodeChilds.getLength();
                    for (int indexChild = 0; indexChild < nodeChildsLength; indexChild++) {
                        final Node nodeChild = nodeChilds.item(indexChild);
                        if (nodeChild instanceof Text) {
                            listLocale.add(((Text) nodeChild).getNodeValue());
                        }
                    }
                }
                if (listLocale.size() == 0) {
                    continue;
                }

                if (mapProcessedBaseName.get(structure.getName()) != null) {
                    throw new IllegalArgumentException(fMsg.getMbrbi005(
                            structure.getName(), (String) mapProcessedBaseName
                                    .get(structure.getName())));
                }

                expandSheet(elementSheet, elementCommon);
                mapProcessedBaseName.put(structure.getName(), "Processed.");
            }
        }
    }

    /**
     * Checks the validity of the content of the aggregated intermediate XML file.
     *
     * @param argElementSheet
     *            A sheet element.
     * @param argElementCommon
     *            An element of common information.
     */
    private void expandSheet(final Element argElementSheet,
            final Element argElementCommon) {
        final BlancoResourceBundleBundleStructure structure = new BlancoResourceBundleBundleStructure();

        structure.setName(BlancoXmlUtil.getTextContent(argElementCommon,
                "baseName"));
        structure.setDescription(BlancoXmlUtil.getTextContent(argElementCommon,
                "description"));

        final List<java.lang.String> listKnownLocale = new ArrayList<java.lang.String>();
        final Map<java.lang.String, java.lang.String> mapBundle = new HashMap<java.lang.String, java.lang.String>();
        // Uses the given package name as is.

        final NodeList listCommonList = argElementSheet
                .getElementsByTagName(fBundle.getMeta2xmlElementCommon());
        if (listCommonList == null || listCommonList.getLength() == 0) {
            // Skips if there is no common.
            return;
        }

        checkLocaleDup(structure.getName(), structure.getDescription(),
                listKnownLocale, listCommonList);

        final NodeList listResourceList = argElementSheet
                .getElementsByTagName(fBundle.getMeta2xmlElementList());
        if (listResourceList == null || listResourceList.getLength() == 0) {
            // Skips the process if there is no body part.
            return;
        }

        final NodeList listResource = ((Element) listResourceList.item(0))
                .getElementsByTagName("resource");
        if (listResource == null || listResource.getLength() == 0) {
            return;
        }

        final int sizeListResource = listResource.getLength();
        for (int indexResource = 0; indexResource < sizeListResource; indexResource++) {
            final Element elementResource = (Element) listResource
                    .item(indexResource);

            final String fieldResourceId = BlancoStringUtil
                    .null2Blank(BlancoXmlUtil.getTextContent(elementResource,
                            "resourceKey"));

            final NodeList nodeListResourceString = elementResource
                    .getElementsByTagName("resourceString");
            if (nodeListResourceString == null
                    || nodeListResourceString.getLength() == 0) {
                // Skips if there are none.
                continue;
            }

            checkMessageFormat(structure.getName(), structure.getDescription(),
                    mapBundle, fieldResourceId, nodeListResourceString,
                    fIsFailOnMessageFormatError);
        }
    }

    /**
     * Checks for the presence of duplicate locales.
     *
     * @param argBaseName
     * @param argDescription
     * @param argListKnownLocale
     * @param argListCommonList
     */
    private void checkLocaleDup(final String argBaseName,
            final String argDescription,
            final List<java.lang.String> argListKnownLocale,
            final NodeList argListCommonList) {
        // Checks for duplicate locales.
        final NodeList listLocale = ((Element) argListCommonList.item(0))
                .getElementsByTagName("locale");
        if (listLocale == null || listLocale.getLength() == 0) {
            return;
        }

        final int sizeListLocale = listLocale.getLength();
        if (sizeListLocale > 0) {
            final Map<java.lang.String, java.lang.String> mapExistLocale = new HashMap<java.lang.String, java.lang.String>();
            for (int indexLocale = 0; indexLocale < sizeListLocale; indexLocale++) {
                final Element elementLocale = (Element) listLocale
                        .item(indexLocale);
                final String locale = BlancoStringUtil.null2Blank(BlancoXmlUtil
                        .getTextContent(elementLocale));
                if (mapExistLocale.get(locale) != null) {
                    // A duplicate locale was found.
                    throw new IllegalArgumentException(fMsg.getMbrbi006(
                            argBaseName
                                    + (argDescription == null ? "" : "/"
                                            + argDescription), locale));
                }
                argListKnownLocale.add(locale);
                mapExistLocale.put(locale, locale);
            }
        }
    }

    /**
     * Checks whether the result of parsing a message format is valid across locales.
     *
     * If there is a difference between locales, aborts the process with an exception.
     *
     * @param argBaseName
     *            Base name.
     * @param argDescription
     *            Description. Used when an exception occurs.
     * @param argMapBundle
     * @param argFieldResourceId
     *            Resource ID.
     * @param argNodeListResourceString
     * @param argIsFailOnMessageFormatError
     *            Whether or not to abort processing when an exception occurs as a result of parsing with MessageFormat.
     */
    private void checkMessageFormat(final String argBaseName,
            final String argDescription,
            final Map<java.lang.String, java.lang.String> argMapBundle,
            final String argFieldResourceId,
            final NodeList argNodeListResourceString,
            final boolean argIsFailOnMessageFormatError) {
        final Map<java.lang.String, java.lang.String> mapProcessedLocale = new HashMap<java.lang.String, java.lang.String>();
        Format[] previousFormatList = null;

        final int nodeListResourceStringSize = argNodeListResourceString
                .getLength();
        for (int indexResourceString = 0; indexResourceString < nodeListResourceStringSize; indexResourceString++) {
            if (argNodeListResourceString.item(indexResourceString) instanceof Element == false) {
                continue;
            }

            final Element elementResourceString = (Element) argNodeListResourceString
                    .item(indexResourceString);
            final String resourceString = BlancoStringUtil
                    .null2Blank(BlancoXmlUtil
                            .getTextContent(elementResourceString));
            final String locale = BlancoStringUtil
                    .null2Blank(elementResourceString.getAttribute("locale"));
            if (mapProcessedLocale.get(locale) != null) {
                // If the locale has already been processed, it will be considered a resource ID duplication error.
                throw new IllegalArgumentException(fMsg.getMbrbi007(argBaseName
                        + (argDescription == null ? "" : "/" + argDescription),
                        locale, argFieldResourceId));
            }

            // Memorizes it as a new locale to be processed.
            mapProcessedLocale.put(locale, locale);
            if (argMapBundle.get(argFieldResourceId) == null) {
                // Stores it in the map of the resource bundle.
                argMapBundle.put(argFieldResourceId, resourceString);
            }

            Format[] formatList = null;
            try {
                formatList = BlancoResourceBundleUtil
                        .getFormatsByArgumentIndex(resourceString,
                                argIsFailOnMessageFormatError);
            } catch (IllegalArgumentException ex) {
                throw new IllegalArgumentException(fMsg.getMbrbi008(
                        argBaseName, locale, argFieldResourceId,
                        BlancoJavaSourceUtil
                                .escapeStringAsJavaSource(resourceString))
                        + ex.toString());
            }

            if (indexResourceString == 0) {
                // No comparison will be made the first time.
            } else {
                if (previousFormatList == null && formatList == null) {
                    // It's a match. No problem.
                } else if (previousFormatList == null && formatList != null) {
                    throw new IllegalArgumentException(fMsg.getMbrbi009(
                            argBaseName
                                    + (argDescription == null ? "" : "/"
                                            + argDescription), locale,
                            argFieldResourceId, String
                                    .valueOf(formatList.length)));
                } else if (previousFormatList != null && formatList == null) {
                    throw new IllegalArgumentException(fMsg.getMbrbi010(
                            argBaseName
                                    + (argDescription == null ? "" : "/"
                                            + argDescription), locale,
                            argFieldResourceId, String
                                    .valueOf(previousFormatList.length)));
                } else {
                    if (previousFormatList.length != formatList.length) {
                        throw new IllegalArgumentException(fMsg.getMbrbi011(
                                argBaseName
                                        + (argDescription == null ? "" : "/"
                                                + argDescription), locale,
                                argFieldResourceId, String
                                        .valueOf(formatList.length), String
                                        .valueOf(previousFormatList.length)));
                    }
                    for (int indexFormat = 0; indexFormat < formatList.length; indexFormat++) {
                        final String previousFormatClass = (previousFormatList[indexFormat] == null ? fBundle
                                .getExpandresourceSrc051()
                                : previousFormatList[indexFormat].getClass()
                                        .getName());
                        final String formatClass = (formatList[indexFormat] == null ? fBundle
                                .getExpandresourceSrc051()
                                : formatList[indexFormat].getClass().getName());
                        if (formatClass.equals(previousFormatClass) == false) {
                            throw new IllegalArgumentException(fMsg
                                    .getMbrbi012(argBaseName
                                            + (argDescription == null ? ""
                                                    : "/" + argDescription),
                                            locale, argFieldResourceId,
                                            formatClass, previousFormatClass));
                        }
                    }
                }
            }
            // Memorizes as the previous list.
            // The key point is that even if it is null, it will be memorized.
            previousFormatList = formatList;
        }
    }
}
