/*
 * blanco Framework
 * Copyright (C) 2004-2007 IGA Tosiki
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 */
package blanco.resourcebundle;

import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.text.DateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import blanco.commons.io.Native2AsciiWriter;
import blanco.commons.util.BlancoFileUtil;
import blanco.commons.util.BlancoStringUtil;
import blanco.resourcebundle.resourcebundle.BlancoResourceBundleResourceBundle;
import blanco.resourcebundle.valueobject.BlancoResourceBundleBundleItemStructure;
import blanco.resourcebundle.valueobject.BlancoResourceBundleBundleStructure;

/**
 * Generates a property file from an intermediate XML file.
 *
 * This source code is part of the blancoResourceBundle.<br>
 * Inputs XML and outputs to a property file.<br>
 * The source of information referenced as the property file specification is the Properties class description below.<br>
 * http://java.sun.com/j2se/1.5.0/docs/api/java/util/Properties.html#store(java.
 * io.OutputStream,%20java.lang.String)
 *
 * @author IGA Tosiki
 */
public class BlancoResourceBundleXml2Properties {
    /**
     * Prefix for output to the command line.
     */
    private static final String CMDLINE_PREFIX = "rb: ";

    /**
     * An instance of a resource bundle accessor.
     */
    private BlancoResourceBundleResourceBundle fBundle = new BlancoResourceBundleResourceBundle();

    /**
     * Whether to output timestamps to comments in property files.
     */
    private boolean fCommentTimestamp = true;

    /**
     * Whether to output property files with directories.
     */
    private boolean fPropertieswithdirectory = true;

    /**
     * Sets the flag whether or not to embed the processing date as a comment in the property file.
     *
     * @param isCommentTimestamp
     *            Whether to embed the processing date; if true, embed.
     */
    public void setCommentTimestamp(final boolean isCommentTimestamp) {
        fCommentTimestamp = isCommentTimestamp;
    }

    /**
     * Sets the flag whether to output property files with directories or not.
     *
     * @param isPropertieswithdirectory
     *            Whether to output property files with directories.
     */
    public void setPropertieswithdirectory(
            final boolean isPropertieswithdirectory) {
        fPropertieswithdirectory = isPropertieswithdirectory;
    }

    /**
     * Style of the source code generation destination directory.
     */
    private boolean fTargetStyleAdvanced = false;
    public void setTargetStyleAdvanced(boolean argTargetStyleAdvanced) {
        this.fTargetStyleAdvanced = argTargetStyleAdvanced;
    }
    public boolean isTargetStyleAdvanced() {
        return this.fTargetStyleAdvanced;
    }

    /**
     * Generates a property file from an intermediate XML file.
     *
     * @param fileSource
     *            Intermediate XML file.
     * @param directoryTarget
     *            Output destination directory.
     */
    public void process(final File fileSource, final File directoryTarget) {

        /*
         * The output directory will be in the format specified by the targetStyle argument of the ant task.
         * To maintain compatibility with the previous version, it will be blanco/main if not specified.
         * by tueda, 2019/08/30
         */
        String strTarget = directoryTarget
                .getAbsolutePath(); // advanced
        if (!this.isTargetStyleAdvanced()) {
            strTarget += "/main"; // legacy
        }
        final File fileBlancoMain = new File(strTarget);

        if (fileBlancoMain.exists() == false) {
            // Since there is no directory, creates a new one.
            fileBlancoMain.mkdirs();
        }

        final Map<java.lang.String, java.lang.String> mapProcessedBaseName = new HashMap<java.lang.String, java.lang.String>(
                64);
        final BlancoResourceBundleBundleStructure[] structures = new BlancoResourceBundleXmlParser()
                .parse(fileSource);
        for (int index = 0; index < structures.length; index++) {
            if (mapProcessedBaseName.get(structures[index].getName()) == null) {
                // System.out.println("The base name [" + baseName + "]
                // appeared for the first time. Locale ["
                // + locale + "] is also used as a resource when no locale is specified.");
                structure2Properties(structures[index], null, fileBlancoMain);
                mapProcessedBaseName.put(structures[index].getName(),
                        structures[index].getCurrentLocale());
            }
            structure2Properties(structures[index], structures[index]
                    .getCurrentLocale(), fileBlancoMain);
        }
    }

    /**
     * Expands the property file.
     *
     * @param resourceBase
     *            Structure.
     * @param locale
     *            Locale.
     * @param directoryTarget
     *            Output destination directory.
     */
    public void structure2Properties(
            final BlancoResourceBundleBundleStructure resourceBase,
            final String locale, final File directoryTarget) {
        final String resourceDefinitionId = resourceBase.getName();

        String subDirectory = "";
        if (fPropertieswithdirectory) {
            subDirectory = "/"
                    + BlancoStringUtil.replace(resourceBase.getPackage(), ".",
                            "/", true);
        }

        // Fixes the file name.
        String fileName = null;
        if (locale == null) {
            fileName = directoryTarget.getAbsolutePath() + subDirectory + "/"
                    + resourceDefinitionId + ".properties";
        } else {
            fileName = directoryTarget.getAbsolutePath() + subDirectory + "/"
                    + resourceDefinitionId + "_" + locale + ".properties";
        }

        final File fileTarget = new File(fileName);

        {
            // Checks for the existence of the destination directory.
            final File dirParent = fileTarget.getAbsoluteFile().getParentFile();
            if (dirParent.exists() == false) {
                // If not, creates one.
                dirParent.mkdirs();
            }
        }

        final ByteArrayOutputStream outStream = new ByteArrayOutputStream();
        Native2AsciiWriter writer = null;
        try {

            // The property file is encoded in 8859_1.
            writer = new Native2AsciiWriter(new BufferedWriter(
                    new OutputStreamWriter(outStream, "8859_1")));

            writer
                    .writeComment(" blancoResourceBundle properties file for locale ["
                            + (locale == null ? "default" : locale) + "]");

            if (fCommentTimestamp) {
                writer.writeComment(" generated at "
                        + DateFormat.getDateInstance().format(new Date()) + " "
                        + DateFormat.getTimeInstance().format(new Date()));
            }

            final List<BlancoResourceBundleBundleItemStructure> listResource = resourceBase
                    .getItemList();
            // Even if none is specified, the file will be generated.

            final int sizeListRow = listResource.size();
            for (int indexField = 0; indexField < sizeListRow; indexField++) {
                final BlancoResourceBundleBundleItemStructure elementResource = listResource
                        .get(indexField);

                final String fieldResourceId = elementResource.getKey();
                String fieldResourceString = null;
                if (elementResource.getResourceStringList().size() > 0) {
                    fieldResourceString = elementResource
                            .getResourceStringList().get(0).getResourceString();
                }

                if (BlancoStringUtil.null2Blank(fieldResourceId).length() == 0) {
                    // If the resource ID is null, it is not a property.
                    if (fieldResourceString != null) {
                        // If the resource ID is null, but a string is specified, it is treated as a comment.
                        writer.writeComment(fieldResourceString);
                    }
                } else {
                    writer.writeProperty(fBundle.getKeyPrefix()
                            + fieldResourceId,
                            (fieldResourceString == null ? ""
                                    : fieldResourceString));
                }
            }
            writer.flush();
            outStream.flush();

            // Creates or updates files only when necessary.
            switch (BlancoFileUtil.bytes2FileIfNecessary(outStream
                    .toByteArray(), fileTarget)) {
            case 0:
                // System.out.println(CMDLINE_PREFIX + "skip : "
                // + fileTarget.getAbsolutePath());
                break;
            case 1:
                System.out.println(CMDLINE_PREFIX + "create: "
                        + fileTarget.getAbsolutePath());
                break;
            case 2:
                System.out.println(CMDLINE_PREFIX + "update: "
                        + fileTarget.getAbsolutePath());
                break;
            }

        } catch (IOException e) {
            throw new IllegalArgumentException("An I/O exception occurred when outputting the property file [" + fileName
                    + "]." + e.toString());
        } finally {
            if (writer != null) {
                try {
                    writer.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
