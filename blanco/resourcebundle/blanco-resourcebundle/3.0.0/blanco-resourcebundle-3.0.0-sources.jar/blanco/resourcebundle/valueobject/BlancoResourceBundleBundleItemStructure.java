package blanco.resourcebundle.valueobject;

import java.util.List;

/**
 * リソースバンドルのキー＋値をあらわす構造体クラス。キー値と文字列を含みます。
 */
public class BlancoResourceBundleBundleItemStructure {
    /**
     * 項目番号。
     *
     * フィールド: [no]。
     */
    private String fNo;

    /**
     * リソースバンドル上のキー値。
     *
     * フィールド: [key]。
     */
    private String fKey;

    /**
     * リソース文字列のリスト。BlancoResourceBundleBundleResourceStringStructureクラスのインスタンスがリストで格納されます。非Combineの場合には、MAX１件が含まれます。Combineの場合には、ロケールごとに１件。
     *
     * フィールド: [resourceStringList]。
     * デフォルト: [new java.util.ArrayList&lt;blanco.resourcebundle.valueobject.BlancoResourceBundleBundleResourceStringStructure&gt;()]。
     */
    private List<BlancoResourceBundleBundleResourceStringStructure> fResourceStringList = new java.util.ArrayList<blanco.resourcebundle.valueobject.BlancoResourceBundleBundleResourceStringStructure>();

    /**
     * フィールド [no] の値を設定します。
     *
     * フィールドの説明: [項目番号。]。
     *
     * @param argNo フィールド[no]に設定する値。
     */
    public void setNo(final String argNo) {
        fNo = argNo;
    }

    /**
     * フィールド [no] の値を取得します。
     *
     * フィールドの説明: [項目番号。]。
     *
     * @return フィールド[no]から取得した値。
     */
    public String getNo() {
        return fNo;
    }

    /**
     * フィールド [key] の値を設定します。
     *
     * フィールドの説明: [リソースバンドル上のキー値。]。
     *
     * @param argKey フィールド[key]に設定する値。
     */
    public void setKey(final String argKey) {
        fKey = argKey;
    }

    /**
     * フィールド [key] の値を取得します。
     *
     * フィールドの説明: [リソースバンドル上のキー値。]。
     *
     * @return フィールド[key]から取得した値。
     */
    public String getKey() {
        return fKey;
    }

    /**
     * フィールド [resourceStringList] の値を設定します。
     *
     * フィールドの説明: [リソース文字列のリスト。BlancoResourceBundleBundleResourceStringStructureクラスのインスタンスがリストで格納されます。非Combineの場合には、MAX１件が含まれます。Combineの場合には、ロケールごとに１件。]。
     *
     * @param argResourceStringList フィールド[resourceStringList]に設定する値。
     */
    public void setResourceStringList(final List<BlancoResourceBundleBundleResourceStringStructure> argResourceStringList) {
        fResourceStringList = argResourceStringList;
    }

    /**
     * フィールド [resourceStringList] の値を取得します。
     *
     * フィールドの説明: [リソース文字列のリスト。BlancoResourceBundleBundleResourceStringStructureクラスのインスタンスがリストで格納されます。非Combineの場合には、MAX１件が含まれます。Combineの場合には、ロケールごとに１件。]。
     * デフォルト: [new java.util.ArrayList&lt;blanco.resourcebundle.valueobject.BlancoResourceBundleBundleResourceStringStructure&gt;()]。
     *
     * @return フィールド[resourceStringList]から取得した値。
     */
    public List<BlancoResourceBundleBundleResourceStringStructure> getResourceStringList() {
        return fResourceStringList;
    }

    /**
     * Gets the string representation of this value object.
     *
     * <P>Precautions for use</P>
     * <UL>
     * <LI>Only the shallow range of the object will be subject to the stringification process.
     * <LI>Do not use this method if the object has a circular reference.
     * </UL>
     *
     * @return String representation of a value object.
     */
    @Override
    public String toString() {
        final StringBuffer buf = new StringBuffer();
        buf.append("blanco.resourcebundle.valueobject.BlancoResourceBundleBundleItemStructure[");
        buf.append("no=" + fNo);
        buf.append(",key=" + fKey);
        buf.append(",resourceStringList=" + fResourceStringList);
        buf.append("]");
        return buf.toString();
    }

    /**
     * Copies this value object to the specified target.
     *
     * <P>Cautions for use</P>
     * <UL>
     * <LI>Only the shallow range of the object will be subject to the copying process.
     * <LI>Do not use this method if the object has a circular reference.
     * </UL>
     *
     * @param target target value object.
     */
    public void copyTo(final BlancoResourceBundleBundleItemStructure target) {
        if (target == null) {
            throw new IllegalArgumentException("Bug: BlancoResourceBundleBundleItemStructure#copyTo(target): argument 'target' is null");
        }

        // No needs to copy parent class.

        // Name: fNo
        // Type: java.lang.String
        target.fNo = this.fNo;
        // Name: fKey
        // Type: java.lang.String
        target.fKey = this.fKey;
        // Name: fResourceStringList
        // Type: java.util.List
        // Field[fResourceStringList] is an unsupported type[java.util.Listblanco.resourcebundle.valueobject.BlancoResourceBundleBundleResourceStringStructure].
    }
}
