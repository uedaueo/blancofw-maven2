/*
 * blanco Framework
 * Copyright (C) 2004-2007 IGA Tosiki
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 */
package blanco.resourcebundle;

import java.text.Format;
import java.text.MessageFormat;

public class BlancoResourceBundleUtil {
    /**
     * Obtains format information from MessageFormat.
     * 
     * This method is used by blancoMessage in addition to blancoResourceBundle.
     * 
     * @param argResourceString
     *            Resource string.
     * @param argIsFailOnMessageFormatError
     *            Whether to treat it as an error when parsed as MessageFormat.
     * @return An array of formats after analysis.
     */
    public static final Format[] getFormatsByArgumentIndex(
            final String argResourceString,
            final boolean argIsFailOnMessageFormatError) {
        try {
            final MessageFormat messageFormat = new MessageFormat(
                    argResourceString);
            return messageFormat.getFormatsByArgumentIndex();

        } catch (IllegalArgumentException ex) {
            if (argIsFailOnMessageFormatError) {
                throw ex;
            }

            // Ignores the error and behaves as if nothing happened.
            return new Format[0];
        }
    }
}
