/*
 * blanco Framework
 * Copyright (C) 2004-2007 IGA Tosiki
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 */
package blanco.resourcebundle.expand;

import java.io.File;
import java.text.Format;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import blanco.cg.BlancoCgObjectFactory;
import blanco.cg.transformer.BlancoCgTransformerFactory;
import blanco.cg.valueobject.BlancoCgClass;
import blanco.cg.valueobject.BlancoCgField;
import blanco.cg.valueobject.BlancoCgMethod;
import blanco.cg.valueobject.BlancoCgSourceFile;
import blanco.commons.util.BlancoBigDecimalUtil;
import blanco.commons.util.BlancoJavaSourceUtil;
import blanco.commons.util.BlancoNameAdjuster;
import blanco.commons.util.BlancoStringUtil;
import blanco.resourcebundle.BlancoResourceBundleUtil;
import blanco.resourcebundle.resourcebundle.BlancoResourceBundleResourceBundle;
import blanco.resourcebundle.valueobject.BlancoResourceBundleBundleItemStructure;
import blanco.resourcebundle.valueobject.BlancoResourceBundleBundleResourceStringStructure;
import blanco.resourcebundle.valueobject.BlancoResourceBundleBundleStructure;

/**
 * Internal process to generate a property file from an intermediate XML file.
 *
 * This source code is part of the blancoResourceBundle.<br>
 * Outputs a file with XML DOM elements as input. <br>
 *
 * Assumption of operation: It is assumed to be pre-checked by the BlancoResourceBundleXmlValidator class.
 *
 * @author IGA Tosiki
 */
public class BlancoResourceBundleExpandResourceBundle {
    /**
     * An instance of a resource bundle accessor.
     */
    private final BlancoResourceBundleResourceBundle fBundle = new BlancoResourceBundleResourceBundle();

    /**
     * A factory for blancoCg to be used internally.
     */
    private BlancoCgObjectFactory fCgFactory = null;

    /**
     * Source file information for blancoCg to be used internally.
     */
    private BlancoCgSourceFile fCgSourceFile = null;

    /**
     * Class information for blancoCg to be used internally.
     */
    private BlancoCgClass fCgClass = null;

    /**
     * Style of the source code generation destination directory.
     */
    private boolean fTargetStyleAdvanced = false;
    public void setTargetStyleAdvanced(boolean argTargetStyleAdvanced) {
        this.fTargetStyleAdvanced = argTargetStyleAdvanced;
    }
    public boolean isTargetStyleAdvanced() {
        return this.fTargetStyleAdvanced;
    }

    /**
     * Expands the specified information into source code.
     *
     * The source code output flag toggles whether the source code is output or not.
     *
     * @param argStructure
     *            Structure.
     * @param argDirectoryTarget
     *            Target directory for output.
     * @param argEncoding
     *            Character encoding of the source code to be generated.
     * @param argIsFailOnMessageFormatError
     *            Sets the flag whether or not to abort the process if an exception occurs when parsing a message string with MessageFormat.
     *.@param argIsLog
     *            Whether to include log output in the auto-generated source code.
     * @param argPropertieswithdirectory
     *            Whether to output property files with directories.
     */
    public void expand(final BlancoResourceBundleBundleStructure argStructure,
            final File argDirectoryTarget, final String argEncoding,
            final boolean argIsFailOnMessageFormatError,
            final boolean argIsLog, final boolean argPropertieswithdirectory) {
        // The class name will be transformed.
        final String className = BlancoNameAdjuster.toClassName(argStructure
                .getName())
                + (argStructure.getSuffix() == null ? "" : argStructure
                        .getSuffix());

        final List<java.lang.String> listKnownLocale = new ArrayList<java.lang.String>();
        final Map<java.lang.String, java.lang.String> mapBundle = new HashMap<java.lang.String, java.lang.String>();

        /*
         * The output directory will be in the format specified by the targetStyle argument of the ant task.
         * For compatibility, the output directory will be blanco/main if it is not specified.
         * by tueda, 2019/08/30
         */
        String strTarget = argDirectoryTarget
                .getAbsolutePath(); // advanced
        if (!this.isTargetStyleAdvanced()) {
            strTarget += "/main"; // legacy
        }
        final File fileBlancoMain = new File(strTarget);

        fCgFactory = BlancoCgObjectFactory.getInstance();
        fCgSourceFile = fCgFactory.createSourceFile(argStructure.getPackage(),
                null);
        fCgSourceFile.setEncoding(argEncoding);

        fCgClass = fCgFactory.createClass(className, null);
        fCgSourceFile.getClassList().add(fCgClass);

        // Sets the access.
        fCgClass.setAccess(argStructure.getAccess());

        if (argStructure.getDescription() != null) {
            fCgClass.setDescription(argStructure.getDescription());
        }

        fCgClass.getLangDoc().getDescriptionList().add(
                fBundle.getExpandresourceSrc011(argStructure.getName()));

        fCgClass.getLangDoc().getDescriptionList().add(
                fBundle.getExpandresourceSrc012());

        String bundleFullPathName = argStructure.getName();
        if (argPropertieswithdirectory) {
            bundleFullPathName = BlancoStringUtil.replace(argStructure
                    .getPackage(), ".", "/", true)
                    + "/" + bundleFullPathName;
        }

        /* Sets the annotations for the class. */
        {
            List<String> annotationList = argStructure.getAnnotationList();
            if (annotationList != null && annotationList.size() > 0) {
                fCgClass.getAnnotationList().addAll(argStructure.getAnnotationList());
                /* tueda DEBUG */
                System.out.println("/* tueda */ structure2Source : class annotation = " + argStructure.getAnnotationList().get(0));
            }
        }

        /* Creates import statements. */
        {
            for (int index = 0; index < argStructure.getImportList()
                    .size(); index++) {
                final String imported = (String) argStructure.getImportList()
                        .get(index);
                fCgSourceFile.getImportList().add(imported);
            }
        }

        {
            final int sizeListLocale = argStructure.getListLocale().size();
            if (sizeListLocale > 0) {
                fCgClass.getLangDoc().getDescriptionList().add(
                        fBundle.getExpandresourceSrc013());
                fCgClass.getLangDoc().getDescriptionList().add("<UL>");
                for (int indexLocale = 0; indexLocale < sizeListLocale; indexLocale++) {
                    final String locale = (String) argStructure.getListLocale()
                            .get(indexLocale);
                    listKnownLocale.add(locale);
                    fCgClass.getLangDoc().getDescriptionList().add(
                            "<LI>" + locale);
                }
                fCgClass.getLangDoc().getDescriptionList().add("</UL>");
            }

            final BlancoCgField field1 = fCgFactory.createField(
                    "fResourceBundle", "java.util.ResourceBundle", fBundle
                            .getExpandresourceSrc014());
            fCgClass.getFieldList().add(field1);
            field1.getLangDoc().getDescriptionList().add(
                    fBundle.getExpandresourceSrc015());

            {
                final BlancoCgMethod method = fCgFactory.createMethod(
                        className, fBundle.getExpandresourceSrc021(className));
                fCgClass.getMethodList().add(method);
                method.setConstructor(true);
                method.getLangDoc().getDescriptionList()
                        .add(
                                fBundle.getExpandresourceSrc022(argStructure
                                        .getName()));

                // It should always be imported.
                fCgSourceFile.getImportList().add(
                        "java.util.MissingResourceException");

                final List<java.lang.String> listLine = method.getLineList();

                listLine.add("try {");
                listLine.add("fResourceBundle = ResourceBundle.getBundle(\""
                        + bundleFullPathName + "\");");
                listLine.add("} catch (MissingResourceException ex) {");
                if (argIsLog) {
                    listLine.add("final String message = \""
                            + fBundle.getExpandresourceSrc023(argStructure
                                    .getName()) + "\" + ex.toString();");
                    fCgSourceFile.getImportList().add(
                            "java.util.logging.Logger");
                    listLine.add("Logger.getLogger(\""
                            + argStructure.getPackage() + "\").fine(message);");
                }
                listLine.add("}");
            }

            {
                final BlancoCgMethod method = fCgFactory.createMethod(
                        className, fBundle.getExpandresourceSrc031(className));
                fCgClass.getMethodList().add(method);
                method.setConstructor(true);
                method.getLangDoc().getDescriptionList()
                        .add(
                                fBundle.getExpandresourceSrc032(argStructure
                                        .getName()));
                method.getParameterList().add(
                        fCgFactory.createParameter("locale",
                                "java.util.Locale", fBundle
                                        .getExpandresourceSrc033()));

                final List<java.lang.String> listLine = method.getLineList();

                listLine.add("try {");
                listLine.add("fResourceBundle = ResourceBundle.getBundle(\""
                        + bundleFullPathName + "\", locale);");
                listLine.add("} catch (MissingResourceException ex) {");
                if (argIsLog) {
                    listLine.add("final String message = \""
                            + fBundle.getExpandresourceSrc034(argStructure
                                    .getName()) + "\" + ex.toString();");
                    fCgSourceFile.getImportList().add(
                            "java.util.logging.Logger");
                    listLine.add("Logger.getLogger(\""
                            + argStructure.getPackage() + "\").fine(message);");
                }
                listLine.add("}");
            }

            {
                final BlancoCgMethod method = fCgFactory.createMethod(
                        className, fBundle.getExpandresourceSrc041(className));
                fCgClass.getMethodList().add(method);
                method.setConstructor(true);
                method.getLangDoc().getDescriptionList()
                        .add(
                                fBundle.getExpandresourceSrc042(argStructure
                                        .getName()));

                method.getParameterList().add(
                        fCgFactory.createParameter("locale",
                                "java.util.Locale", fBundle
                                        .getExpandresourceSrc043()));
                method.getParameterList().add(
                        fCgFactory.createParameter("loader",
                                "java.lang.ClassLoader", fBundle
                                        .getExpandresourceSrc044()));

                final List<java.lang.String> listLine = method.getLineList();

                listLine.add("try {");
                listLine.add("fResourceBundle = ResourceBundle.getBundle(\""
                        + bundleFullPathName + "\", locale, loader);");
                listLine.add("} catch (MissingResourceException ex) {");
                if (argIsLog) {
                    listLine.add("final String message = \""
                            + fBundle.getExpandresourceSrc045(argStructure
                                    .getName()) + "\" + ex.toString();");
                    fCgSourceFile.getImportList().add(
                            "java.util.logging.Logger");
                    listLine.add("Logger.getLogger(\""
                            + argStructure.getPackage() + "\").fine(message);");
                }
                listLine.add("}");
            }

            {
                // getResourceBundle method
                final BlancoCgMethod method = fCgFactory.createMethod(
                        "getResourceBundle", "Gets the resource bundle object held internally.");
                fCgClass.getMethodList().add(method);

                method.setReturn(fCgFactory
                        .createReturn("java.util.ResourceBundle",
                                "The resource bundle object held internally."));

                final List<java.lang.String> listLine = method.getLineList();

                listLine.add("return fResourceBundle;");
            }

            final int sizeListResource = argStructure.getItemList().size();
            for (int indexResource = 0; indexResource < sizeListResource; indexResource++) {
                final BlancoResourceBundleBundleItemStructure itemStructure = (BlancoResourceBundleBundleItemStructure) argStructure
                        .getItemList().get(indexResource);

                final BlancoCgMethod methodGet = fCgFactory.createMethod("get"
                        + BlancoNameAdjuster
                                .toClassName(itemStructure.getKey()), "bundle["
                        + argStructure.getName() + "], key["
                        + itemStructure.getKey() + "]");
                fCgClass.getMethodList().add(methodGet);

                final Map<java.lang.String, java.lang.String> mapProcessedLocale = new HashMap<java.lang.String, java.lang.String>();
                for (int indexResourceString = 0; indexResourceString < itemStructure
                        .getResourceStringList().size(); indexResourceString++) {

                    final BlancoResourceBundleBundleResourceStringStructure resourceStringStructure = (BlancoResourceBundleBundleResourceStringStructure) itemStructure
                            .getResourceStringList().get(indexResourceString);

                    methodGet
                            .getLangDoc()
                            .getDescriptionList()
                            .add(
                                    "["
                                            + BlancoJavaSourceUtil
                                                    .escapeStringAsJavaDoc(BlancoStringUtil
                                                            .null2Blank(resourceStringStructure
                                                                    .getResourceString()))
                                            + "] ("
                                            + resourceStringStructure
                                                    .getLocale() + ")<br>");

                    // Memorizes that it is a processed locale.
                    mapProcessedLocale.put(resourceStringStructure.getLocale(),
                            resourceStringStructure.getLocale());
                    if (mapBundle.get(itemStructure.getKey()) == null) {
                        mapBundle.put(itemStructure.getKey(),
                                resourceStringStructure.getResourceString());
                    }

                    // We do not expect formatting exceptions to occur, because they have already been resolved by prior checks. 
                    final Format[] formatList = BlancoResourceBundleUtil
                            .getFormatsByArgumentIndex(BlancoStringUtil
                                    .null2Blank(resourceStringStructure
                                            .getResourceString()),
                                    argIsFailOnMessageFormatError);
                    for (int indexFormat = 0; indexFormat < formatList.length; indexFormat++) {
                        String strArgType = "java.lang.String";
                        if (formatList[indexFormat] == null) {
                            // No format:
                            // Mapping to java.lang.String is reasonable.
                            strArgType = "java.lang.String";
                        } else if (formatList[indexFormat] instanceof java.text.NumberFormat) {
                            // Mapping to java.math.BigDecimal is reasonable.
                            strArgType = "java.math.BigDecimal";
                        } else if (formatList[indexFormat] instanceof java.text.DateFormat) {
                            // Mapping to java.util.Date is reasonable.
                            strArgType = "java.util.Date";
                        } else if (formatList[indexFormat] instanceof java.text.ChoiceFormat) {
                            // Mapping to int is reasonable.
                            strArgType = "int";
                        } else {
                            strArgType = "java.lang.String";
                        }
                        if (indexResourceString == 0) {
                            // Generates method arguments only the first time.
                            methodGet
                                    .getParameterList()
                                    .add(
                                            fCgFactory
                                                    .createParameter(
                                                            "arg" + indexFormat,
                                                            strArgType,
                                                            fBundle
                                                                    .getExpandresourceSrc101(
                                                                            BlancoBigDecimalUtil
                                                                                    .toBigDecimal(indexFormat),
                                                                            strArgType)));
                        }
                    }
                    methodGet.setReturn(fCgFactory.createReturn(
                            "java.lang.String", fBundle
                                    .getExpandresourceSrc102(itemStructure
                                            .getKey())));
                }

                // Checks to see if all locales are in place.
                for (int indexCheck = 0; indexCheck < listKnownLocale.size(); indexCheck++) {
                    final String localeCheck = (String) listKnownLocale
                            .get(indexCheck);
                    final Object objCheck = mapProcessedLocale.get(localeCheck);
                    if (objCheck == null) {
                        // Even if it doesn't have them all, it only outputs a warning to JavaDoc.
                        methodGet.getLangDoc().getDescriptionList().add(
                                fBundle.getExpandresourceSrc103(localeCheck));
                    }
                }

                final String resourceString = (String) mapBundle
                        .get(itemStructure.getKey());

                final List<java.lang.String> listLine = methodGet.getLineList();

                listLine.add("// " + fBundle.getExpandresourceSrc104());
                listLine.add("String strFormat = \""
                        + BlancoJavaSourceUtil
                                .escapeStringAsJavaSource(BlancoStringUtil
                                        .null2Blank(resourceString)) + "\";");
                listLine.add("try {");
                listLine.add("if (fResourceBundle != null) {");
                listLine.add("strFormat = fResourceBundle.getString(\""
                        + BlancoJavaSourceUtil.escapeStringAsJavaSource(fBundle
                                .getKeyPrefix()
                                + itemStructure.getKey()) + "\");");
                listLine.add("}");
                listLine.add("} catch (MissingResourceException ex) {");
                if (argIsLog) {
                    listLine.add("final String message = \""
                            + fBundle.getExpandresourceSrc105(argStructure
                                    .getName(), fBundle.getKeyPrefix()
                                    + itemStructure.getKey())
                            + "\" + ex.toString();");
                    fCgSourceFile.getImportList().add(
                            "java.util.logging.Logger");
                    listLine.add("Logger.getLogger(\""
                            + argStructure.getPackage() + "\").fine(message);");
                }
                listLine.add("}");

                final Format[] formatList = BlancoResourceBundleUtil
                        .getFormatsByArgumentIndex(BlancoStringUtil
                                .null2Blank(resourceString),
                                argIsFailOnMessageFormatError);
                if (formatList.length > 0) {
                    String strArgForFormat = "";
                    for (int index = 0; index < formatList.length; index++) {
                        if (index != 0) {
                            strArgForFormat += ", ";
                        }
                        strArgForFormat += ("arg" + index);
                    }

                    fCgSourceFile.getImportList()
                            .add("java.text.MessageFormat");

                    listLine
                            .add("final MessageFormat messageFormat = new MessageFormat(strFormat);");
                    listLine
                            .add("final StringBuffer strbuf = new StringBuffer();");
                    listLine.add("// " + fBundle.getExpandresourceSrc106());
                    listLine.add("messageFormat.format(new Object[] {"
                            + strArgForFormat + "}, strbuf, null);");

                    listLine.add("return strbuf.toString();");
                } else {
                    listLine.add("// " + fBundle.getExpandresourceSrc107());
                    listLine.add("return strFormat;");
                }

            }
        }

        // Generates the actual source code.
        BlancoCgTransformerFactory.getJavaSourceTransformer().transform(
                fCgSourceFile, fileBlancoMain);
    }
}
