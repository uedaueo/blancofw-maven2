/*
 * blanco Framework
 * Copyright (C) 2004-2007 IGA Tosiki
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 */
package blanco.resourcebundle;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import javax.xml.transform.dom.DOMResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;

import blanco.commons.util.BlancoNameAdjuster;
import blanco.commons.util.BlancoXmlUtil;
import blanco.resourcebundle.resourcebundle.BlancoResourceBundleResourceBundle;
import blanco.resourcebundle.valueobject.BlancoResourceBundleBundleStructure;

/**
 * Generates a constant class for only the key part of a property file from an intermediate XML file.
 * 
 * This source code is part of the blancoResourceBundle.<br>
 * Internally, generates an XML file for blancoConstants.
 * 
 * @author IGA Tosiki
 */
public class BlancoResourceBundleXml2ConstantsXml {
    /**
     * An instance of a resource bundle accessor.
     */
    private final BlancoResourceBundleResourceBundle fBundle = new BlancoResourceBundleResourceBundle();

    /**
     * Generates a constant class for only the key part of a property file from an intermediate XML file.
     * 
     * @param argFileSource
     *            An intermediate XML file as input.
     * @param argTmpResourceBundleDirectory
     *            Output directory for intermediate XML files for blancoConstants.
     */
    public void process(final File argFileSource,
            final File argTmpResourceBundleDirectory) {
        final DOMResult result = BlancoXmlUtil.transformFile2Dom(argFileSource);

        final Node rootNode = result.getNode();
        if (rootNode instanceof Document) {
            // This is the normal system. Gets the document root.
            final Document rootDocument = (Document) rootNode;
            final NodeList listSheet = rootDocument
                    .getElementsByTagName("sheet");
            final int sizeListSheet = listSheet.getLength();
            for (int index = 0; index < sizeListSheet; index++) {
                final Element elementSheet = (Element) listSheet.item(index);
                // System.out.println("Sheet [" + elementSheet.getAttribute("name")
                // + "] is being processed.");

                final NodeList listCommon = elementSheet
                        .getElementsByTagName(fBundle
                                .getMeta2xmlElementCommon());
                if (listCommon.getLength() == 0) {
                    // Skips if there is no common.
                    continue;
                }

                final Element elementCommon = (Element) listCommon.item(0);
                final String baseName = BlancoXmlUtil.getTextContent(
                        elementCommon, "baseName");
                if (baseName == null) {
                    continue;
                }

                if (BlancoXmlUtil.getTextContent(elementCommon, "packageName") == null) {
                    continue;
                }

                final List<java.lang.String> listLocale = new ArrayList<java.lang.String>();
                final NodeList nodeListCommon = elementCommon
                        .getElementsByTagName("locale");
                for (int indexLocale = 0; indexLocale < nodeListCommon
                        .getLength(); indexLocale++) {
                    final Node nodeLook = nodeListCommon.item(indexLocale);
                    if (nodeLook instanceof Element) {
                        final Element elementLook = (Element) nodeLook;
                        final NodeList nodeChields = elementLook
                                .getChildNodes();
                        for (int indexChild = 0; indexChild < nodeChields
                                .getLength(); indexChild++) {
                            final Node nodeChild = nodeChields.item(indexChild);
                            if (nodeChild instanceof Text) {
                                listLocale.add(((Text) nodeChild)
                                        .getNodeValue());
                            }
                        }
                    }
                }
                if (listLocale.size() == 0) {
                    continue;
                }

                expandSheet(elementSheet, elementCommon,
                        argTmpResourceBundleDirectory);
            }
        }
    }

    /**
     * Expands the node of the sheet.
     * 
     * @param argElementSheet
     *            A sheet element.
     * @param argElementCommon
     *            A common element.
     * @param argTmpResourceBundleDirectory
     *            Output directory for intermediate XML files for blancoConstants.
     */
    private void expandSheet(final Element argElementSheet,
            final Element argElementCommon,
            final File argTmpResourceBundleDirectory) {
        final BlancoResourceBundleBundleStructure structure = new BlancoResourceBundleBundleStructure();
        structure.setName(BlancoXmlUtil.getTextContent(argElementCommon,
                "baseName"));
        // The class name will be transformed.
        final String className = BlancoNameAdjuster.toClassName(structure
                .getName())
                + "Constants";
        structure.setPackage(BlancoXmlUtil.getTextContent(argElementCommon,
                "packageName"));
        structure.setDescription(BlancoXmlUtil.getTextContent(argElementCommon,
                "description"));

        final NodeList listResourceList = argElementSheet
                .getElementsByTagName(fBundle.getMeta2xmlElementList());
        if (listResourceList.getLength() == 0) {
            // Skips if there is no common.
            return;
        }

        new File(argTmpResourceBundleDirectory.getAbsolutePath() + "/constants")
                .mkdirs();

        final Document document = BlancoXmlUtil.newDocument();
        final Element eleWorkbook = document.createElement("workbook");
        document.appendChild(eleWorkbook);

        final Element eleSheet = document.createElement("sheet");
        eleWorkbook.appendChild(eleSheet);

        final Element eleCommon = document
                .createElement("blancoconstants-common");
        eleSheet.appendChild(eleCommon);

        BlancoXmlUtil.addChildElement(document, eleCommon, "name", className);
        BlancoXmlUtil.addChildElement(document, eleCommon, "package", structure
                .getPackage());
        BlancoXmlUtil.addChildElement(document, eleCommon, "description",
                structure.getDescription());
        BlancoXmlUtil.addChildElement(document, eleCommon, "fileDescription",
                structure.getDescription());

        final Element eleList = document.createElement("blancoconstants-list");
        eleSheet.appendChild(eleList);

        final NodeList listResource = ((Element) listResourceList.item(0))
                .getElementsByTagName("resource");
        final int sizeListResource = listResource.getLength();
        for (int indexResource = 0; indexResource < sizeListResource; indexResource++) {
            final Element elementResource = (Element) listResource
                    .item(indexResource);

            final Element eleField = document.createElement("field");
            eleList.appendChild(eleField);

            final String fieldResourceId = BlancoXmlUtil.getTextContent(
                    elementResource, "resourceKey");

            // Does not output “no” on purpose.

            BlancoXmlUtil.addChildElement(document, eleField, "name",
                    fieldResourceId.replaceAll("[.]", "_"));
            BlancoXmlUtil.addChildElement(document, eleField, "type",
                    "java.lang.String");
            BlancoXmlUtil.addChildElement(document, eleField, "value",
                    fieldResourceId);

            String allDescription = "";
            final NodeList nodeListResourceString = elementResource
                    .getElementsByTagName("resourceString");
            for (int indexResourceString = 0; indexResourceString < nodeListResourceString
                    .getLength(); indexResourceString++) {
                if (nodeListResourceString.item(indexResourceString) instanceof Element) {
                    final Element elementResourceString = (Element) nodeListResourceString
                            .item(indexResourceString);
                    final String resourceString = BlancoXmlUtil
                            .getTextContent(elementResourceString);
                    if (resourceString != null) {
                        if (allDescription.length() != 0) {
                            allDescription += "\n";
                        }
                        allDescription += resourceString;
                    }
                }
            }

            // The contents of the actual key will be described in the JavaDoc.
            BlancoXmlUtil.addChildElement(document, eleField, "description",
                    "Content: " + allDescription + " (key: " + fieldResourceId + ")");
        }
        BlancoXmlUtil.transformDom2File(document, new File(
                argTmpResourceBundleDirectory.getAbsolutePath() + "/constants/"
                        + className + ".constantsxml"));
    }
}