/*
 * blanco Framework
 * Copyright (C) 2004-2007 IGA Tosiki
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 */
package blanco.resourcebundle;

import java.io.File;

import blanco.resourcebundle.expand.BlancoResourceBundleExpandResourceBundle;
import blanco.resourcebundle.valueobject.BlancoResourceBundleBundleStructure;

/**
 * Generates Java source code for property file access from an intermediate XML file.
 *
 * This source code is part of the blancoResourceBundle.<br>
 *
 * @author IGA Tosiki
 */
public class BlancoResourceBundleXml2JavaClass {
    /**
     * Flag whether or not to abort the process if an exception occurs when parsing a resource bundle string with MessageFormat.
     *
     * If true, processing will be aborted and an exception will be raised. <br>
     * If false, continues processing and assumes there is no replacement string. <br>
     * In some cases, such as when processing Java source code, you may want to set this flag to false so that braces can be handled. <br>
     * The default value [true] is set.
     */
    private boolean fIsFailOnMessageFormatError = true;

    /**
     * Flag whether or not to include log output in auto-generated source code. Currently, only stdout is supported.
     */
    private boolean fIsLog = false;

    /**
     * Whether to output property files with directories.
     */
    private boolean fPropertieswithdirectory = true;

    /**
     * Character encoding of auto-generated source files.
     */
    private String fEncoding = null;

    public void setEncoding(final String argEncoding) {
        fEncoding = argEncoding;
    }

    /**
     * Sets the flag whether or not to abort the process if an exception occurs when parsing a resource bundle string with MessageFormat.
     *
     * If true, processing will be aborted and an exception will be raised. <br>
     * If false, continues processing and assumes there is no replacement string. <br>
     * In some cases, such as when processing Java source code, you may want to set this flag to false so that braces can be handled. <br>
     * The default value [true] is set.
     *
     * @param isFailOnMessageFormatError
     */
    public void setFailOnMessageFormatError(
            final boolean isFailOnMessageFormatError) {
        fIsFailOnMessageFormatError = isFailOnMessageFormatError;
    }

    /**
     * Style of the source code generation destination directory.
     */
    private boolean fTargetStyleAdvanced = false;
    public void setTargetStyleAdvanced(boolean argTargetStyleAdvanced) {
        this.fTargetStyleAdvanced = argTargetStyleAdvanced;
    }
    public boolean isTargetStyleAdvanced() {
        return this.fTargetStyleAdvanced;
    }

    /**
     * Sets the flag whether or not to include log output in auto-generated source code. 
     *
     * @param argIsLog
     *            Whether or not to include log output in auto-generated source code. 
     */
    public void setLog(final boolean argIsLog) {
        fIsLog = argIsLog;
    }

    /**
     * Set the flag whether to output property files with directories.
     *
     * @param isPropertieswithdirectory
     *            Whether to output property files with directories.
     */
    public void setPropertieswithdirectory(
            final boolean isPropertieswithdirectory) {
        fPropertieswithdirectory = isPropertieswithdirectory;
    }

    /**
     * Generates Java source code for property file access from an intermediate XML file.
     *
     * @param argFileSource
     *            An intermediate XML file as input.
     * @param argDirectoryTarget
     *            Output directory of the source code.
     */
    public void process(final File argFileSource, final File argDirectoryTarget) {
        final BlancoResourceBundleBundleStructure[] structures = new BlancoResourceBundleXmlParser()
                .parse(argFileSource);
        for (int index = 0; index < structures.length; index++) {
            structure2Source(structures[index], argDirectoryTarget);
        }
    }

    /**
     * Expands the description of the specified sheet.
     *
     * @param argStructure
     *            Task structure.
     * @param argDirectoryTarget
     *            Output directory.
     */
    public void structure2Source(
            final BlancoResourceBundleBundleStructure argStructure,
            final File argDirectoryTarget) {
        BlancoResourceBundleExpandResourceBundle expander = new BlancoResourceBundleExpandResourceBundle();
        expander.setTargetStyleAdvanced(this.isTargetStyleAdvanced());
        expander.expand(argStructure,
                argDirectoryTarget, fEncoding, fIsFailOnMessageFormatError,
                fIsLog, fPropertieswithdirectory);
    }
}
