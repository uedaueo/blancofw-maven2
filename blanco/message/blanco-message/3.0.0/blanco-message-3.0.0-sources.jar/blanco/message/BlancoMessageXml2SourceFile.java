/*
 * blanco Framework
 * Copyright (C) 2004-2006 IGA Tosiki
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 */
package blanco.message;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import blanco.cg.BlancoCgObjectFactory;
import blanco.cg.BlancoCgSupportedLang;
import blanco.cg.transformer.BlancoCgTransformerFactory;
import blanco.cg.util.BlancoCgLineUtil;
import blanco.cg.util.BlancoCgSourceUtil;
import blanco.cg.valueobject.BlancoCgClass;
import blanco.cg.valueobject.BlancoCgField;
import blanco.cg.valueobject.BlancoCgMethod;
import blanco.cg.valueobject.BlancoCgSourceFile;
import blanco.commons.util.BlancoNameAdjuster;
import blanco.commons.util.BlancoStringUtil;
import blanco.message.message.BlancoMessageMessage;
import blanco.message.resourcebundle.BlancoMessageResourceBundle;
import blanco.message.valueobject.BlancoMessageFieldStructure;
import blanco.message.valueobject.BlancoMessageStructure;
import blanco.resourcebundle.BlancoResourceBundleUtil;
import blanco.resourcebundle.BlancoResourceBundleXml2JavaClass;
import blanco.resourcebundle.BlancoResourceBundleXml2Properties;
import blanco.resourcebundle.valueobject.BlancoResourceBundleBundleItemStructure;
import blanco.resourcebundle.valueobject.BlancoResourceBundleBundleResourceStringStructure;
import blanco.resourcebundle.valueobject.BlancoResourceBundleBundleStructure;

/**
 * Generates class source code to process messages from "Message Definition" Excel format.
 * 
 * This class is responsible for auto-generating source code from intermediate XML files.
 * 
 * @author IGA Tosiki
 */
public class BlancoMessageXml2SourceFile {
    private final BlancoMessageMessage fMsg = new BlancoMessageMessage();

    /**
     * An access object to the resource bundle for this product.
     */
    private final BlancoMessageResourceBundle fBundle = new BlancoMessageResourceBundle();

    /**
     * Target programming language.
     */
    private int fTargetLang = BlancoCgSupportedLang.NOT_DEFINED;

    /**
     * Whether to output the string as a constant to the class.
     */
    private boolean fIsGenerateConstants = false;

    /**
     * A factory for blancoCg to be used internally.
     */
    private BlancoCgObjectFactory fCgFactory = null;

    /**
     * Source file information for blancoCg to be used internally.
     */
    private BlancoCgSourceFile fCgSourceFile = null;

    /**
     * Class information for blancoCg to be used internally.
     */
    private BlancoCgClass fCgClass = null;

    /**
     * Character encoding of auto-generated source files.
     */
    private String fEncoding = null;

    public void setEncoding(final String argEncoding) {
        fEncoding = argEncoding;
    }

    private boolean fIsJavaJsf = false;

    public void setIsJavaJsf(final boolean arg) {
        fIsJavaJsf = arg;
    }

    private boolean fIsJavaStruts = false;

    public void setIsJavaStruts(final boolean arg) {
        fIsJavaStruts = arg;
    }

    /**
     * Auto-generates source code from intermediate XML files.
     *
     * @param argMetaXmlSourceFile
     *            An XML file that contains meta-information.
     * @param argTargetLang
     *            Target programming language.
     * @param argDirectoryTarget
     *            Output directory of the generated source code (specify the part excluding /main).
     * @param argIsGenerateConstants
     *            Flag whether or not to output string constants to the class.
     * @throws IOException
     *             If an I/O exception occurs.
     */
    public void process(final File argMetaXmlSourceFile, final String argTargetLang,
            final boolean argIsGenerateConstants, final File argDirectoryTarget) throws IOException {

        fTargetLang = new BlancoCgSupportedLang().convertToInt(argTargetLang);
        switch (fTargetLang) {
        case BlancoCgSupportedLang.JAVA:
        case BlancoCgSupportedLang.CS:
        case BlancoCgSupportedLang.JS:
        case BlancoCgSupportedLang.VB:
        case BlancoCgSupportedLang.PHP:
        case BlancoCgSupportedLang.RUBY:
        case BlancoCgSupportedLang.PYTHON:
        case BlancoCgSupportedLang.DELPHI:
            break;
        default:
            throw new IllegalArgumentException(fMsg.getMbmsgi02(argTargetLang));
        }

        fIsGenerateConstants = argIsGenerateConstants;

        final BlancoMessageStructure[] structures = new BlancoMessageXmlParser().parse(argMetaXmlSourceFile);

        for (int index = 0; index < structures.length; index++) {
            // Executes auto-generating source code based on the analysis results of meta information.
            structure2Source(structures[index], argDirectoryTarget);

            if (fTargetLang == BlancoCgSupportedLang.JAVA) {
                expandResourceBundleForJava(structures[index], argDirectoryTarget);
            }
        }
    }

    /**
     * Expands the description of the specified sheet.
     * 
     * @param argStructure
     *            Task structure.
     * @param argDirectoryTarget
     *            Output directory.
     */
    public void structure2Source(final BlancoMessageStructure argStructure, final File argDirectoryTarget) {
        // To make it compatible with the previous version, outputs to the /main subfolder.
        final File fileBlancoMain = new File(argDirectoryTarget.getAbsolutePath() + "/main");

        fCgFactory = BlancoCgObjectFactory.getInstance();
        fCgSourceFile = fCgFactory.createSourceFile(argStructure.getPackage(),
                "This source code has been generated by blanco Framework.");
        fCgSourceFile.setEncoding(fEncoding);
        switch (fTargetLang) {
        case BlancoCgSupportedLang.DELPHI:
            // In Delphi, forces the class name to have a T in accordance with convention in order to avoid name collisions with unit names.
            fCgSourceFile.setName(argStructure.getName() + BlancoStringUtil.null2Blank(argStructure.getSuffix()));
            fCgClass = fCgFactory.createClass("T" + BlancoNameAdjuster.toClassName(argStructure.getName())
                    + BlancoStringUtil.null2Blank(argStructure.getSuffix()),
                    BlancoStringUtil.null2Blank(argStructure.getDescription()));
            break;
        default:
            fCgClass = fCgFactory.createClass(
                    BlancoNameAdjuster.toClassName(argStructure.getName())
                            + BlancoStringUtil.null2Blank(argStructure.getSuffix()),
                    BlancoStringUtil.null2Blank(argStructure.getDescription()));
            break;
        }
        fCgSourceFile.getClassList().add(fCgClass);

        if (fTargetLang == BlancoCgSupportedLang.JAVA) {
            // In the case of Java, uses resource bundle.
            final BlancoCgField field = new BlancoCgField();
            field.setName("fBundle");
            field.setType(fCgFactory.createType(argStructure.getPackage() + "."
                    + BlancoNameAdjuster.toClassName(argStructure.getName()) + argStructure.getSuffix()
                    + "ResourceBundle"));
            field.setDescription("A resource bundle class that is used internally to make messages correspond to property files.");
            field.setDefault("new " + BlancoNameAdjuster.toClassName(argStructure.getName()) + argStructure.getSuffix()
                    + "ResourceBundle()");
            field.setFinal(true);
            field.setAccess("protected");
            fCgClass.getFieldList().add(field);
        }

        if (fIsGenerateConstants) {
            expandFieldMessage(argStructure);
        }

        expandMethodGetMessage(argStructure);

        if (fIsJavaJsf) {
            expandMethodGetFacesMessage(argStructure);
        }
        if (fIsJavaStruts) {
            expandMethodGetStrutsMessage(argStructure);
            expandStrutsMessageBundle(argStructure, fileBlancoMain);
        }

        BlancoCgTransformerFactory.getSourceTransformer(fTargetLang).transform(fCgSourceFile, fileBlancoMain);
    }

    /**
     * Expands the constant field.
     * 
     * @param argProcessStructure
     *            Processing structure data that could be collected from metafiles.
     */
    @SuppressWarnings("unchecked")
    private void expandFieldMessage(final BlancoMessageStructure argProcessStructure) {

        for (int indexField = 0; indexField < argProcessStructure.getFieldList().size(); indexField++) {
            final BlancoMessageFieldStructure fieldLook = argProcessStructure.getFieldList().get(indexField);

            final String fieldName = fieldLook.getName().toUpperCase();

            // Supports the flag whether or not to implement the specification "Not to generate constant fields if the message has a replacement string".
            if ("true".equals(fBundle.getXml2sourceFileNoGenerateConstantIfFormatElementExist())) {
                final List listSplitMessage = new ArrayList();
                listSplitMessage.add(fieldLook.getMessage());
                final int maxReplaceNumber = new BlancoMessageSplitUtil().split(listSplitMessage);
                if (maxReplaceNumber >= 0) {
                    // No constant field will be generated because the replacement string exists.
                    continue;
                }
            }

            {
                // Constant-ized message.
                final BlancoCgField cgField = fCgFactory.createField(fieldName, getTypeString(), "String ["
                        + BlancoCgSourceUtil.escapeStringAsLangDoc(fTargetLang, fieldLook.getMessage()) + "]");
                fCgClass.getFieldList().add(cgField);
                cgField.setAccess("public");
                cgField.setStatic(true);
                cgField.setFinal(true);
                cgField.setDefault(BlancoCgLineUtil.getStringLiteralEnclosure(fTargetLang)
                        + BlancoCgSourceUtil.escapeStringAsSource(fTargetLang,
                                (argProcessStructure.getIdEmbedding() ? "[" + fieldLook.getName() + "] " : "")
                                        + fieldLook.getMessage())
                        + BlancoCgLineUtil.getStringLiteralEnclosure(fTargetLang));

                if (fieldLook.getNo() != null) {
                    cgField.getLangDoc().getDescriptionList().add(fBundle.getXml2sourceFileFieldNo(fieldLook.getNo()));
                }
            }

            {
                // Constant-ized message ID.
                final BlancoCgField cgField = fCgFactory.createField("KEY_" + fieldName, getTypeString(), "Key value: "
                        + BlancoCgSourceUtil.escapeStringAsLangDoc(fTargetLang, "KEY_" + fieldLook.getName()));
                fCgClass.getFieldList().add(cgField);
                cgField.setAccess("public");
                cgField.setStatic(true);
                cgField.setFinal(true);
                cgField.setDefault(BlancoCgLineUtil.getStringLiteralEnclosure(fTargetLang)
                        + BlancoCgSourceUtil.escapeStringAsSource(fTargetLang, fieldLook.getName())
                        + BlancoCgLineUtil.getStringLiteralEnclosure(fTargetLang));

                if (fieldLook.getNo() != null) {
                    cgField.getLangDoc().getDescriptionList().add(fBundle.getXml2sourceFileFieldNo(fieldLook.getNo()));
                }
            }
        }
    }

    /**
     * Expands a get message method.
     * 
     * @param argProcessStructure
     *            Processing structure data that could be collected from metafiles.
     */
    @SuppressWarnings("unchecked")
    private void expandMethodGetMessage(final BlancoMessageStructure argProcessStructure) {

        for (int indexField = 0; indexField < argProcessStructure.getFieldList().size(); indexField++) {
            final BlancoMessageFieldStructure fieldLook = (BlancoMessageFieldStructure) argProcessStructure
                    .getFieldList().get(indexField);

            final List listSplitMessage = new ArrayList();
            listSplitMessage.add((argProcessStructure.getIdEmbedding() ? "[" + fieldLook.getName() + "] " : "")
                    + fieldLook.getMessage());
            final int maxReplaceNumber = new BlancoMessageSplitUtil().split(listSplitMessage);

            final int blancoResourceBundleFormatCount = BlancoResourceBundleUtil.getFormatsByArgumentIndex(
                    fieldLook.getMessage(), false).length;

            if (maxReplaceNumber + 1 != blancoResourceBundleFormatCount) {
                throw new IllegalArgumentException(fMsg.getMbmsgi04(argProcessStructure.getName(), fieldLook.getName(),
                        Integer.toString(maxReplaceNumber + 1), Integer.toString(blancoResourceBundleFormatCount)));
            }

            switch (fTargetLang) {
            case BlancoCgSupportedLang.RUBY:
            case BlancoCgSupportedLang.PYTHON:
                new BlancoMessageSplitUtil().splitByNewLineChar(listSplitMessage);
                break;
            }
            final String methodName = "get" + BlancoNameAdjuster.toClassName(fieldLook.getName());

            final BlancoCgMethod cgMethod = fCgFactory.createMethod(getMethodName(methodName), "Gets the string of message definition ID ["
                    + argProcessStructure.getName() + "] and key [" + fieldLook.getName() + "].");
            fCgClass.getMethodList().add(cgMethod);

            // System.out.println("The number of replacement strings:" + maxReplaceNumber);
            for (int indexArg = 0; indexArg <= maxReplaceNumber; indexArg++) {
                cgMethod.getParameterList().add(
                        fCgFactory.createParameter("arg" + indexArg, getTypeString(), "Value of the replacement string {" + indexArg + "}.",
                                true));
            }

            if (fieldLook.getNo() != null) {
                cgMethod.getLangDoc().getDescriptionList().add(fBundle.getXml2sourceFileFieldNo(fieldLook.getNo()));
            }
            cgMethod.getLangDoc().getDescriptionList()
                    .add("String [" + BlancoCgSourceUtil.escapeStringAsLangDoc(fTargetLang, fieldLook.getMessage()) + "]");

            cgMethod.setReturn(fCgFactory.createReturn(getTypeString(), "Message string."));

            final List lineList = cgMethod.getLineList();

            StringBuffer bufLine = new StringBuffer();

            switch (fTargetLang) {
            case BlancoCgSupportedLang.JAVA:
                if (true) {
                    final StringBuffer buf = new StringBuffer();
                    if (argProcessStructure.getIdEmbedding()) {
                        // ID embedding
                        buf.append(BlancoCgLineUtil.getStringLiteralEnclosure(fTargetLang) + "[" + fieldLook.getName()
                                + "] " + BlancoCgLineUtil.getStringLiteralEnclosure(fTargetLang) + " + ");
                    }
                    buf.append("fBundle.get" + BlancoNameAdjuster.toClassName(fieldLook.getName()) + "(");
                    for (int indexArg = 0; indexArg <= maxReplaceNumber; indexArg++) {
                        if (indexArg != 0) {
                            buf.append(", ");
                        }
                        buf.append("arg" + indexArg);
                    }
                    buf.append(")");
                    bufLine.append(buf.toString());
                }
                break;
            case BlancoCgSupportedLang.RUBY:
            case BlancoCgSupportedLang.PYTHON:
                bufLine.append(getReturnStringRuby(listSplitMessage));
                break;
            default:
                bufLine.append(getReturnString(listSplitMessage));
                break;
            }

            switch (fTargetLang) {
            case BlancoCgSupportedLang.DELPHI:
                // There are no return statements in Delphi.
                lineList.add("result:= " + bufLine.toString() + BlancoCgLineUtil.getTerminator(fTargetLang));
                lineList.add("exit" + BlancoCgLineUtil.getTerminator(fTargetLang));
                break;
            default:
                lineList.add(BlancoCgLineUtil.getReturn(fTargetLang, bufLine.toString())
                        + BlancoCgLineUtil.getTerminator(fTargetLang));
                break;
            }
        }
    }

    /**
     * JSF message generation method for the Java only.
     * 
     * @param argProcessStructure
     */
    private void expandMethodGetFacesMessage(final BlancoMessageStructure argProcessStructure) {

        for (int indexField = 0; indexField < argProcessStructure.getFieldList().size(); indexField++) {
            final BlancoMessageFieldStructure fieldLook = (BlancoMessageFieldStructure) argProcessStructure
                    .getFieldList().get(indexField);

            if (fTargetLang != BlancoCgSupportedLang.JAVA) {
                // Unsupported except in Java.
                return;
            }

            final String methodName = "getFaces" + BlancoNameAdjuster.toClassName(fieldLook.getName());
            final BlancoCgMethod cgMethod = fCgFactory.createMethod(
                    getMethodName(methodName),
                    "Message: [" + fieldLook.getMessage() + "]");
            fCgClass.getMethodList().add(cgMethod);
            cgMethod.getLangDoc().getDescriptionList().add("<h3>Information</h3><ul>");
            cgMethod.getLangDoc()
                    .getDescriptionList()
                    .add("<li>Message definition ID: "
                            + BlancoCgSourceUtil.escapeStringAsLangDoc(fTargetLang, argProcessStructure.getName())
                            + "</li>");
            cgMethod.getLangDoc()
                    .getDescriptionList()
                    .add("<li>Key: " + BlancoCgSourceUtil.escapeStringAsLangDoc(fTargetLang, fieldLook.getName())
                            + "</li>");
            cgMethod.getLangDoc()
                    .getDescriptionList()
                    .add("<li>Level: " + BlancoCgSourceUtil.escapeStringAsLangDoc(fTargetLang, fieldLook.getLevel())
                            + "</li>");
            cgMethod.getLangDoc()
                    .getDescriptionList()
                    .add("<li>Message: " + BlancoCgSourceUtil.escapeStringAsLangDoc(fTargetLang, fieldLook.getMessage())
                            + "</li>");
            cgMethod.getLangDoc().getDescriptionList().add("</ul>");

            final List<String> listSplitMessage = new ArrayList<String>();
            listSplitMessage.add((argProcessStructure.getIdEmbedding() ? "[" + fieldLook.getName() + "] " : "")
                    + fieldLook.getMessage());
            final int maxReplaceNumber = new BlancoMessageSplitUtil().split(listSplitMessage);
            for (int indexArg = 0; indexArg <= maxReplaceNumber; indexArg++) {
                cgMethod.getParameterList().add(
                        fCgFactory.createParameter("arg" + indexArg, getTypeString(), "Value of the replacement string {" + indexArg + "}.",
                                true));
            }

            cgMethod.setReturn(fCgFactory.createReturn("javax.faces.application.FacesMessage", "JSF Faces message."));

            final StringBuffer callParam = new StringBuffer();
            for (int indexArg = 0; indexArg <= maxReplaceNumber; indexArg++) {
                if (indexArg != 0)
                    callParam.append(", ");
                callParam.append("arg" + indexArg);
            }

            String levelFaces = "INFO";
            if (fieldLook.getLevel() == null || fieldLook.getLevel().trim().length() == 0) {
                // We will do nothing.
                levelFaces = "INFO";
            } else if (fieldLook.getLevel().equals("FATAL")) {
                levelFaces = "FATAL";
            } else if (fieldLook.getLevel().equals("ERROR")) {
                levelFaces = "ERROR";
            } else if (fieldLook.getLevel().equals("WARN")) {
                levelFaces = "WARN";
            } else if (fieldLook.getLevel().equals("INFO")) {
                levelFaces = "INFO";
            } else {
                // We have no choice but to treat it as INFO.
                levelFaces = "INFO";
            }

            cgMethod.getLineList().add(
                    "return new FacesMessage(FacesMessage.SEVERITY_" + levelFaces + ", get"
                            + BlancoNameAdjuster.toClassName(fieldLook.getName()) + "(" + callParam + "), null);");
        }
    }

    /**
     * Apache Struts message generation method for the Java only.
     * 
     * Add <message-resources parameter="resources.foo"/> to struts-config.xml.
     * 
     * @param argProcessStructure
     */
    private void expandMethodGetStrutsMessage(final BlancoMessageStructure argProcessStructure) {

        for (int indexField = 0; indexField < argProcessStructure.getFieldList().size(); indexField++) {
            final BlancoMessageFieldStructure fieldLook = (BlancoMessageFieldStructure) argProcessStructure
                    .getFieldList().get(indexField);

            if (fTargetLang != BlancoCgSupportedLang.JAVA) {
                // Unsupported except in Java.
                return;
            }

            final String methodName = "addStruts" + BlancoNameAdjuster.toClassName(fieldLook.getName());
            final BlancoCgMethod cgMethod = fCgFactory.createMethod(
                    getMethodName(methodName),
                    "Message: [" + fieldLook.getMessage() + "]");
            fCgClass.getMethodList().add(cgMethod);
            cgMethod.getLangDoc().getDescriptionList().add("<h3>Information</h3><ul>");
            cgMethod.getLangDoc()
                    .getDescriptionList()
                    .add("<li>Message definition ID: "
                            + BlancoCgSourceUtil.escapeStringAsLangDoc(fTargetLang, argProcessStructure.getName())
                            + "</li>");
            cgMethod.getLangDoc()
                    .getDescriptionList()
                    .add("<li>Key: " + BlancoCgSourceUtil.escapeStringAsLangDoc(fTargetLang, fieldLook.getName())
                            + "</li>");
            cgMethod.getLangDoc()
                    .getDescriptionList()
                    .add("<li>Level: " + BlancoCgSourceUtil.escapeStringAsLangDoc(fTargetLang, fieldLook.getLevel())
                            + "</li>");
            cgMethod.getLangDoc()
                    .getDescriptionList()
                    .add("<li>Message: " + BlancoCgSourceUtil.escapeStringAsLangDoc(fTargetLang, fieldLook.getMessage())
                            + "</li>");
            cgMethod.getLangDoc().getDescriptionList().add("</ul>");

            cgMethod.getParameterList().add(
                    fCgFactory.createParameter("actionMessages", "org.apache.struts.action.ActionMessages",
                            "Apache Struts Messages"));

            final List<String> listSplitMessage = new ArrayList<String>();
            listSplitMessage.add((argProcessStructure.getIdEmbedding() ? "[" + fieldLook.getName() + "] " : "")
                    + fieldLook.getMessage());
            final int maxReplaceNumber = new BlancoMessageSplitUtil().split(listSplitMessage);
            for (int indexArg = 0; indexArg <= maxReplaceNumber; indexArg++) {
                cgMethod.getParameterList().add(
                        fCgFactory.createParameter("arg" + indexArg, getTypeString(), "Value of the replacement string {" + indexArg + "}.",
                                true));
            }

            fCgSourceFile.getImportList().add("org.apache.struts.action.ActionMessage");

            final int STRUTS_MAX_ARG = 2; // If it exceeds 3, we will convert to a String array (Struts defines up to 4).
            final StringBuffer callParam = new StringBuffer();
            if (maxReplaceNumber > STRUTS_MAX_ARG) {
                // Constructor argument limit support for Apache Struts Message.
                callParam.append(", new String[] {");
            } else if (maxReplaceNumber >= 0) {
                // Point: -1 if there are none.
                callParam.append(", ");
            }
            for (int indexArg = 0; indexArg <= maxReplaceNumber; indexArg++) {
                if (indexArg != 0)
                    callParam.append(", ");

                callParam.append("arg" + indexArg);
            }
            if (maxReplaceNumber > STRUTS_MAX_ARG) {
                callParam.append("}");
            }

            String levelCustomMessage = "INFO";
            if (fieldLook.getLevel() == null || fieldLook.getLevel().trim().length() == 0) {
                levelCustomMessage = "INFO";
            } else if (fieldLook.getLevel().equals("FATAL")) {
                levelCustomMessage = "FATAL";
            } else if (fieldLook.getLevel().equals("ERROR")) {
                levelCustomMessage = "ERROR";
            } else if (fieldLook.getLevel().equals("WARN")) {
                levelCustomMessage = "WARN";
            } else if (fieldLook.getLevel().equals("INFO")) {
                levelCustomMessage = "INFO";
            } else {
                // We have no choice but to treat it as INFO.
                levelCustomMessage = "INFO";
            }

            cgMethod.getLineList().add(
                    "actionMessages.add(\"" + levelCustomMessage + "\", new ActionMessage(\""
                            + argProcessStructure.getPackage() + "." + fieldLook.getName() + "\"" + callParam + "));");
        }
    }

    private void expandStrutsMessageBundle(final BlancoMessageStructure argProcessStructure, final File fileBlancoMain) {
        final BlancoResourceBundleBundleStructure bundleStructure = new BlancoResourceBundleBundleStructure();
        bundleStructure.setPackage(argProcessStructure.getPackage());
        bundleStructure.setName(argProcessStructure.getName());
        bundleStructure.setDescription(argProcessStructure.getDescription());

        for (int indexField = 0; indexField < argProcessStructure.getFieldList().size(); indexField++) {
            final BlancoMessageFieldStructure fieldLook = (BlancoMessageFieldStructure) argProcessStructure
                    .getFieldList().get(indexField);

            if (fTargetLang != BlancoCgSupportedLang.JAVA) {
                // Unsupported except in Java.
                return;
            }

            final BlancoResourceBundleBundleItemStructure item = new BlancoResourceBundleBundleItemStructure();
            bundleStructure.getItemList().add(item);
            item.setKey(bundleStructure.getPackage() + "." + fieldLook.getName());
            BlancoResourceBundleBundleResourceStringStructure res = new BlancoResourceBundleBundleResourceStringStructure();
            res.setResourceString(fieldLook.getMessage());
            item.getResourceStringList().add(res);
        }

        final BlancoResourceBundleXml2Properties xml2Properties = new BlancoResourceBundleXml2Properties();
        xml2Properties.setPropertieswithdirectory(false);
        xml2Properties.structure2Properties(bundleStructure, null, fileBlancoMain);
    }

    /**
     * Gets the name of the String type that matches the programming language processor.
     * 
     * Type reading.
     * 
     * @return
     */
    private final String getTypeString() {
        switch (fTargetLang) {
        case BlancoCgSupportedLang.JAVA:
        default:
            return "java.lang.String";
        case BlancoCgSupportedLang.CS:
            return "string";
        case BlancoCgSupportedLang.JS:
        case BlancoCgSupportedLang.PHP:
            return "string";
        case BlancoCgSupportedLang.VB:
        case BlancoCgSupportedLang.DELPHI:
            return "String";
        }
    }

    /**
     * Renames the methods to match the programming language processor.
     * 
     * Method name reading.
     * 
     * @return
     */
    private final String getMethodName(final String argMethodName) {
        switch (fTargetLang) {
        case BlancoCgSupportedLang.JAVA:
        default:
            return argMethodName;
        case BlancoCgSupportedLang.CS:
        case BlancoCgSupportedLang.VB:
            return BlancoNameAdjuster.toUpperCaseTitle(argMethodName);
        case BlancoCgSupportedLang.JS:
            return argMethodName;
        }
    }

    /**
     * 
     * Gets an expression to generate a message string.
     * 
     * @param listSplitMessage
     *            A list of messages divided by embedded strings.
     * @return
     */
    @SuppressWarnings("unchecked")
    private StringBuffer getReturnString(final List listSplitMessage) {
        StringBuffer bufLine = new StringBuffer();
        boolean isPastString = false;
        for (int index = 0; index < listSplitMessage.size(); index++) {
            final Object objLook = listSplitMessage.get(index);
            if (objLook instanceof Integer) {
                // Replacement string.
                final Integer intLook = (Integer) objLook;
                if (isPastString) {
                    bufLine.append(BlancoCgLineUtil.getStringLiteralEnclosure(fTargetLang));
                }
                isPastString = false;
                if (index != 0) {
                    bufLine.append(" " + BlancoCgLineUtil.getStringConcatenationOperator(fTargetLang) + " ");
                }
                if (fTargetLang == BlancoCgSupportedLang.PHP) {
                    bufLine.append("$");
                }
                bufLine.append("arg" + intLook.intValue());
            } else {
                if (isPastString == false) {
                    if (index != 0) {
                        bufLine.append(" " + BlancoCgLineUtil.getStringConcatenationOperator(fTargetLang) + " ");
                    }
                    bufLine.append(BlancoCgLineUtil.getStringLiteralEnclosure(fTargetLang));
                }
                isPastString = true;

                final String strLook = (String) objLook;
                bufLine.append(BlancoCgSourceUtil.escapeStringAsSource(fTargetLang, strLook));
            }
        }

        if (isPastString) {
            bufLine.append(BlancoCgLineUtil.getStringLiteralEnclosure(fTargetLang));
        }

        return bufLine;
    }

    /**
     * 
     * Gets an expression to generate a message string in a Ruby-like language.
     * 
     * Use this when you want to treat newline characters as individual string literals.
     * 
     * @param listSplitMessage
     *            A list of messages divided by embedded strings.
     * @return
     */
    @SuppressWarnings("unchecked")
    private StringBuffer getReturnStringRuby(final List listSplitMessage) {
        StringBuffer bufLine = new StringBuffer();
        for (int index = 0; index < listSplitMessage.size(); index++) {
            final Object objLook = listSplitMessage.get(index);
            if (index != 0) {
                bufLine.append(" " + BlancoCgLineUtil.getStringConcatenationOperator(fTargetLang) + " ");
            }
            if (objLook instanceof Integer) {
                // For replacement characters.
                final Integer intLook = (Integer) objLook;

                if (fTargetLang == BlancoCgSupportedLang.PHP) {
                    bufLine.append("$");
                }
                bufLine.append("arg" + intLook.intValue());
            } else {
                // For string literals.
                final String strLook = (String) objLook;

                // If there are only newline characters, encloses the string literal in \".
                StringBuffer literalEnclosure = new StringBuffer();
                if ("\n".equals(strLook)) {
                    literalEnclosure.append("\"");
                } else {
                    literalEnclosure.append(BlancoCgLineUtil.getStringLiteralEnclosure(fTargetLang));
                }

                bufLine.append(literalEnclosure);
                bufLine.append(BlancoCgSourceUtil.escapeStringAsSource(fTargetLang, strLook));
                bufLine.append(literalEnclosure);
            }
        }

        return bufLine;
    }

    /**
     * Generates a resource bundle class in the case of Java.
     * 
     * @param argStructure
     * @param argDirectoryTarget
     */
    private void expandResourceBundleForJava(final BlancoMessageStructure argStructure, final File argDirectoryTarget) {
        final BlancoResourceBundleBundleStructure bundleStructure = new BlancoResourceBundleBundleStructure();
        bundleStructure.setName(BlancoNameAdjuster.toClassName(argStructure.getName()) + argStructure.getSuffix());
        bundleStructure.setPackage(argStructure.getPackage());
        // Restricts the class to package access.
        bundleStructure.setAccess("");
        bundleStructure.setSuffix("ResourceBundle");
        bundleStructure.setDescription("A resource bundle class used internally by the message definition [" + argStructure.getName() + "].");

        // TODO: We use the default locale.
        final Locale defalutLocale = Locale.getDefault();

        for (int index = 0; index < argStructure.getFieldList().size(); index++) {
            final BlancoMessageFieldStructure fieldStructure = (BlancoMessageFieldStructure) argStructure
                    .getFieldList().get(index);
            final BlancoResourceBundleBundleItemStructure item = new BlancoResourceBundleBundleItemStructure();
            item.setKey(fieldStructure.getName());
            final BlancoResourceBundleBundleResourceStringStructure resourceString = new BlancoResourceBundleBundleResourceStringStructure();
            resourceString.setResourceString(BlancoStringUtil.null2Blank(fieldStructure.getMessage()));
            resourceString.setLocale(defalutLocale.getLanguage());
            item.getResourceStringList().add(resourceString);
            bundleStructure.getItemList().add(item);
        }

        final BlancoResourceBundleXml2JavaClass xml2java = new BlancoResourceBundleXml2JavaClass();
        xml2java.setEncoding(fEncoding);
        xml2java.structure2Source(bundleStructure, argDirectoryTarget);
    }
}
