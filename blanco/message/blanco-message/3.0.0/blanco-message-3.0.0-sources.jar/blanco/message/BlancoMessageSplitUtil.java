/*
 * blanco Framework
 * Copyright (C) 2004-2006 IGA Tosiki
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 */
package blanco.message;

import java.util.List;

/**
 * A utility for splitting blancoMessage messages.
 * 
 * @author ToshikiIga
 */
class BlancoMessageSplitUtil {
    /**
     * Splits the message based on the replacement string.
     * 
     * @param listSourceString
     *            Input string. The content changes during the processing. After processing, it will be split.
     * @return How many replacement strings existed. If none were found, -1 is returned.
     */
    @SuppressWarnings("unchecked")
    public int split(final List listSourceString) {
        for (int number = 0;; number++) {
            final boolean isFound = splitByReplaceString(listSourceString,
                    number);
            if (isFound == false) {
                // Returns the current process number -1.
                // If none of the replacement strings are found, returns -1.
                return number - 1;
            }
        }
    }

    /**
     * Splits a string based on the replacement string by the specified number.
     * 
     * Splits the input string of the argument listSourceString at the position where the replacement string with the specified number {0}, {1} is found, and returns it to listSourceString.
     * The replacement string is stored in listSourceString as a numeric value of type Integer.
     * 
     * For example, if the input listSourceString.index(0) contains the string "置換文字列が{0}が存在します", it will be split as follows.<br>
     * listSourceString.index(0) = "置換文字列が"<br>
     * listSourceString.index(1) = new Integer(0)<br>
     * listSourceString.index(2) = "が存在します"<br>
     * 
     * @param listSourceString
     *            Input string.
     * @param replaceNumber
     *            The number of the replacement string, specified in 0-origin.
     * @return A flag indicating whether or not a replacement has occurred. Returns true if a replacement has occurred, false if not.
     */
    @SuppressWarnings("unchecked")
    private boolean splitByReplaceString(final List listSourceString,
            final int replaceNumber) {
        boolean isFound = false;
        for (int index = 0; index < listSourceString.size(); index++) {
            final Object objLook = listSourceString.get(index);
            if (objLook instanceof Integer) {
                continue;
            }

            final String input = (String) listSourceString.get(index);

            // String to be used for replacement.
            final String replaceNumberString = "{" + replaceNumber + "}";

            final int search = input.indexOf(replaceNumberString);
            if (search >= 0) {
                listSourceString.remove(index);
                listSourceString.add(index, input.substring(0, search));
                listSourceString.add(index + 1, new Integer(replaceNumber));
                listSourceString.add(index + 2, input.substring(search
                        + replaceNumberString.length()));
                isFound = true;
            }
        }

        // Removes unwanted zero-length strings from the list.
        removeUnnecessaryString(listSourceString);

        return isFound;
    }

    /**
     * Splits a string based on line breaks.
     * 
     * Splits the input string of the argument listSourceString at the position where a newline (\n) is found, and returns it to listSourceString.
     * 
     * For example, if the input listSourceString.index(0) contains the string "改行が\n存在します", it will be split as follows.<br>
     * listSourceString.index(0) = "改行が"<br>
     * listSourceString.index(1) = "\n"<br>
     * listSourceString.index(2) = "存在します"<br>
     * 
     * @param listSourceString
     *            Input string.
     */
    @SuppressWarnings("unchecked")
    public void splitByNewLineChar(final List listSourceString) {
        for (int index = 0; index < listSourceString.size(); index++) {
            final Object objLook = listSourceString.get(index);
            if (objLook instanceof Integer) {
                continue;
            }

            final String input = (String) listSourceString.get(index);

            // String to be used for replacement.
            final String newLine = "\n";

            if (newLine.equals(input)) {
                continue;
            }

            final int search = input.indexOf(newLine);
            if (search >= 0) {
                listSourceString.remove(index);
                listSourceString.add(index, input.substring(0, search));
                listSourceString.add(index + 1, newLine);
                listSourceString.add(index + 2, input.substring(search
                        + newLine.length()));
            }
        }

        // Removes unwanted zero-length strings from the list.
        removeUnnecessaryString(listSourceString);
    }

    /**
     * Removes unwanted zero-length strings from the list.
     * 
     * @param listSourceString
     */
    @SuppressWarnings("unchecked")
    private void removeUnnecessaryString(final List listSourceString) {
        for (int index = listSourceString.size() - 1; index >= 0; index--) {
            final Object objLook = listSourceString.get(index);
            if (objLook instanceof Integer) {
                continue;
            }

            final String input = (String) listSourceString.get(index);
            if (input.length() == 0) {
                listSourceString.remove(index);
            }
        }
    }
}
