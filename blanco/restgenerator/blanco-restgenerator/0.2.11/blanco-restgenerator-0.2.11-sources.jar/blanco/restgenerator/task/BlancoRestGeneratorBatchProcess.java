package blanco.restgenerator.task;

import java.io.IOException;

import blanco.restgenerator.task.valueobject.BlancoRestGeneratorProcessInput;

/**
 * Batch process class [BlancoRestGeneratorBatchProcess].
 *
 * <P>Example of a batch processing call.</P>
 * <code>
 * java -classpath (classpath) blanco.restgenerator.task.BlancoRestGeneratorBatchProcess -help
 * </code>
 */
public class BlancoRestGeneratorBatchProcess {
    /**
     * Normal end.
     */
    public static final int END_SUCCESS = 0;

    /**
     * Termination due to abnormal input. In the case that java.lang.IllegalArgumentException is raised internally.
     */
    public static final int END_ILLEGAL_ARGUMENT_EXCEPTION = 7;

    /**
     * Termination due to I/O exception. In the case that java.io.IOException is raised internally.
     */
    public static final int END_IO_EXCEPTION = 8;

    /**
     * Abnormal end. In the case that batch process fails to start or java.lang.Error or java.lang.RuntimeException is raised internally.
     */
    public static final int END_ERROR = 9;

    /**
     * The entry point when executed from the command line.
     *
     * @param args Agruments inherited from the console.
     */
    public static final void main(final String[] args) {
        final BlancoRestGeneratorBatchProcess batchProcess = new BlancoRestGeneratorBatchProcess();

        // Arguments for batch process.
        final BlancoRestGeneratorProcessInput input = new BlancoRestGeneratorProcessInput();

        boolean isNeedUsage = false;
        boolean isFieldMetadirProcessed = false;

        // Parses command line arguments.
        for (int index = 0; index < args.length; index++) {
            String arg = args[index];
            if (arg.startsWith("-verbose=")) {
                input.setVerbose(Boolean.valueOf(arg.substring(9)).booleanValue());
            } else if (arg.startsWith("-metadir=")) {
                input.setMetadir(arg.substring(9));
                isFieldMetadirProcessed = true;
            } else if (arg.startsWith("-targetdir=")) {
                input.setTargetdir(arg.substring(11));
            } else if (arg.startsWith("-tmpdir=")) {
                input.setTmpdir(arg.substring(8));
            } else if (arg.startsWith("-searchTmpdir=")) {
                input.setSearchTmpdir(arg.substring(14));
            } else if (arg.startsWith("-nameAdjust=")) {
                input.setNameAdjust(Boolean.valueOf(arg.substring(12)).booleanValue());
            } else if (arg.startsWith("-encoding=")) {
                input.setEncoding(arg.substring(10));
            } else if (arg.startsWith("-xmlrootelement=")) {
                input.setXmlrootelement(Boolean.valueOf(arg.substring(16)).booleanValue());
            } else if (arg.startsWith("-sheetType=")) {
                input.setSheetType(arg.substring(11));
            } else if (arg.startsWith("-targetStyle=")) {
                input.setTargetStyle(arg.substring(13));
            } else if (arg.startsWith("-client=")) {
                input.setClient(Boolean.valueOf(arg.substring(8)).booleanValue());
            } else if (arg.startsWith("-serverType=")) {
                input.setServerType(arg.substring(12));
            } else if (arg.startsWith("-telegrampackage=")) {
                input.setTelegrampackage(arg.substring(17));
            } else if (arg.startsWith("-processBaseClass=")) {
                input.setProcessBaseClass(arg.substring(18));
            } else if (arg.startsWith("-defaultExceptionClass=")) {
                input.setDefaultExceptionClass(arg.substring(23));
            } else if (arg.startsWith("-lineSeparator=")) {
                input.setLineSeparator(arg.substring(15));
            } else if (arg.startsWith("-packageSuffix=")) {
                input.setPackageSuffix(arg.substring(15));
            } else if (arg.startsWith("-overridePackage=")) {
                input.setOverridePackage(arg.substring(17));
            } else if (arg.startsWith("-overrideLocation=")) {
                input.setOverrideLocation(arg.substring(18));
            } else if (arg.startsWith("-voPackageSuffix=")) {
                input.setVoPackageSuffix(arg.substring(17));
            } else if (arg.startsWith("-voOverridePackage=")) {
                input.setVoOverridePackage(arg.substring(19));
            } else if (arg.startsWith("-ignoreDefault=")) {
                input.setIgnoreDefault(Boolean.valueOf(arg.substring(15)).booleanValue());
            } else if (arg.startsWith("-ignoreAnnotation=")) {
                input.setIgnoreAnnotation(Boolean.valueOf(arg.substring(18)).booleanValue());
            } else if (arg.startsWith("-ignoreImport=")) {
                input.setIgnoreImport(Boolean.valueOf(arg.substring(14)).booleanValue());
            } else if (arg.startsWith("-telegramsOnly=")) {
                input.setTelegramsOnly(Boolean.valueOf(arg.substring(15)).booleanValue());
            } else if (arg.equals("-?") || arg.equals("-help")) {
                usage();
                System.exit(END_SUCCESS);
            } else {
                System.out.println("BlancoRestGeneratorBatchProcess: The input parameter[" + arg + "] was ignored.");
                isNeedUsage = true;
            }
        }

        if (isNeedUsage) {
            usage();
        }

        if( isFieldMetadirProcessed == false) {
            System.out.println("BlancoRestGeneratorBatchProcess: Failed to start the process. The required field value[metadir] in the input parameter[input] is not set to a value.");
            System.exit(END_ILLEGAL_ARGUMENT_EXCEPTION);
        }

        int retCode = batchProcess.execute(input);

        // Returns the exit code.
        // Note: Please note that calling System.exit().
        System.exit(retCode);
    }

    /**
     * A method to describe the specific batch processing contents.
     *
     * This method is used to describe the actual process.
     *
     * @param input Input parameters for batch process.
     * @return The exit code for batch process. Returns one of the values END_SUCCESS, END_ILLEGAL_ARGUMENT_EXCEPTION, END_IO_EXCEPTION, END_ERROR
     * @throws IOException If an I/O exception occurs.
     * @throws IllegalArgumentException If an invalid input value is found.
     */
    public int process(final BlancoRestGeneratorProcessInput input) throws IOException, IllegalArgumentException {
        // Checks the input parameters.
        validateInput(input);

        // If you get a compile error at this point, You may be able to solve it by implementing a BlancoRestGeneratorProcess interface and creating an BlancoRestGeneratorProcessImpl class in package blanco.restgenerator.task.
        final BlancoRestGeneratorProcess process = new BlancoRestGeneratorProcessImpl();

        // Executes the main body of the process.
        final int retCode = process.execute(input);

        return retCode;
    }

    /**
     * The entry point for instantiating a class and running a batch.
     *
     * This method provides the following specifications.
     * <ul>
     * <li>Checks the contents of the input parameters of the method.
     * <li>Catches exceptions such as IllegalArgumentException, RuntimeException, Error, etc. and converts them to return values.
     * </ul>
     *
     * @param input Input parameters for batch process.
     * @return The exit code for batch process. Returns one of the values END_SUCCESS, END_ILLEGAL_ARGUMENT_EXCEPTION, END_IO_EXCEPTION, END_ERROR
     * @throws IllegalArgumentException If an invalid input value is found.
     */
    public final int execute(final BlancoRestGeneratorProcessInput input) throws IllegalArgumentException {
        try {
            // Executes the main body of the batch process.
            int retCode = process(input);

            return retCode;
        } catch (IllegalArgumentException ex) {
            System.out.println("BlancoRestGeneratorBatchProcess: An input exception has occurred. Abort the batch process.:" + ex.toString());
            // Termination due to abnormal input.
            return END_ILLEGAL_ARGUMENT_EXCEPTION;
        } catch (IOException ex) {
            System.out.println("BlancoRestGeneratorBatchProcess: An I/O exception has occurred. Abort the batch process.:" + ex.toString());
            // Termination due to abnormal input.
            return END_IO_EXCEPTION;
        } catch (RuntimeException ex) {
            System.out.println("BlancoRestGeneratorBatchProcess: A runtime exception has occurred. Abort the batch process.:" + ex.toString());
            ex.printStackTrace();
            // Abnormal end.
            return END_ERROR;
        } catch (Error er) {
            System.out.println("BlancoRestGeneratorBatchProcess: A runtime exception has occurred. Abort the batch process.:" + er.toString());
            er.printStackTrace();
            // Abnormal end.
            return END_ERROR;
        }
    }

    /**
     * A method to show an explanation of how to use this batch processing class on the stdout.
     */
    public static final void usage() {
        System.out.println("BlancoRestGeneratorBatchProcess: Usage:");
        System.out.println("  java blanco.restgenerator.task.BlancoRestGeneratorBatchProcess -verbose=value1 -metadir=value2 -targetdir=value3 -tmpdir=value4 -searchTmpdir=value5 -nameAdjust=value6 -encoding=value7 -xmlrootelement=value8 -sheetType=value9 -targetStyle=value10 -client=value11 -serverType=value12 -telegrampackage=value13 -processBaseClass=value14 -defaultExceptionClass=value15 -lineSeparator=value16 -packageSuffix=value17 -overridePackage=value18 -overrideLocation=value19 -voPackageSuffix=value20 -voOverridePackage=value21 -ignoreDefault=value22 -ignoreAnnotation=value23 -ignoreImport=value24 -telegramsOnly=value25");
        System.out.println("    -verbose");
        System.out.println("      explanation[Whether to run in verbose mode.]");
        System.out.println("      type[boolean]");
        System.out.println("      default value[false]");
        System.out.println("    -metadir");
        System.out.println("      explanation[メタディレクトリ。xlsファイルの格納先または xmlファイルの格納先を指定します。]");
        System.out.println("      type[string]");
        System.out.println("      a required parameter");
        System.out.println("    -targetdir");
        System.out.println("      explanation[出力先フォルダを指定します。無指定の場合にはカレント直下のblancoを用います。]");
        System.out.println("      type[string]");
        System.out.println("      default value[blanco]");
        System.out.println("    -tmpdir");
        System.out.println("      explanation[テンポラリディレクトリを指定します。無指定の場合にはカレント直下のtmpを用います。]");
        System.out.println("      type[string]");
        System.out.println("      default value[tmp]");
        System.out.println("    -searchTmpdir");
        System.out.println("      explanation[import文作成のために検索するtmpディレクトリをカンマ区切りで指定します。指定ディレクトリ直下のvalueobjectディレクトリの下にxmlを探しにいきます。]");
        System.out.println("      type[string]");
        System.out.println("    -nameAdjust");
        System.out.println("      explanation[フィールド名やメソッド名を名前変形を実施するかどうか。]");
        System.out.println("      type[boolean]");
        System.out.println("      default value[true]");
        System.out.println("    -encoding");
        System.out.println("      explanation[自動生成するソースファイルの文字エンコーディングを指定します。]");
        System.out.println("      type[string]");
        System.out.println("    -xmlrootelement");
        System.out.println("      explanation[XML ルート要素のアノテーションを出力するかどうか。JDK 1.6 以降が必要。]");
        System.out.println("      type[boolean]");
        System.out.println("      default value[false]");
        System.out.println("    -sheetType");
        System.out.println("      explanation[meta定義書が期待しているプログラミング言語を指定します]");
        System.out.println("      type[string]");
        System.out.println("      default value[java]");
        System.out.println("    -targetStyle");
        System.out.println("      explanation[出力先フォルダの書式を指定します。<br>\nblanco: [targetdir]/main<br>\nmaven: [targetdir]/main/java<br>\nfree: [targetdir](targetdirが無指定の場合はblanco/main)]");
        System.out.println("      type[string]");
        System.out.println("      default value[blanco]");
        System.out.println("    -client");
        System.out.println("      explanation[trueの場合はサーバ用のメソッドを生成しません。]");
        System.out.println("      type[boolean]");
        System.out.println("      default value[false]");
        System.out.println("    -serverType");
        System.out.println("      explanation[Webアプリケーションサーバのタイプを指定します。現在の所、tomcatのみが使用可能です。]");
        System.out.println("      type[string]");
        System.out.println("      default value[tomcat]");
        System.out.println("    -telegrampackage");
        System.out.println("      explanation[電文の基底クラスが配備されているパッケージを指定します。指定がない場合はvalueobjectから探します。]");
        System.out.println("      type[string]");
        System.out.println("    -processBaseClass");
        System.out.println("      explanation[電文処理の基底クラスを指定します。指定がない場合はblanco.restgenerator.common.ApiBaseとなります。]");
        System.out.println("      type[string]");
        System.out.println("    -defaultExceptionClass");
        System.out.println("      explanation[デフォルトの例外クラスを指定します。指定がない場合はblanco.restgenerator.exception.BlancoRestExceptionとなります。]");
        System.out.println("      type[string]");
        System.out.println("    -lineSeparator");
        System.out.println("      explanation[行末記号をしていします。LF=0x0a, CR=0x0d, CFLF=0x0d0x0a とします。LFがデフォルトです。]");
        System.out.println("      type[string]");
        System.out.println("      default value[LF]");
        System.out.println("    -packageSuffix");
        System.out.println("      explanation[定義書で指定されたパッケージ名の後ろに追加するパッケージ文字列を指定します。]");
        System.out.println("      type[string]");
        System.out.println("    -overridePackage");
        System.out.println("      explanation[定義書で指定されたパッケージ名を上書きします。]");
        System.out.println("      type[string]");
        System.out.println("    -overrideLocation");
        System.out.println("      explanation[定義書で指定されたロケーション名を上書きします。]");
        System.out.println("      type[string]");
        System.out.println("    -voPackageSuffix");
        System.out.println("      explanation[packageを探しにいくValueObject定義書を処理する際に指定されていたはずの packageSuffix を指定します。]");
        System.out.println("      type[string]");
        System.out.println("    -voOverridePackage");
        System.out.println("      explanation[packageを探しにいくValueObject定義書を処理する際に指定されていたはずの overridePackage を指定します。]");
        System.out.println("      type[string]");
        System.out.println("    -ignoreDefault");
        System.out.println("      explanation[Java向け以外のデフォルト値を無視します。]");
        System.out.println("      type[boolean]");
        System.out.println("      default value[false]");
        System.out.println("    -ignoreAnnotation");
        System.out.println("      explanation[Java向け以外のアノテーションを無視します。]");
        System.out.println("      type[boolean]");
        System.out.println("      default value[false]");
        System.out.println("    -ignoreImport");
        System.out.println("      explanation[Java向け以外のインポートを無視します。]");
        System.out.println("      type[boolean]");
        System.out.println("      default value[false]");
        System.out.println("    -telegramsOnly");
        System.out.println("      explanation[電文のみを生成し、電文処理は生成しません。]");
        System.out.println("      type[boolean]");
        System.out.println("      default value[false]");
        System.out.println("    -? , -help");
        System.out.println("      explanation[show the usage.]");
    }

    /**
     * A method to check the validity of input parameters for this batch processing class.
     *
     * @param input Input parameters for batch process.
     * @throws IllegalArgumentException If an invalid input value is found.
     */
    public void validateInput(final BlancoRestGeneratorProcessInput input) throws IllegalArgumentException {
        if (input == null) {
            throw new IllegalArgumentException("BlancoBatchProcessBatchProcess: Failed to start the process. The input parameter[input] was given as null.");
        }
        if (input.getMetadir() == null) {
            throw new IllegalArgumentException("BlancoRestGeneratorBatchProcess: Failed to start the process. The required field value[metadir] in the input parameter[input] is not set to a value.");
        }
    }
}
