/*
 * blanco Framework
 * Copyright (C) 2004-2009 IGA Tosiki
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 */
/*******************************************************************************
 * Copyright (c) 2009 IGA Tosiki, NTT DATA BUSINESS BRAINS Corp.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    IGA Tosiki (NTT DATA BUSINESS BRAINS Corp.) - initial API and implementation
 *******************************************************************************/
package blanco.commons.calc.parser.block;

/**
 * Represents a property key.
 * 
 * @author IGA Tosiki
 */
public class BlancoCalcParserPropertyKey {

    private String keyName = "name";

    private String[] startString = null;

    /**
     * Reads only one column by default.
     */
    private int waitForValueX = 1;

    /**
     * A constructor for the property key object.
     * 
     * @param name
     *            The name of the property key.
     */
    public BlancoCalcParserPropertyKey(final String name) {
        this.keyName = name;
    }

    /**
     * A constructor for the property key object.
     * 
     * @param name
     *            Name of the property key.
     * @param startString
     *            An array of start strings.
     */
    public BlancoCalcParserPropertyKey(final String name,
            final String[] startString) {
        this.keyName = name;
        this.startString = startString;
    }

    /**
     * Gets the name of the key.
     * 
     * @return The name of the key.
     */
    public String getName() {
        return keyName;
    }

    /**
     * Sets the name of the key.
     * 
     * @param arg
     *            The name of the key.
     */
    public void setName(String arg) {
        keyName = arg;
    }

    /**
     * Sets the start strings.
     * 
     * @param arg
     *            An array of start strings.
     */
    public void setKeyString(String[] arg) {
        startString = arg;
    }

    /**
     * Checks if the string matches the start strings.
     * 
     * @param arg
     *            A string to be checked.
     * @return Whether or not the string matches the start string.
     */
    public boolean isStartString(String arg) {
        final int startStringLength = startString.length;
        for (int index = 0; index < startStringLength; index++) {
            if (startString[index].equals(arg)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Sets the search range in the X direction.
     * 
     * @param arg
     *            The search range in the X direction.
     */
    public void setSearchRangeX(int arg) {
        waitForValueX = arg;
    }

    /**
     * Gets the search range in the X direction.
     * 
     * @return The search range in the X direction.
     */
    public int getSearchRangeX() {
        return waitForValueX;
    }
}
