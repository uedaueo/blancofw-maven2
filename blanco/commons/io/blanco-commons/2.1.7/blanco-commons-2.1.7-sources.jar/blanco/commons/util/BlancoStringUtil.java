/*
 * blanco Framework
 * Copyright (C) 2004-2009 IGA Tosiki
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 */
/*******************************************************************************
 * Copyright (c) 2009 IGA Tosiki, NTT DATA BUSINESS BRAINS Corp.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    IGA Tosiki (NTT DATA BUSINESS BRAINS Corp.) - initial API and implementation
 *******************************************************************************/
package blanco.commons.util;

/**
 * Contains utilities for strings in the blanco Framework.
 * 
 * In principle, most methods are provided as static methods.
 * 
 * @author IGA Tosiki
 */
public class BlancoStringUtil {
    /**
     * Gets the hexadecimal notation of the given byte array. Returns in lower case.
     * 
     * @param arg
     *            Byte array to be used as input.
     * @return A string in hexadecimal notation.
     */
    public static final String toHexString(final byte[] arg) {
        final StringBuffer buf = new StringBuffer();
        for (int index = 0; index < arg.length; index++) {
            buf.append(toHexString(arg[index]));
        }
        return buf.toString();
    }

    /**
     * Gets the hexadecimal notation of the given byte. Returns in lower case.
     * 
     * @param arg
     *            Byte.
     * @return A string in hexadecimal notation.
     */
    public static final String toHexString(final byte arg) {
        // Gets the hexadecimal notation after making it a positive value.
        String strResult = Integer.toHexString(arg & 0xff);
        for (; strResult.length() < 2;) {
            strResult = "0" + strResult;
        }
        return strResult;
    }

    /**
     * Converts the given char character to hexadecimal notation. Returns in lower case.
     * 
     * @param arg
     *            A character.
     * @return A string in hexadecimal notation.
     */
    public static final String toHexString(final char arg) {
        String strResult = Integer.toHexString(arg);
        for (; strResult.length() < 4;) {
            strResult = "0" + strResult;
        }
        return strResult;
    }

    /**
     * Performs string substitution independent of regular expressions.
     * 
     * This method does not involve regular expressions, unlike java.lang.String.<br>
     * This is used for string substitution where you do not want regular expressions to work.
     * 
     * @param source
     *            The string before conversion.
     * @param replaceFrom
     *            Replacement source character.
     * @param replaceTo
     *            Replacement destination character.
     * @return The string after conversion.
     */
    public static final String replaceAll(final String source,
            final char replaceFrom, final char replaceTo) {
        return BlancoStringUtilReplace.replaceAll(source, replaceFrom,
                replaceTo);
    }

    /**
     * Performs string substitution independent of regular expressions.
     * 
     * This method does not involve regular expressions, unlike java.lang.String.<br>
     * This is used for string substitution where you do not want regular expressions to work.
     * 
     * @param source
     *            The string before conversion.
     * @param replaceFrom
     *            Replacement source character.
     * @param replaceTo
     *            Replacement destination character.
     * @return The string after conversion.
     */
    public static final String replaceAll(final String source,
            final String replaceFrom, final String replaceTo) {
        return BlancoStringUtilReplace.replace(source, replaceFrom, replaceTo,
                true);
    }

    /**
     * Performs string substitution independent of regular expressions.
     * 
     * This method does not involve regular expressions, unlike java.lang.String.<br>
     * This is used for string substitution where you do not want regular expressions to work.
     * 
     * @param source
     *            The string before conversion.
     * @param replaceFrom
     *            Replacement source character.
     * @param replaceTo
     *            Replacement destination character.
     * @param isReplaceAll
     *            Whether to replace all.
     * @return The string after conversion.
     */
    public static final String replace(final String source,
            final String replaceFrom, final String replaceTo,
            final boolean isReplaceAll) {
        return BlancoStringUtilReplace.replace(source, replaceFrom, replaceTo,
                isReplaceAll);
    }

    /**
     * If the given string is null, converts it to a zero-length string. Otherwise, the string is returned as is.
     * 
     * Use this method when you want to replace null with a string of zero length.<br>
     * This method is supposed to be used when null is possible in the string processing process, but you want to consider it as a zero-length string.
     * 
     * @param originalString
     *            Input string. If null is given here, it will be converted to a zero-length string.
     * @return The string to be converted. Always returns something other than null.
     */
    public static final String null2Blank(final String originalString) {
        if (originalString == null) {
            // If null, it will be replaced by a string of length 0.
            return "";
        }
        // Otherwise, the original string will be returned as is.
        return originalString;
    }

    /**
     * Gets the length of a string, or assumes zero if null.
     * 
     * It is intended to be used when you want to get the length of a string that can contain null.
     * 
     * @deprecated It is recommended to call null2Blank and length() directly to ensure obviousness.
     * @param sourceString
     *            The string you want to get the length.
     * @return The length of the string, which will return 0 if null is given.
     */
    public static final int getLengthNullable(final String sourceString) {
        // If null is given, the length is determined to be zero.
        return null2Blank(sourceString).length();
    }

    /**
     * For the given string, if there are spaces on the left side, removes them.
     * 
     * Removes only single-byte spaces. Full-width whitespace is not processed.
     * 
     * @param originalString
     *            The string to be processed.
     * @return The string after half-width spaces have been trimmed.
     */
    public static final String trimLeft(final String originalString) {
        return BlancoStringUtilTrim.trimLeft(originalString);
    }

    /**
     * For the given string, if there are spaces on the right side, removes them.
     * 
     * Removes only single-byte spaces. Full-width whitespace is not processed.
     * 
     * @param originalString
     *            The string to be processed.
     * @return The string after half-width spaces have been trimmed.
     */
    public static final String trimRight(final String originalString) {
        return BlancoStringUtilTrim.trimRight(originalString);
    }

    /**
     * For the given string, if there are spaces on the right side or left side, removes them.
     * 
     * Removes only single-byte spaces. Full-width whitespace is not processed.
     * 
     * @param originalString
     *            The string to be processed.
     * @return The string after half-width spaces have been trimmed.
     */
    public static final String trim(final String originalString) {
        return BlancoStringUtilTrim.trim(originalString);
    }

    /**
     * Adds characters to the right side of the string until the specified length is reached.
     * 
     * @param argSource
     *            Original string.
     * @param argLength
     *            Desired length.
     * @param argPadChar
     *            Characters to be used for stuffing.
     * @return The string after processing to the specified length. If the original string is longer than the specified length, the original string will be returned as is.
     */
    public static final String padRight(final String argSource,
            final int argLength, final char argPadChar) {
        return BlancoStringUtilPad.padRight(argSource, argLength, argPadChar);
    }

    /**
     * Adds characters to the left side of the string until the specified length is reached.
     * 
     * @param argSource
     *            Original string.
     * @param argLength
     *            Desired length.
     * @param argPadChar
     *            Characters to be used for stuffing.
     * @return The string after processing to the specified length. If the original string is longer than the specified length, the original string will be returned as is.
     */
    public static final String padLeft(final String argSource,
            final int argLength, final char argPadChar) {
        return BlancoStringUtilPad.padLeft(argSource, argLength, argPadChar);
    }

    /**
     * Adds characters to the right side of the string until it reaches the specified length in Windows 31J.
     * 
     * @param argSource
     *            Original string.
     * @param argLength
     *            Desired length.
     * @param argPadChar
     *            Characters to be used for stuffing.
     * @return The string after processing to the specified length. If the original string is longer than the specified length, the original string will be returned as is.
     */
    public static final String padRightWindows31J(final String argSource,
            final int argLength, final char argPadChar) {
        return BlancoStringUtilPad.padRightWindows31J(argSource, argLength,
                argPadChar);
    }

    /**
     * Adds characters to the left side of the string until it reaches the specified length in Windows 31J.
     * 
     * @param argSource
     *            Original string.
     * @param argLength
     *            Desired length.
     * @param argPadChar
     *            Characters to be used for stuffing.
     * @return The string after processing to the specified length. If the original string is longer than the specified length, the original string will be returned as is.
     */
    public static final String padLeftWindows31J(final String argSource,
            final int argLength, final char argPadChar) {
        return BlancoStringUtilPad.padLeftWindows31J(argSource, argLength,
                argPadChar);
    }
}
