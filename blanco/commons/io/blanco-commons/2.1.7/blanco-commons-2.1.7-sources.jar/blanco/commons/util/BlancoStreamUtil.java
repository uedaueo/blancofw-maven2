/*
 * blanco Framework
 * Copyright (C) 2004-2009 IGA Tosiki
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 */
/*******************************************************************************
 * Copyright (c) 2009 IGA Tosiki, NTT DATA BUSINESS BRAINS Corp.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    IGA Tosiki (NTT DATA BUSINESS BRAINS Corp.) - initial API and implementation
 *******************************************************************************/
package blanco.commons.util;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * Contains utilities for streams in the blanco Framework.
 * 
 * In principle, most methods are provided as static methods.
 * 
 * @author IGA Tosiki
 */
public class BlancoStreamUtil {
    /**
     * Buffer size for stream copy, etc.
     */
    public static final int BUF_SIZE = 8192;

    /**
     * Converts the given stream to a byte array.
     * 
     * This method is used to get the opposite effect of ByteArrayInputStream.
     * 
     * @param inStream
     *            Input stream.
     * @return The byte array after conversion.
     * @throws IOException
     *             If an I/O exception occurs.
     */
    public static byte[] stream2Bytes(final InputStream inStream)
            throws IOException {
        if (inStream == null) {
            throw new IllegalArgumentException(
                    "The method that converts the input stream to a byte array was given null as the input stream, please give it a non-null value.");
        }

        final ByteArrayOutputStream result = new ByteArrayOutputStream();

        // Copies the stream.
        copy(inStream, result);

        result.flush();
        return result.toByteArray();
    }

    /**
     * Copies the given input stream to the output stream.
     * 
     * Makes a block copy of the stream with a buffer size of 8192 bytes.<br>
     * No flushing is performed inside this method. If necessary, flush() should be performed in the caller method.
     * 
     * @param inStream
     *            Input stream.
     * @param outStream
     *            Output stream.
     * @throws IOException
     *             If an I/O exception occurs.
     */
    public static final void copy(final InputStream inStream,
            final OutputStream outStream) throws IOException {
        if (inStream == null) {
            throw new IllegalArgumentException(
                    "The input stream parameter of the BlancoStreamUtil.copy method was given as null, please specify a non-null value.");
        }
        if (outStream == null) {
            throw new IllegalArgumentException(
                    "The output stream parameter of the BlancoStreamUtil.copy method was given as null, please specify a non-null value.");
        }

        final byte[] buf = new byte[BUF_SIZE];
        for (;;) {
            final int length = inStream.read(buf, 0, buf.length);
            if (length < 0) {
                break;
            }
            outStream.write(buf, 0, length);
        }
    }
}
