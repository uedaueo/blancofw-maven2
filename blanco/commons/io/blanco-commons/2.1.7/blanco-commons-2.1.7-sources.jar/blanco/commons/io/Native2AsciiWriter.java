/*
 * blanco Framework
 * Copyright (C) 2004-2009 IGA Tosiki
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 */
/*******************************************************************************
 * Copyright (c) 2009 IGA Tosiki, NTT DATA BUSINESS BRAINS Corp.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    IGA Tosiki (NTT DATA BUSINESS BRAINS Corp.) - initial API and implementation
 *******************************************************************************/
package blanco.commons.io;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.Properties;

import blanco.commons.util.BlancoStringUtil;

/**
 * Native2Ascii writer
 *
 * Performs Native2Ascii using java.util.Properties.
 *
 * @author IGA Tosiki
 * @see java.util.Properties#load(java.io.InputStream)
 */
public class Native2AsciiWriter {
    private BufferedWriter fWriter;
    private String lineSeparator = null;
    protected static final String CMDLINE_PREFIX = "commons: ";

    /**
     * Basically, give a writer with 8859_1 encoding.
     *
     * @param writer
     *            Output destination writer.
     */
    public Native2AsciiWriter(final BufferedWriter writer) {
        this.fWriter = writer;
        String lineSeparator = System.getProperty("line.separator");
        /*
         * for debugging
         */
        String lineSeparatorMark = "other, use system default.";
        if ("\n".equals(lineSeparator)) {
            lineSeparatorMark = "LF";
        } else if ("\r\n".equals(lineSeparator)) {
            lineSeparatorMark = "CRLF";
        } else if ("\r".equals(lineSeparator)) {
            lineSeparatorMark = "CR";
        } else {
            lineSeparator = System.lineSeparator();
        }
        System.out.println(CMDLINE_PREFIX + "lineSeparator = " + lineSeparatorMark);
        this.lineSeparator = lineSeparator;
    }

    /**
     * Flushes the writer.
     *
     * @throws IOException
     *             If an I/O exception occurs.
     */
    public void flush() throws IOException {
        fWriter.flush();
    }

    /**
     * Closes the writer.
     *
     * @throws IOException
     *             If an I/O exception occurs.
     */
    public void close() throws IOException {
        fWriter.close();
    }

    /**
     * Outputs a comment to the writer.<br>
     * If you want a space, add a space at the beginning of the string you are giving.
     *
     * @param comment
     * @throws IOException
     */
    public void writeComment(final String comment) throws IOException {
        fWriter.write("#" + encodeNative2AsciiComment(comment));
        if (this.lineSeparator != null) {
            fWriter.write(this.lineSeparator);
        } else {
            fWriter.newLine();
        }
    }

    /**
     * Outputs properties to the writer.
     *
     * @param key
     *            Key.
     * @param value
     *            Value.
     * @throws IOException
     *             If an I/O exception occurs.
     */
    public void writeProperty(final String key, final String value)
            throws IOException {
        fWriter.write(encodeNative2AsciiKey(key));
        fWriter.write("=");
        fWriter.write(encodeNative2AsciiValue(value));
        if (this.lineSeparator != null) {
            fWriter.write(this.lineSeparator);
        } else {
            fWriter.newLine();
        }
    }

    /**
     * Converts the given native string to a byte array in a virtual property file.
     *
     * @param nativeString
     *            Native string.
     * @return A byte array.
     * @throws IOException
     *             If an I/O exception occurs.
     */
    private static final byte[] encodeNative2AsciiKeyByteArray(
            final String nativeString) throws IOException {
        final Properties prop = new Properties();
        prop.setProperty(nativeString, "value");
        final ByteArrayOutputStream byteOutStream = new ByteArrayOutputStream();
        try {
            prop.store(byteOutStream, "dummy");
            byteOutStream.flush();
        } finally {
            byteOutStream.close();
        }
        return byteOutStream.toByteArray();
    }

    /**
     * Converts the given native string to a byte array in a virtual property file.
     *
     * @param nativeString
     *            A string to be converted.
     * @return A byte array after conversion.
     * @throws IOException
     *             If an I/O exception occurs.
     */
    private static final byte[] encodeNative2AsciiValueByteArray(
            final String nativeString) throws IOException {
        final Properties prop = new Properties();
        prop.setProperty("key", nativeString);
        final ByteArrayOutputStream byteOutStream = new ByteArrayOutputStream();
        try {
            prop.store(byteOutStream, "dummy");
            byteOutStream.flush();
        } finally {
            byteOutStream.close();
        }
        return byteOutStream.toByteArray();
    }

    /**
     * Executes native2ascii.
     *
     * See http://java.sun.com/j2se/1.4/ja/docs/ja/api/java/util/Properties.html#load(java.io.InputStream) for details.
     *
     * @param nativeString
     *            A string to be converted.
     * @return A string after conversion.
     * @see java.util.Properties#load(java.io.InputStream)
     */
    public static final String encodeNative2AsciiKey(final String nativeString) {
        try {
            final BufferedReader reader = new BufferedReader(
                    new InputStreamReader(new ByteArrayInputStream(
                            encodeNative2AsciiKeyByteArray(nativeString)),
                            "8859_1"));
            for (;;) {
                final String look = reader.readLine();
                if (look == null) {
                    throw new IllegalArgumentException(
                            "Unexpected termination of the intermediate memory file occurred during the process of encodeNative2Ascii ("
                                    + nativeString
                                    + "). This case is impossible.");
                }
                if (look.startsWith("#")) {
                    // Skips the comment line.
                    continue;
                }
                reader.close();
                if (look.endsWith("=value")) {
                    return look.substring(0, look.lastIndexOf("=value"));
                }
                throw new IllegalArgumentException("In the process of processing encodeNative2AsciiKey ("
                        + nativeString + "), an unexpected line ["
                        + look + "] was returned as a result of reading an intermediate memory file. This case is impossible.");
            }
        } catch (IOException ex) {
            throw new IllegalArgumentException("An unexpected exception occurred during the processing of encodeNative2Ascii ("
                    + nativeString + "). This case is impossible:"
                    + ex.toString());
        }
    }

    /**
     * Executes native2ascii.
     *
     * See http://java.sun.com/j2se/1.4/ja/docs/ja/api/java/util/Properties.html#load(java.io.InputStream) for details.
     *
     * @param nativeString
     *            A string to be converted.
     * @return A string after conversion.
     * @see java.util.Properties#load(java.io.InputStream)
     */
    public static final String encodeNative2AsciiValue(final String nativeString) {
        try {
            final BufferedReader reader = new BufferedReader(
                    new InputStreamReader(new ByteArrayInputStream(
                            encodeNative2AsciiValueByteArray(nativeString)),
                            "8859_1"));
            for (;;) {
                final String look = reader.readLine();
                if (look == null) {
                    throw new IllegalArgumentException(
                            "Unexpected termination of the intermediate memory file occurred during the process of encodeNative2Ascii ("
                                    + nativeString
                                    + "). This case is impossible.");
                }
                if (look.startsWith("#")) {
                    // Skips the comment line.
                    continue;
                }
                reader.close();
                if (look.startsWith("key=")) {
                    return look.substring("key=".length());
                }
                throw new IllegalArgumentException("In the process of processing encodeNative2AsciiKey ("
                        + nativeString + "), an unexpected line ["
                        + look + "] was returned as a result of reading an intermediate memory file. This case is impossible.");
            }
        } catch (IOException ex) {
            throw new IllegalArgumentException("An unexpected exception occurred during the processing of encodeNative2Ascii ("
                    + nativeString + "). This case is impossible:"
                    + ex.toString());
        }
    }

    /**
     * Runs Native2Ascii assuming that the given string is a comment.
     *
     * @param nativeString
     *            The string to be converted.
     * @return The string after conversion as an ascii comment.
     */
    public static final String encodeNative2AsciiComment(
            final String nativeString) {
        final StringReader reader = new StringReader(nativeString);
        final StringWriter writer = new StringWriter();
        try {
            for (;;) {
                final int iRead = reader.read();
                if (iRead < 0) {
                    break;
                }
                if ((iRead < 0x0020) || (iRead > 0x007E)) {
                    // Anything smaller than \u0020 and larger than \u007E will be displayed in hexadecimal as in \\uxxxx.
                    writer.write(toHexString((char) iRead));
                } else {
                    // Does nothing and just writes it down.
                    writer.write((char) iRead);
                }
            }
            writer.flush();
            return writer.toString();
        } catch (IOException e) {
            // This is unlikely.
            e.printStackTrace();
            return null;
        } finally {
            if (writer != null) {
                try {
                    writer.close();
                } catch (IOException e) {
                    // This is unlikely.
                    e.printStackTrace();
                }
            }
            if (reader != null) {
                reader.close();
            }
        }
    }

    /**
     * Converts the given char character to Unicode notation.<br>
     * This is different from the specification of native2ascii.exe, but it will convert to uppercase according to the specification of java.util.<br>
     * This routine is used to encode comments with Native2AsciiWriter.
     *
     * @param arg
     *            A string for which hexadecimal notation is to be used.
     * @return A string after conversion to hexadecimal notation.
     */
    private static final String toHexString(final char arg) {
        return "\\u" + BlancoStringUtil.toHexString(arg).toUpperCase();
    }
}
