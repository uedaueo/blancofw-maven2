/*
 * blanco Framework
 * Copyright (C) 2004-2009 IGA Tosiki
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 */
/*******************************************************************************
 * Copyright (c) 2009 IGA Tosiki, NTT DATA BUSINESS BRAINS Corp.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    IGA Tosiki (NTT DATA BUSINESS BRAINS Corp.) - initial API and implementation
 *******************************************************************************/
package blanco.commons.util;

import java.math.BigDecimal;

/**
 * Contains utilities for BigDecimal in the blanco Framework.
 * 
 * In principle, most methods are provided as static methods.
 * 
 * @author IGA Tosiki
 */
public class BlancoBigDecimalUtil {
    /**
     * Converts int to BigDecimal.
     * 
     * The constructor of BigDecimal, which inputs a numeric value, has been introduced in JDK 1.5 or later.<br>
     * This method is used to avoid accidentally using the constructor introduced in JDK1.5 or later for BigDecimal in order to make it work before 1.4.
     * 
     * @param valueSource
     *            The value of the source of the conversion.
     * @return The value after conversion to BigDecimal.
     */
    public static final BigDecimal toBigDecimal(final int valueSource) {
        return new BigDecimal(String.valueOf(valueSource));
    }
}
