/*
 * blanco Framework
 * Copyright (C) 2004-2009 IGA Tosiki
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 */
/*******************************************************************************
 * Copyright (c) 2009 IGA Tosiki, NTT DATA BUSINESS BRAINS Corp.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    IGA Tosiki (NTT DATA BUSINESS BRAINS Corp.) - initial API and implementation
 *******************************************************************************/
package blanco.commons.calc.parser.block;

import java.util.ArrayList;
import java.util.List;

/**
 * Implements a repeating type block.
 *
 * @author IGA Tosiki
 */
public class BlancoCalcParserTableBlock extends AbstractBlancoCalcParserBlock {
    private List<BlancoCalcParserTableColumn> list = new ArrayList<BlancoCalcParserTableColumn>();

    private String blockRowName = "";

    /**
     * Provides the number of lines (usually 1) in the title when searching for a title.
     */
    private int waitForIteratorTitleSearchY = 1;

    /**
     * A constructor for a repeating block object.
     *
     * @param name
     *            Block name.
     */
    public BlancoCalcParserTableBlock(String name) {
        setName(name);
    }

    /**
     * Adds a column to a repeating block object.
     *
     * @param item
     *            The column you want to add to the block.
     */
    public void add(BlancoCalcParserTableColumn item) {
        list.add(item);
    }

    /**
     * Searches for column items triggered by the title line.
     *
     * @param titleString
     *            Title string.
     * @return Found column items.
     */
    public BlancoCalcParserTableColumn findByTitleString(String titleString) {
        final int listSize = list.size();
        for (int index = 0; index < listSize; index++) {
            final BlancoCalcParserTableColumn item = (BlancoCalcParserTableColumn) list
                    .get(index);
            if (item.isStartString(titleString)) {
                return item;
            }
        }
        return null;
    }

    /**
     * Searches for column items triggered by the column number.
     *
     * @param pos
     *            Column number.
     * @return Found column items.
     */
    public BlancoCalcParserTableColumn findByColumnPosition(int pos) {
        final int listSize = list.size();
        for (int index = 0; index < listSize; index++) {
            final BlancoCalcParserTableColumn item = (BlancoCalcParserTableColumn) list
                    .get(index);
            if (item.getColumnPosition() == pos) {
                return item;
            }
        }
        return null;
    }

    /**
     * Gets the search range in the Y direction.
     *
     * @return The search range in the Y direction.
     */
    public int getSearchRangeForTitleY() {
        return waitForIteratorTitleSearchY;
    }

    /**
     * Gets the search range in the X direction from the title string.
     *
     * @param arg
     *            The search range in the X direction.
     */
    public void setSearchRangeForTitleY(int arg) {
        waitForIteratorTitleSearchY = arg;
    }

    /**
     * Sets the column name.
     *
     * @param arg
     *            The column name.
     */
    public void setRowName(String arg) {
        blockRowName = arg;
    }

    /**
     * Gets the column name.
     *
     * @return The column name.
     */
    public String getRowName() {
        return blockRowName;
    }

    /**
     *  Clears all position information of TableColumn.
     */
    public void clearPositions() {
        for (BlancoCalcParserTableColumn item : list) {
            item.setColumnPosition(-1);
        }
    }
}
