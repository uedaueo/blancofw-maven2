/*
 * blanco Framework
 * Copyright (C) 2004-2009 IGA Tosiki
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 */
/*******************************************************************************
 * Copyright (c) 2009 IGA Tosiki, NTT DATA BUSINESS BRAINS Corp.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    IGA Tosiki (NTT DATA BUSINESS BRAINS Corp.) - initial API and implementation
 *******************************************************************************/
package blanco.commons.util;

import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;

/**
 * This class is a collection of utilities for Java source code output in the blanco Framework.
 * 
 * This class is also used from C#.NET source code generation.
 * 
 * @author IGA Tosiki
 */
public final class BlancoJavaSourceUtil {
    /**
     * Escapes the given string as if it were output as a Java source code string.
     * 
     * Escapes ¥/ backslashes and newline codes.<br>
     * It does not perform any other processing. For example, resistance to injection attacks is not handled by this method.
     * 
     * @param originalString
     *            Input string.
     * @return The string after the escape processing has been performed.
     */
    public static final String escapeStringAsJavaSource(
            final String originalString) {
        if (originalString == null) {
            throw new IllegalArgumentException(
                    "An input violation occurred in BlancoJavaSourceUtil.escapeStringAsJavaSource. A null was given as a parameter to this method, please enter a non-null value.");
        }

        final StringReader reader = new StringReader(originalString);
        final StringWriter writer = new StringWriter();
        try {
            for (;;) {
                final int iRead = reader.read();
                if (iRead < 0) {
                    break;
                }
                switch (iRead) {
                case '\\':
                    writer.write("\\\\");
                    break;
                case '\n':
                    writer.write("\\n");
                    break;
                case '"':
                    writer.write("\\\"");
                    break;
                default:
                    writer.write((char) iRead);
                    break;
                }
            }
            writer.flush();
        } catch (IOException e) {
            // There is no way that it can come in here.
            e.printStackTrace();
        }
        return writer.toString();
    }

    /**
     * Escapes a given string into something that can be treated as a JavaDoc string. Escapes as a JavaDoc string.
     * 
     * This is equivalent to escaping as HTML. <, >, &, and ” are escaped.
     * 
     * @param originalString
     *            Input string.
     * @return The string after the escape processing has been performed.
     */
    public static final String escapeStringAsJavaDoc(final String originalString) {
        if (originalString == null) {
            throw new IllegalArgumentException(
                    "An input violation occurred in BlancoJavaSourceUtil.escapeStringAsJavaDoc. A null was given as a parameter to this method, please enter a non-null value.");
        }

        final StringReader reader = new StringReader(originalString);
        final StringWriter writer = new StringWriter();
        try {
            for (;;) {
                final int iRead = reader.read();
                if (iRead < 0) {
                    break;
                }
                switch (iRead) {
                case '&':
                    writer.write("&amp;");
                    break;
                case '<':
                    writer.write("&lt;");
                    break;
                case '>':
                    writer.write("&gt;");
                    break;
                case '"':
                    writer.write("&quot;");
                    break;
                case '\n':
                    // Since it is not good if line feeds are output directly to JavaDoc, we treat them as strings.
                    writer.write("\\n");
                    break;
                default:
                    writer.write((char) iRead);
                    break;
                }
            }
            writer.flush();
        } catch (IOException e) {
            // There is no way that it can come in here.
            e.printStackTrace();
        }
        return writer.toString();
    }
}
