/*
 * blanco Framework
 * Copyright (C) 2004-2009 IGA Tosiki
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 */
/*******************************************************************************
 * Copyright (c) 2009 IGA Tosiki, NTT DATA BUSINESS BRAINS Corp.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    IGA Tosiki (NTT DATA BUSINESS BRAINS Corp.) - initial API and implementation
 *******************************************************************************/
package blanco.commons.util;

import java.io.UnsupportedEncodingException;

/**
 * Contains the internal processing of string-related utilities in the blanco Framework.
 * 
 * This class is set to be private outside the package.
 * 
 * @author IGA Tosiki
 */
class BlancoStringUtilPad {
    /**
     * Adds characters to the right side of the string until the specified length is reached.
     * 
     * @param argSource
     *            Original string.
     * @param argLength
     *            Desired length.
     * @param argPadChar
     *            Characters to be used for stuffing.
     * @return The string after processing to the specified length. If the original string is longer than the specified length, the original string will be returned as is.
     */
    public static final String padRight(final String argSource,
            final int argLength, final char argPadChar) {
        if (argSource == null) {
            throw new IllegalArgumentException(
                    "The input string of BlancoStringUtil.padRight was given null.");
        }

        final StringBuffer buf = new StringBuffer();
        buf.append(argSource);

        for (; buf.length() < argLength;) {
            // Increases the number of letters one by one.
            buf.append(argPadChar);
        }

        return buf.toString();
    }

    /**
     * Adds characters to the left side of the string until the specified length is reached.
     * 
     * @param argSource
     *            Original string.
     * @param argLength
     *            Desired length.
     * @param argPadChar
     *            Characters to be used for stuffing.
     * @return The string after processing to the specified length. If the original string is longer than the specified length, the original string will be returned as is.
     */
    public static final String padLeft(final String argSource,
            final int argLength, final char argPadChar) {
        if (argSource == null) {
            throw new IllegalArgumentException(
                    "The input string of BlancoStringUtil.padLefo was given null.");
        }

        final int originalLength = argSource.length();
        final StringBuffer buf = new StringBuffer();

        for (; buf.length() + originalLength < argLength;) {
            // Increases the number of letters one by one.
            buf.append(argPadChar);
        }

        return buf.toString() + argSource;
    }

    /**
      * Adds characters to the right side of the string until it reaches the specified length in Windows 31J.
     * 
     * @param argSource
     *            Original string.
     * @param argLength
     *            Desired length.
     * @param argPadChar
     *            Characters to be used for stuffing.
     * @return The string after processing to the specified length. If the original string is longer than the specified length, the original string will be returned as is.
     */
    public static final String padRightWindows31J(final String argSource,
            final int argLength, final char argPadChar) {
        if (argSource == null) {
            throw new IllegalArgumentException(
                    "The input string of BlancoStringUtil.padRight was given null.");
        }

        final StringBuffer buf = new StringBuffer();
        buf.append(argSource);

        try {
            for (; buf.toString().getBytes("Windows-31J").length < argLength;) {
                // Increases the number of letters one by one.
                buf.append(argPadChar);
            }
            return buf.toString();
        } catch (UnsupportedEncodingException ex) {
            throw new IllegalArgumentException(
                    "An unexpected exception occurred: Windows-31J encoding could not be obtained.", ex);
        }
    }

    /**
     * Adds characters to the left side of the string until it reaches the specified length in Windows 31J.
     * 
     * @param argSource
     *            Original string.
     * @param argLength
     *            Desired length.
     * @param argPadChar
     *            Characters to be used for stuffing.
     * @return The string after processing to the specified length. If the original string is longer than the specified length, the original string will be returned as is.
     */
    public static final String padLeftWindows31J(final String argSource,
            final int argLength, final char argPadChar) {
        if (argSource == null) {
            throw new IllegalArgumentException(
                    "The input string of BlancoStringUtil.padLefo was given null.");
        }

        try {
            final int originalLength = argSource.getBytes("Windows-31J").length;
            final StringBuffer buf = new StringBuffer();

            for (; buf.toString().getBytes("Windows-31J").length
                    + originalLength < argLength;) {
                // Increases the number of letters one by one.
                buf.append(argPadChar);
            }
            return buf.toString() + argSource;
        } catch (UnsupportedEncodingException ex) {
            throw new IllegalArgumentException(
                    "An unexpected exception occurred: Windows-31J encoding could not be obtained.", ex);
        }
    }
}
