/*
 * blanco Framework
 * Copyright (C) 2004-2009 IGA Tosiki
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 */
/*******************************************************************************
 * Copyright (c) 2009 IGA Tosiki, NTT DATA BUSINESS BRAINS Corp.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    IGA Tosiki (NTT DATA BUSINESS BRAINS Corp.) - initial API and implementation
 *******************************************************************************/
package blanco.commons.util;

import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;

/**
 * This class is a collection of utilities for VB.NET source code output in blanco Framework.
 * 
 * @author IGA Tosiki
 */
public final class BlancoVbSourceUtil {
    /**
     * Escapes the given string as if it were output as a VB.NET source code string.
     * 
     * Escapes ¥/ backslashes and newline codes.<br>
     * It does not perform any other processing. For example, resistance to injection attacks is not handled by this method.
     * 
     * @param originalString
     *            Input string.
     * @return The string after the escape processing has been performed.
     */
    public static final String escapeStringAsVbSource(
            final String originalString) {
        if (originalString == null) {
            throw new IllegalArgumentException(
                    "An input violation occurred in BlancoVbSourceUtil.escapeStringAsVbSource. A null was given as a parameter to this method, please enter a non-null value.");
        }

        final StringReader reader = new StringReader(originalString);
        final StringWriter writer = new StringWriter();
        try {
            for (;;) {
                final int iRead = reader.read();
                if (iRead < 0) {
                    break;
                }
                switch (iRead) {
                case '\\':
                    writer.write("\\\\");
                    break;
                case '\n':
                    writer.write("\\n");
                    break;
                case '"':
                    writer.write("\"\"");
                    break;
                case '＂':
                    // 0xfa57 (Windows-31J)
                    // 0xff02 (UTF-16BE)
                    writer.write("\"＂");
                    break;
                default:
                    writer.write((char) iRead);
                    break;
                }
            }
            writer.flush();
        } catch (IOException e) {
            // There is no way that it can come in here.
            e.printStackTrace();
        }
        return writer.toString();
    }
}
