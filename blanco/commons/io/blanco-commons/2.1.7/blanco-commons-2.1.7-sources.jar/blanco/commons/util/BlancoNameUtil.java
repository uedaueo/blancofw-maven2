/*
 * blanco Framework
 * Copyright (C) 2004-2009 IGA Tosiki
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 */
/*******************************************************************************
 * Copyright (c) 2009 IGA Tosiki, NTT DATA BUSINESS BRAINS Corp.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    IGA Tosiki (NTT DATA BUSINESS BRAINS Corp.) - initial API and implementation
 *******************************************************************************/
package blanco.commons.util;

import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;

/**
 * This class is a collection of utilities related to the name of the blanco Framework.
 * 
 * @author IGA Tosiki
 */
public class BlancoNameUtil {
    /**
     * Determines whether the given name is valid to use as a file name.
     * 
     * Returns false if ／, ￥, ：, ；, ＊, ？, ”, ＞, ＜, and ｜ is given.
     * 
     * @param checkString
     *            String to be checked as the file name.
     * @return Returns true if it is a valid file name, false if it is not.
     */
    public static final boolean isValidFileName(final String checkString) {
        if (checkString == null) {
            throw new IllegalArgumentException(
                    "The method to determine if the file name is valid was given a null value. Give it a non-null value.");
        }

        if (checkString.indexOf('/') >= 0 || checkString.indexOf('\\') >= 0
                || checkString.indexOf(':') >= 0
                || checkString.indexOf(';') >= 0
                || checkString.indexOf('*') >= 0
                || checkString.indexOf('?') >= 0
                || checkString.indexOf('\"') >= 0
                || checkString.indexOf('>') >= 0
                || checkString.indexOf('<') >= 0
                || checkString.indexOf('|') >= 0) {
            // If it contains any of these characters, it is invalid as a file name.
            return false;
        }
        return true;
    }

    /**
     * Gets a list of characters that should not be used as a file name in display format.
     * 
     * @return A list of strings that should not be used, expressed in a display format.
     */
    public static final String invalidFileNameChar() {
        return "/ \\ : ; * ? \" > < |";
    }

    /**
     * Removes the extension from the file name (given without the directory name).
     * 
     * A dot will be removed as well as the extension.<br>
     * If a file name such as .cvsignore is given, it will return as is.
     * 
     * @param checkString
     *            A file name (not including directories).
     * @return File name without extension.
     */
    public static final String trimFileExtension(final String checkString) {
        if (checkString == null) {
            throw new IllegalArgumentException(
                    "The method to remove the extension from the file name was given null. Give it a non-null value.");
        }

        // Finds the last extension.
        final int posDot = checkString.lastIndexOf(".");
        if (posDot == 0) {
            // This is a file name starting with a dot.
            // Returns the file as is, without trimming the extension.
            return checkString;
        }
        if (posDot > 0) {
            // Removes the extension.
            return checkString.substring(0, posDot);
        }

        return checkString;
    }

    /**
     * Splits the given string with the specified delimiter.
     * 
     * The behavior when the delimiter is '/' is as follows.<br>
     * Normal case 1: [aaa/bbb/ccc]→{ "aaa", "bbb", "ccc" }<br>
     * Normal case 2: [aaa//ccc]→{ "aaa", "", "ccc" }<br>
     * Normal case 3: [/aaa/bbb]→{ "", "aaa", "bbb" }<br>
     * The first slash counts as one.<br>
     * Normal case 4: [/aaa/bbb/]→{ "", "aaa", "bbb" }<br>
     * Ignores the last slash.<br>
     * <br>
     * Boundary case 1: [/]→{ "" }<br>
     * Boundary case 2: [///]→{ "", "", "" }<br>
     * Boundary case 3: []→Zero-length array<br>
     * Boundary case 4: null→Zero-length array<br>
     * 
     * @param originalString
     *            A string separated by a delimiter; if null is given, a zero-length String array will be returned.
     * @return A string that has been split. The delimiter itself is not included.
     */
    public static final String[] splitString(final String originalString,
            final char delimiter) {
        if (originalString == null) {
            // For null, it is assumed that there are no items.
            return new String[0];
        }

        final StringReader reader = new StringReader(originalString);
        StringWriter writer = null;
        final List<java.lang.String> result = new ArrayList<java.lang.String>();
        for (;;) {
            final int read;
            try {
                read = reader.read();
            } catch (IOException e) {
                e.printStackTrace();
                throw new IllegalArgumentException(
                        "An exception was thrown when reading from a StringReader in the work. This is a completely unexpected case:"
                                + e.toString());
            }
            if (read < 0) {
                break;
            }
            if (writer == null) {
                writer = new StringWriter();
            }
            if ((char) read == delimiter) {
                if (writer != null) {
                    try {
                        writer.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                        throw new IllegalArgumentException(
                                "An exception was thrown on the close of the StringWriter in the work. This is a completely unexpected case:"
                                        + e.toString());
                    }
                    result.add(writer.toString());
                    // Resets the contents of the work variable.
                    writer = null;
                }
            } else {
                writer.write((char) read);
            }
        }
        if (writer != null) {
            try {
                writer.close();
            } catch (IOException e) {
                e.printStackTrace();
                throw new IllegalArgumentException(
                        "The error occurred in a completely unexpected and improbable case:" + e.toString());
            }
            result.add(writer.toString());
            // Resets the contents of the work variable.
            writer = null;
        }
        return (String[]) result.toArray(new String[result.size()]);
    }

    /**
     * Assumes that the given string is a path and splits the string by separating it with a / (slash) symbol.
     * 
     * Normal case 1: [aaa/bbb/ccc]→{ "aaa", "bbb", "ccc" }<br>
     * Normal case 2: [aaa//ccc]→{ "aaa", "", "ccc" }<br>
     * Normal case 3: [/aaa/bbb]→{ "", "aaa", "bbb" }<br>
     * The first slash counts as one.<br>
     * Normal case 4: [/aaa/bbb/]→{ "", "aaa", "bbb" }<br>
     * Ignores the last slash.<br>
     * <br>
     * Boundary case 1: [/]→{ "" }<br>
     * Boundary case 2: [///]→{ "", "", "" }<br>
     * Boundary case 3: []→Zero-length array<br>
     * Boundary case 4: null→Zero-length array<br>
     * 
     * @param originalString
     *            A string separated by a / (slash) symbol; if null is given, a zero-length String array will be returned.
     * @return The split string. The / (slash) symbol is not included.
     */
    public static final String[] splitPath(final String originalString) {
        return splitString(originalString, '/');
    }

    /**
     * Removes the package name from the given class name.
     * 
     * @param argClassName
     *            Class name with full package name.
     * @return Class name without package name.
     */
    public static final String trimJavaPackage(final String argClassName) {
        if (argClassName == null) {
            throw new IllegalArgumentException(
                    "The method that removes the package name from the class name was given a null value. Give it a non-null value.");
        }

        // Splits the full class name with a dot.
        final String[] work = splitString(argClassName, '.');
        for (int index = work.length - 1; index >= 0; index--) {
            if (work[index].length() > 0) {
                // We will look at the string after the split, and the last string with the length will be used as the class name.
                return work[index];
            }
        }

        // Couldn't find a single name with any substance.
        throw new IllegalArgumentException("String [" + argClassName
                + "] cannot be processed as a Java class name with package name.");
    }

    /**
     * Gets the Java package name from the given URI according to some naming convention.
     * 
     * @param uri
     *            Input URI.
     * @return Java package name.
     */
    public static final String uri2JavaPackage(final String uri) {
        if (uri == null) {
            throw new IllegalArgumentException(
                    "The method to get the package name from the URI was given null. Give it a non-null value.");
        }

        final StringWriter writer = new StringWriter();
        final String[] splitedUri = splitString(uri, ':');
        boolean isFirst = true;
        if (splitedUri.length < 2) {
            throw new IllegalArgumentException(
                    "The given URI ["
                            + uri
                            + "] is malformed. Please specify it in a format such as [http://www.w3.org/XML/Schema].");
        }
        final String[] splitDir = BlancoNameUtil
                .splitString(splitedUri[1], '/');
        for (int index = 0; index < splitDir.length; index++) {
            final String[] splitDomain = BlancoNameUtil.splitString(
                    splitDir[index], '.');
            for (int indexDomain = splitDomain.length - 1; indexDomain >= 0; indexDomain--) {
                // Since this is the part that is supposed to represent the domain, processes it in reverse order.
                if (splitDomain[indexDomain].length() > 0) {
                    if (isFirst) {
                        isFirst = false;
                    } else {
                        writer.write(".");
                    }
                    writer.write(splitDomain[indexDomain]);
                }
            }
        }
        for (int indexUri = 2; indexUri < splitedUri.length; indexUri++) {
            final String[] splitDirAfter = BlancoNameUtil.splitString(
                    splitedUri[indexUri], '/');
            // Point: The first node will be the port number, so ignores it.
            for (int index = 1; index < splitDirAfter.length; index++) {
                if (isFirst) {
                    isFirst = false;
                } else {
                    writer.write(".");
                }
                writer.write(splitDirAfter[index]);
            }
        }

        try {
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
            throw new IllegalArgumentException(
                    "Impossible exception: An exception was raised during close() of StringWriter:"
                            + e.toString());
        }
        return writer.toString();
    }
}
