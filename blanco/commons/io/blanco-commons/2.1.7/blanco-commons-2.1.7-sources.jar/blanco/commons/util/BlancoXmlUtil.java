/*
 * blanco Framework
 * Copyright (C) 2004-2009 IGA Tosiki
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 */
/*******************************************************************************
 * Copyright (c) 2009 IGA Tosiki, NTT DATA BUSINESS BRAINS Corp.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    IGA Tosiki (NTT DATA BUSINESS BRAINS Corp.) - initial API and implementation
 *******************************************************************************/
package blanco.commons.util;

import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMResult;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;

/**
 * This class is a collection of XML-related utilities in the blanco Framework.
 * 
 * @author IGA Tosiki
 */
public class BlancoXmlUtil {
    /**
     * Gets a string from a selected node (or element).
     * 
     * This is used to obtain all text data hanging on a node.
     * 
     * @param nodeTarget
     *            The node to be targeted.
     * @return The obtained text string.
     */
    public static final String getTextContent(final Node nodeTarget) {
        if (nodeTarget == null) {
            throw new IllegalArgumentException(
                    "The method to get the text from the node was given a null value. Gives it a non-null value.");
        }

        String result = null;
        final NodeList listText = nodeTarget.getChildNodes();
        final int sizeChildList = listText.getLength();
        for (int indexChild = 0; indexChild < sizeChildList; indexChild++) {
            final Node nodeChild = listText.item(indexChild);
            if (nodeChild instanceof Text) {
                final Text textLook = (Text) nodeChild;
                result = (result == null ? textLook.getData() : result
                        + textLook.getData());
            }
        }
        return result;
    }

    /**
     * Reads a string with the specified tag name from an element.
     * 
     * @param elementTarget
     *            The element to be targeted.
     * @param tagName
     *            Tag name.
     * @return The obtained text string.
     */
    public static final String getTextContent(final Element elementTarget,
            final String tagName) {
        if (elementTarget == null) {
            throw new IllegalArgumentException(
                    "The method to get the text from the element was given null as the element. Give it a non-null value.");
        }
        if (tagName == null) {
            throw new IllegalArgumentException(
                    "The method to get the text from the element was given null as the tag name. Give it a non-null value.");
        }

        String result = null;
        final NodeList listElementTarget = elementTarget
                .getElementsByTagName(tagName);
        final int sizeList = listElementTarget.getLength();
        for (int index = 0; index < sizeList; index++) {
            final Node nodeLook = listElementTarget.item(index);
            if (nodeLook instanceof Element) {
                final Element elementLook = (Element) nodeLook;

                final NodeList listText = elementLook.getChildNodes();
                final int sizeChildList = listText.getLength();
                for (int indexChild = 0; indexChild < sizeChildList; indexChild++) {
                    final Node nodeChild = listText.item(indexChild);
                    if (nodeChild instanceof Text) {
                        final Text textLook = (Text) nodeChild;
                        result = (result == null ? textLook.getData() : result
                                + textLook.getData());
                    }
                }
            }
        }
        return result;
    }

    /**
     * Converts the given XML file to a DOM tree.
     * 
     * Internally, the conversion is performed using the commonly used XML conversion API.
     * 
     * @param metaXmlSourceFile
     *            Input XML file.
     * @return Output DOM tree.
     * @throws IllegalArgumentException
     *             If the input file is invalid, or if the XML transformation acquisition fails, etc.
     */
    public static final DOMResult transformFile2Dom(final File metaXmlSourceFile) {
        if (metaXmlSourceFile == null) {
            throw new IllegalArgumentException(
                    "The method that generates the DOM tree with the file as input was given a null value. Give it a non-null value.");
        }

        if (metaXmlSourceFile.exists() == false) {
            throw new IllegalArgumentException("XML file to DOM conversion: The specified file ["
                    + metaXmlSourceFile.getAbsolutePath() + "] was not found.");
        }
        if (metaXmlSourceFile.isFile() == false) {
            throw new IllegalArgumentException("XML file to DOM conversion: The specified file ["
                    + metaXmlSourceFile.getAbsolutePath()
                    + "] was not actually a file.");
        }
        if (metaXmlSourceFile.canRead() == false) {
            throw new IllegalArgumentException("XML file to DOM conversion: The specified file ["
                    + metaXmlSourceFile.getAbsolutePath() + "] cannot be read.");
        }

        try {
            byte[] fileBytes = BlancoFileUtil.file2Bytes(metaXmlSourceFile);
            return transformStream2Dom(new ByteArrayInputStream(fileBytes));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            throw new IllegalArgumentException(
                    "Unexpected exception: A file not found exception occurred during XML conversion." + e.toString());
        } catch (IOException e) {
            e.printStackTrace();
            throw new IllegalArgumentException(
                    "Unexpected exception: A file I/O exception occurred during XML conversion." + e.toString());
        }
    }

    /**
     * Converts the given XML stream to a DOM tree.
     * 
     * Internally, the conversion is performed using the commonly used XML conversion API.
     * 
     * @param inXmlSource
     *            Input XML stream.
     * @return Output DOM tree.
     * @throws IllegalArgumentException
     *             If the input file is invalid, or if the XML transformation acquisition fails, etc.
     */
    public static final DOMResult transformStream2Dom(
            final InputStream inXmlSource) {
        if (inXmlSource == null) {
            throw new IllegalArgumentException(
                    "The process of converting the input XML stream to a DOM tree was given null as a stream. Give it a non-null stream.");
        }

        try {
            final DOMResult result = new DOMResult();
            final TransformerFactory tf = TransformerFactory.newInstance();
            final Transformer transformer = tf.newTransformer();
            transformer.transform(new StreamSource(inXmlSource), result);
            return result;
        } catch (TransformerConfigurationException e) {
            e.printStackTrace();
            throw new IllegalArgumentException(
                    "Unexpected exception: An XML transformation configuration exception occurred." + e.toString());
        } catch (TransformerException e) {
            throw new IllegalArgumentException("Unexpected exception: An XML conversion exception occurred."
                    + e.toString());
        }
    }

    /**
     * Converts the given DOM tree to an XML file.
     * 
     * Internally, the conversion is performed using the commonly used XML conversion API.
     * 
     * @param document
     *            XML Document.
     * @param metaXmlResultFile
     *            Output XML file.
     * @throws IllegalArgumentException
     *             If the input XML tree is invalid, or if the XML transformation acquisition fails, etc.
     */
    public static final void transformDom2File(final Document document,
            final File metaXmlResultFile) {
        if (document == null) {
            throw new IllegalArgumentException(
                    "DOM to XML file conversion: null was given for the input XML document, but a non-null value must be specified for this parameter.");
        }
        if (metaXmlResultFile == null) {
            throw new IllegalArgumentException(
                    "DOM to XML file conversion: null was given for the output XML file, but a non-null value must be specified for this parameter.");
        }

        if (metaXmlResultFile.exists() == true
                && metaXmlResultFile.canWrite() == false) {
            throw new IllegalArgumentException("DOM to XML file conversion: The specified file ["
                    + metaXmlResultFile.getAbsolutePath() + "] could not be written.");
        }

        try {
            final OutputStream outStream = new BufferedOutputStream(
                    new FileOutputStream(metaXmlResultFile));
            try {
                transformDom2Stream(document, outStream);
                // Flushes when the program finishes normally.
                outStream.flush();
            } finally {
                outStream.close();
            }
        } catch (IOException e) {
            throw new IllegalArgumentException("DOM to XML file conversion: An I/O exception occurred during the conversion to the specified file ["
                    + metaXmlResultFile.getAbsolutePath()
                    + "]." + e.toString());
        }
    }

    /**
     * Converts the given DOM tree to an XML stream.
     * 
     * Internally, the conversion is performed using the commonly used XML conversion API.
     * 
     * @param document
     *            Input XML tree.
     * @param outXmlResult
     *            Output DOM stream.
     * @throws IllegalArgumentException
     *             If the parameter is invalid, or if the XML transformation acquisition fails, etc.
     */
    public static final void transformDom2Stream(final Document document,
            final OutputStream outXmlResult) {
        if (document == null) {
            throw new IllegalArgumentException(
                    "The process of converting the DOM tree to the output XML stream was given null as the XML document. Give it a non-null value as the XML document.");
        }
        if (outXmlResult == null) {
            throw new IllegalArgumentException(
                    "The process of converting the DOM tree to the output XML stream was given null as the stream. Give it a non-null value as stream.");
        }

        try {
            final DOMSource source = new DOMSource(document);
            final TransformerFactory tf = TransformerFactory.newInstance();
            final Transformer transformer = tf.newTransformer();
            transformer.transform(source, new StreamResult(outXmlResult));
        } catch (TransformerConfigurationException e) {
            e.printStackTrace();
            throw new IllegalArgumentException(
                    "Unexpected exception: XML transformation configuration exception occurred." + e.toString());
        } catch (TransformerException e) {
            throw new IllegalArgumentException("Unexpected exception: An XML conversion exception occurred."
                    + e.toString());
        }
    }

    /**
     * Creates a new XML document.
     * 
     * Gets the DocumentBuilder from the DocumentFactory and creates a new XML document from it.
     * 
     * @return Newly created XML document object.
     * @throws IllegalArgumentException
     *             If it fails to create a new DocumentBuilder.
     */
    public static final Document newDocument() {
        final DocumentBuilderFactory builderFactory = DocumentBuilderFactory
                .newInstance();
        DocumentBuilder builder = null;
        try {
            builder = builderFactory.newDocumentBuilder();
        } catch (ParserConfigurationException e) {
            throw new IllegalArgumentException(
                    "Failed to create a new DocumentBuilder." + e.toString());
        }
        return builder.newDocument();
    }

    /**
     * Adds a child element with the specified element name to the specified element.
     * 
     * If text is specified, a text node will be added. If null is specified for the text, only the child elements will be added.
     * 
     * @param document
     *            XML document.
     * @param elementParent
     *            Parent element.
     * @param addElementName
     *            Name of the new element.
     * @param addElementText
     *            Text to be added to the new element; if null is specified, the text addition will be omitted.
     */
    public static final void addChildElement(final Document document,
            final Element elementParent, final String addElementName,
            final String addElementText) {
        if (document == null) {
            throw new IllegalArgumentException(
                    "The element add (addElementText) was given null as a document. Specify a non-null value.");
        }
        if (elementParent == null) {
            throw new IllegalArgumentException(
                    "The element add (addElementText) was given null as a parent element. Specify a non-null value.");
        }
        if (addElementName == null) {
            throw new IllegalArgumentException(
                    "The element add (addElementText) was given null as a name of the new element. Specify a non-null value.");
        }
        if (addElementName.length() == 0) {
            throw new IllegalArgumentException(
                    "The element add (addElementText) was given zero-length string as a name of the new element. Specify a length greater than or equal to 1.");
        }

        // First, generates the elements you want to add.
        final Element elementAdd = document.createElement(addElementName);
        if (addElementText != null) {
            // Additional processing will be performed only if text is specified.
            // Generates a text node.
            final Text elemnetTextNode = document
                    .createTextNode(addElementText);
            // Add a text node to an element.
            elementAdd.appendChild(elemnetTextNode);
        }
        // Finally, adds the new element to the parent element.
        elementParent.appendChild(elementAdd);
    }

    /**
     * Searches for elements with the specified element name.
     * 
     * @param path
     *            Specify the path as aaa/bbb.
     * @return Obtained elements.
     */
    public static final Element getElement(final Node nodeTarget,
            final String path) {
        if (nodeTarget == null) {
            throw new IllegalArgumentException(
                    "The method to search for elements with the specified element name was given null as a node. Give it a non-null value.");
        }
        if (nodeTarget == null) {
            throw new IllegalArgumentException(
                    "The method to search for elements with the specified element name was given null as a path name. Give it a non-null value.");
        }

        final String[] splitPath = BlancoNameUtil.splitPath(path);

        final NodeList nodeList = nodeTarget.getChildNodes();
        final int nodeLength = nodeList.getLength();
        for (int index = 0; index < nodeLength; index++) {
            final Node nodeLook = nodeList.item(index);
            if (nodeLook instanceof Element) {
                final Element elementLook = (Element) nodeLook;
                if (elementLook.getNodeName().equals(splitPath[0])) {
                    // It got a hit.
                    if (splitPath.length == 1) {
                        // System.out.println("Found it." +
                        // elementLook.getNodeName());
                        return elementLook;
                    } else {
                        // System.out.println("Performs recursion." +
                        // elementLook.getNodeName());
                        return getElement(elementLook, path
                                .substring(splitPath[0].length() + 1));
                    }
                }
            }
        }
        // Couldn't find it.
        return null;
    }
}
