/*
 * blanco Framework
 * Copyright (C) 2004-2009 IGA Tosiki
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 */
/*******************************************************************************
 * Copyright (c) 2009 IGA Tosiki, NTT DATA BUSINESS BRAINS Corp.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    IGA Tosiki (NTT DATA BUSINESS BRAINS Corp.) - initial API and implementation
 *******************************************************************************/
package blanco.commons.util;

/**
 * Contains utilities related to bytes in the blanco Framework.
 * 
 * In principle, most methods are provided as static methods.
 * 
 * @author IGA Tosiki
 */
public class BlancoByteUtil {
    /**
     * Compares the contents of a byte array.
     * 
     * @param arg0
     *            Left side value.
     * @param arg1
     *            Right side value.
     * @return 0 if a match is found; otherwise, (left side value - right side) value.
     */
    public static final int compare(final byte[] arg0, final byte[] arg1) {
        if (arg0 == null) {
            throw new IllegalArgumentException(
                    "The first input parameter of BlancoStreamUtil.compare was given as null.");
        }
        if (arg1 == null) {
            throw new IllegalArgumentException(
                    "The second input parameter of BlancoStreamUtil.compare was given as null.");
        }

        for (int index = 0;; index++) {
            // First, checks the length.
            if (index == arg0.length) {
                // Exceeded the length.
                if (index == arg1.length) {
                    // They were in agreement until the very end.
                    return 0;
                } else {
                    // The right side value is bigger.
                    return -1;
                }
            } else if (index == arg1.length) {
                // Exceeded the length.
                // The left side value is bigger.
                return 1;
            }
            if (arg0[index] == arg1[index]) {
                continue;
            } else {
                // There was no match.
                return arg0[index] - arg1[index];
            }
        }
    }
}
