/*
 * blanco Framework
 * Copyright (C) 2004-2009 IGA Tosiki
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 */
/*******************************************************************************
 * Copyright (c) 2009 IGA Tosiki, NTT DATA BUSINESS BRAINS Corp.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    IGA Tosiki (NTT DATA BUSINESS BRAINS Corp.) - initial API and implementation
 *******************************************************************************/
package blanco.commons.util;

import java.io.CharArrayWriter;
import java.io.IOException;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;

/**
 * This class is a collection of utilities for name adjustment in the blanco Framework.
 * 
 * @author IGA Tosiki
 */
public class BlancoNameAdjuster {
    /**
     * As a name variant of the blanco Framework, checks if it is a character that should be adjusted.
     * 
     * It determines whether the characters are considered inappropriate for use as Java class or method names.<br>
     * Even if a character can be used in the language specification, the blanco framework judges it as an adjustment character if it is not recommended for use.
     * 
     * @param checkChar
     *            The input character to be checked.
     * @return If it is determined that the character should be adjusted, returns true.
     */
    public static final boolean checkAdjustChar(final char checkChar) {
        switch (checkChar) {
        case '!':
        case '"':
        case '#':
        case '%':
        case '&':
        case '\'':
        case '(':
        case ')':
        case '-':
        case '=':
        case '^':
        case '~':
        case '\\':
        case '|':
        case '@':
        case '[':
        case ']':
        case '{':
        case '}':
        case ';':
        case '+':
        case ':':
        case '*':
        case '<':
        case '>':
        case ',':
        case '.':
        case '/':
        case '?':
        case '_':
        case ' ':
            // Decided that this was a character that should be adjusted.
            return true;
        default:
            return false;
        }
    }

    /**
     * As a name variant of the blanco Framework, it checks if it is a character that should be adjusted.
     * 
     * It determines whether the characters are considered inappropriate for use as Java class or method names.<br>
     * Even if a character can be used in the language specification, the blanco framework judges it as an adjustment character if it is not recommended for use.
     * 
     * @param checkChar
     *            The input character to be checked.
     * @return If it is determined that the character should be adjusted, returns true.
     */
    public static final boolean checkAdjustCharExist(final String checkChar) {
        if (checkChar == null) {
            throw new IllegalArgumentException(
                    "The method that checks if the adjustment string is included (BlancoNameAdjuster.checkAdjustCharExist) has been given null, but you cannot give null to this method.");
        }

        for (int index = 0; index < checkChar.length(); index++) {
            if (checkAdjustChar(checkChar.charAt(index))) {
                return true;
            }
        }
        return false;
    }

    /**
     * Adjusts the name of the given string so that the first letter of the string is capitalized.
     * 
     * @param originalString
     *            Input string, given as a non-null string. It is allowed to give a zero-length string.
     * @return Adjusted string.
     */
    public static final String toUpperCaseTitle(final String originalString) {
        if (originalString == null) {
            throw new IllegalArgumentException(
                    "The routine to convert the first character of a string to uppercase was given null.");
        }
        if (originalString.length() == 0) {
            // For a zero-length string, this is allowed. Returns as is.
            return originalString;
        }

        final char[] buf = originalString.toCharArray();
        if (buf[0] != Character.toUpperCase(buf[0])) {
            // Since the first letter is not capitalized, converts the first letter to uppercase.
            buf[0] = Character.toUpperCase(buf[0]);
            // Returns the adjusted string.
            return new String(buf);
        } else {
            // Since there is no need to adjust it, returns the input string as it is.
            return originalString;
        }
    }

    /**
     * Adjusts the name so that the first character of the given string is lowercase.
     * 
     * 
     * @param originalString
     *            Input string, given as a non-null string. It is allowed to give a zero-length string.
     * @return Adjusted string.
     */
    public static final String toLowerCaseTitle(final String originalString) {
        if (originalString == null) {
            throw new IllegalArgumentException(
                    "The routine to convert the first character of a string to lowercase was given null.");
        }
        if (originalString.length() == 0) {
            // For a zero-length string, this is allowed. Returns as is.
            return originalString;
        }

        final char[] buf = originalString.toCharArray();
        if (buf[0] != Character.toLowerCase(buf[0])) {
            // Since the first character is not in lowercase, converts the first character to lowercase.
            buf[0] = Character.toLowerCase(buf[0]);
            // Returns the adjusted string.
            return new String(buf);
        } else {
            // Since there is no need to adjust it, returns the input string as it is.
            return originalString;
        }
    }

    /**
     * If the given character is all uppercase, it will convert all but the first letter to lowercase.
     * 
     * Works differently depending on whether it is all uppercase or mixed case.<br>
     * This method is supposed to be called from within the blanco Framework.
     * 
     * @param originalString
     *            Input string.
     * @return Adjusted string.
     */
    public static final String weakenUpperCase(final String originalString) {
        if (originalString == null) {
            throw new IllegalArgumentException(
                    "A null value was given to the routine that converts all but the first letter to lowercase when the string is all uppercase.");
        }

        if (originalString.equals(originalString.toUpperCase())) {
            // The given string is all uppercase.
            // Converts only the first letter to uppercase and the rest to lowercase.
            return toUpperCaseTitle(originalString.toLowerCase());
        } else {
            // Since there is no need to adjust it, returns the input string as it is.
            return originalString;
        }
    }

    /**
     * Splits the given string into multiple strings with respect to the characters to be adjusted in the blanco Framework.
     * 
     * If it is all uppercase, it internally includes a process to convert all but the first letter to lowercase.<br>
     * Please use with caution that the array may contain strings of zero length as a result of string splitting.
     * 
     * @param originalString
     *            Input string.
     * @return An array of strings divided by adjustment characters.
     */
    public static final String[] splitByAdjustChar(final String originalString) {
        if (originalString == null) {
            throw new IllegalArgumentException(
                    "The method that splits the string based on the adjustment string (BlancoNameAdjuster.splitByAdjustChar) has been given null. It is not possible to give null to this method.");
        }

        final List<java.lang.String> result = new ArrayList<java.lang.String>();
        final char[] bufRead = originalString.toCharArray();
        final CharArrayWriter writerWork = new CharArrayWriter();
        for (int index = 0; index < bufRead.length; index++) {
            if (checkAdjustChar(bufRead[index])) {
                // A character to be adjusted has appeared. Performs the splitting process.
                writerWork.flush();
                result.add(weakenUpperCase(writerWork.toString()));
                writerWork.reset();
            } else {
                // This ia a non-adjustment character. Stores it.
                writerWork.write(bufRead[index]);
            }
        }
        writerWork.flush();
        result.add(weakenUpperCase(writerWork.toString()));
        final String[] ret = new String[result.size()];
        return (String[]) result.toArray(ret);
    }

    /**
     * Adjusts the given string into a valid class name according to the blanco Framework name transformation rules.
     * 
     * This method is a commonly used method from within the blanco Framework. It is often used in situations where you need to transform the name into a class name.
     * 
     * @param originalString
     *            Input string.
     * @return The string after being adjusted as a class name.
     */
    public static final String toClassName(final String originalString) {
        if (originalString == null) {
            throw new IllegalArgumentException(
                    "The method (BlancoNameAdjuster.toClassName) that transforms the name into a class name was given null. You cannot give null to this method.");
        }

        final StringWriter result = new StringWriter();
        // Splits strings with adjustment characters.
        // If the characters separated by the adjustment character are only uppercase, all but the first letter will be converted to lowercase.
        final String[] work = splitByAdjustChar(originalString);
        for (int index = 0; index < work.length; index++) {
            if (work[index].length() == 0) {
                // Skips if the length is zero.
                continue;
            }
            // Transforms the first letter into uppercase for the string after it is splitted by the adjustment character.
            result.write(toUpperCaseTitle(work[index]));
        }
        try {
            result.close();
        } catch (IOException e) {
            e.printStackTrace();
            throw new IllegalArgumentException(
                    "An exception that should not have been raised was raised in the routine that adjusts the string to the class name: " + e.toString());
        }
        return result.toString();
    }

    /**
     * Adjusts the given string into a valid parameter name according to the blanco Framework's name adjustment rules.
     * 
     * Internally, calls toClassName and transforms the first letter to lowercase.
     * 
     * @param originalString
     *            Input string.
     * @return The string after being adjusted as a parameter name.
     */
    public static final String toParameterName(final String originalString) {
        if (originalString == null) {
            throw new IllegalArgumentException(
                    "The method (BlancoNameAdjuster.toParameterName) that transforms the name into a parameter name was given null. It is not possible to give null to this method.");
        }

        // After transforming the name to a class name, transforms the first string to lowercase.
        return toLowerCaseTitle(toClassName(originalString));
    }
}
