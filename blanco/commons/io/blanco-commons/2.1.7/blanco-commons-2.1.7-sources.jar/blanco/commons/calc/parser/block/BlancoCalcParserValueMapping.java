/*
 * blanco Framework
 * Copyright (C) 2004-2009 IGA Tosiki
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 */
/*******************************************************************************
 * Copyright (c) 2009 IGA Tosiki, NTT DATA BUSINESS BRAINS Corp.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    IGA Tosiki (NTT DATA BUSINESS BRAINS Corp.) - initial API and implementation
 *******************************************************************************/
package blanco.commons.calc.parser.block;

/**
 * Maps the value for display to the actual value.
 * 
 * @author IGA Tosiki
 */
public class BlancoCalcParserValueMapping {
    private String[] source = null;

    private String target = null;

    public BlancoCalcParserValueMapping(final String[] source,
            final String target) {
        this.source = source;
        this.target = target;
    }

    public void setSource(final String[] args) {
        source = args;
    }

    public String[] getSource() {
        return source;
    }

    public String getTarget() {
        return target;
    }

    /**
     * Performs string mapping. If the mapping fails, returns null.
     * 
     * @param value
     *            Input value.
     * @return If the mapping successed, the converted value will be returned. If not, the input value is returned as is.
     */
    private String mapping(final String value) {
        if (source == null) {
            return null;
        }

        final int sourceLength = source.length;
        for (int index = 0; index < sourceLength; index++) {
            if (source[index].equals(value)) {
                return target;
            }
        }
        return null;
    }

    /**
     * Performs value mapping. If the mapping fails, returns input value as is.
     * 
     * @param value
     *            The input value for which you want to perform mapping matching.
     * @param mappings
     *            Mapping table.
     * @return The value after mapping. If no mapping was done, the input value as is.
     */
    public static final String mapping(final String value,
            final BlancoCalcParserValueMapping[] mappings) {
        if (mappings == null) {
            return value;
        }

        final int mappingCount = mappings.length;
        for (int index = 0; index < mappingCount; index++) {
            String result = mappings[index].mapping(value);
            if (result != null) {
                return result;
            }
        }
        return value;
    }
}
