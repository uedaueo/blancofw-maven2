/*
 * blanco Framework
 * Copyright (C) 2004-2009 IGA Tosiki
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 */
/*******************************************************************************
 * Copyright (c) 2009 IGA Tosiki, NTT DATA BUSINESS BRAINS Corp.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    IGA Tosiki (NTT DATA BUSINESS BRAINS Corp.) - initial API and implementation
 *******************************************************************************/
package blanco.commons.calc.parser.block;

/**
 * Represents an abstract block.
 * 
 * @author IGA Tosiki
 */
public abstract class AbstractBlancoCalcParserBlock {

    /**
     * Number of times to hold back in the Y direction (Counts of title lines that will be excluded).
     */
    private int waitForValueY = 1;

    /**
     * Block start strings
     */
    private String[] startString = null;

    /**
     * Block end strings
     */
    private String[] endString = null;

    /**
     * The name (ID) given to the block
     */
    private String blockName = "name";

    /**
     * Value mapping information
     */
    private BlancoCalcParserValueMapping[] valueMapping = null;

    /**
     * Gets the block name.
     * 
     * @return The block name.
     */
    public String getName() {
        return blockName;
    }

    /**
     * Sets the block name.
     * 
     * @param arg
     */
    public void setName(String arg) {
        blockName = arg;
    }

    /**
     * Sets the start strings.
     * 
     * @param arg
     *            An array of start strings.
     */
    public void setStartString(String[] arg) {
        startString = arg;
    }

    /**
     * Checks if the string matches the start string.
     * 
     * @param arg
     *            A string to be checked.
     * @return Whether or not the string matches the start string.
     */
    public boolean isStartString(String arg) {
        if (startString == null) {
            return false;
        }

        final int startStringLength = startString.length;
        for (int index = 0; index < startStringLength; index++) {
            if (startString[index].equals(arg)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Sets the end strings.
     * 
     * @deprecated Checking the end string is not recommended.
     * @param arg
     *            An array of end strings.
     */
    public void setEndString(String[] arg) {
        endString = arg;
    }

    /**
     * Checks if the string matches the end string.
     * 
     * @deprecated Checking the end string is not recommended.
     * @param arg
     *            A string to be checked.
     * @return Whether or not the string matches the end string.
     */
    public boolean isEndString(String arg) {
        if (endString == null) {
            return false;
        }

        final int endStringLength = endString.length;
        for (int index = 0; index < endStringLength; index++) {
            if (endString[index].equals(arg)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Specifies the search range in the Y direction.
     * 
     * @param arg
     *            Search range in Y direction.
     */
    public void setSearchRangeY(int arg) {
        waitForValueY = arg;
    }

    /**
     * Gets the search range in the Y direction.
     * 
     * @return The search range in the Y direction.
     */
    public int getSearchRangeY() {
        return waitForValueY;
    }

    /**
     * Specifies the read mapping of the value.
     * 
     * @param mapping
     *            The read mapping of the value.
     */
    public void setValueMapping(BlancoCalcParserValueMapping[] mapping) {
        valueMapping = mapping;
    }

    /**
     * Gets the read mapping of the value.
     * 
     * @return The read mapping of the value.
     */
    public BlancoCalcParserValueMapping[] getValueMapping() {
        return valueMapping;
    }
}
