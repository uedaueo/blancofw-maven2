/*
 * blanco Framework
 * Copyright (C) 2004-2009 IGA Tosiki
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 */
/*******************************************************************************
 * Copyright (c) 2009 IGA Tosiki, NTT DATA BUSINESS BRAINS Corp.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    IGA Tosiki (NTT DATA BUSINESS BRAINS Corp.) - initial API and implementation
 *******************************************************************************/
package blanco.commons.calc.parser;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.sax.SAXResult;
import javax.xml.transform.sax.SAXSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.*;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.AttributesImpl;

import blanco.commons.calc.BlancoCalcUtil;
import blanco.commons.calc.parser.block.AbstractBlancoCalcParserBlock;
import blanco.commons.calc.parser.block.BlancoCalcParserPropertyBlock;
import blanco.commons.calc.parser.block.BlancoCalcParserPropertyKey;
import blanco.commons.calc.parser.block.BlancoCalcParserTableBlock;
import blanco.commons.calc.parser.block.BlancoCalcParserTableColumn;
import blanco.commons.calc.parser.block.BlancoCalcParserValueMapping;
import blanco.commons.calc.parser.concretesax.BlancoCalcParserDefHandler;

/**
 * This is a SAX2 parser for reading Calc.<br>
 * Enables the association of the start string with the entity name, etc.
 *
 * @author IGA Tosiki
 */
public class BlancoCalcParser extends AbstractBlancoCalcParser {
    /**
     * Whether the system is running in debug mode or not.
     */
    private static final boolean IS_DEBUG = false;

    /**
     *  A block that is held internally.
     */
    private List<AbstractBlancoCalcParserBlock> listBlock = new ArrayList<AbstractBlancoCalcParserBlock>();

    /**
     * Current block.
     */
    private AbstractBlancoCalcParserBlock currentBlock = null;

    /**
     * Current item during keymap.
     */
    private BlancoCalcParserPropertyKey currentKeyMapItem = null;

    private int waitForValueX = -1;

    private int waitForValueY = -1;

    private int waitForIteratorTitleSearchY = -1;

    private boolean isNoCellExistOnRow = true;

    private boolean isFirstIteratorRowItem = true;

    /**
     * It is currently the startup entry point for BlancoCalcTransformer.<br>
     * Example:
     * <code>BlancoCalcParser ./meta/BlancoCalcParserDef.xml ./meta/blancoCsvTemplate.xls ./output.xml</code>
     *
     * @param args
     *            0th:configuration file 1st:input file 2nd:output xml file
     */
    public static final void main(final String[] args) {
        if (args.length < 3) {
            System.out.println("usage: BlancoCalcParser Configuration-file Input-file Output-file");
            return;
        }

        InputStream inStreamDef = null;
        InputStream inStream = null;
        OutputStream outStream = null;
        try {
            inStreamDef = new FileInputStream(args[0]);
            inStream = new BufferedInputStream(new FileInputStream(new File(
                    args[1])));
            outStream = new BufferedOutputStream(new FileOutputStream(new File(
                    args[2])));
            new BlancoCalcParser().process(inStreamDef, inStream, outStream);
            outStream.flush();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (TransformerException e) {
            e.printStackTrace();
        } finally {
            if (inStreamDef != null) {
                try {
                    inStreamDef.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (inStream != null) {
                try {
                    inStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (outStream != null) {
                try {
                    outStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

    }

    /**
     * A constructor of BlancoCalcParser.
     */
    public BlancoCalcParser() {
    }

    /**
     * Converts the Excel file to XML based on the configuration information.
     *
     * @param inStreamDef
     *            Configuration information.
     * @param inStreamCalc
     *            Excel input stream.
     * @param outStreamXml
     *            XML output stream.
     * @throws TransformerException
     */
    public void process(final InputStream inStreamDef,
            final InputStream inStreamCalc, final OutputStream outStreamXml)
            throws TransformerException {
        final BlancoCalcParser parser = new BlancoCalcParser();
        parser.readDef(inStreamDef);

        final SAXSource source = new SAXSource(parser, new InputSource(
                inStreamCalc));

        final TransformerFactory tf = TransformerFactory.newInstance();
        Transformer transformer = tf.newTransformer();
        transformer.transform(source, new StreamResult(outStreamXml));
    }

    /**
     * Loads the specified definition file.
     *
     * @param inStreamDef
     *            Input stream, This stream is not closed internally.
     * @throws TransformerException
     */
    public void readDef(final InputStream inStreamDef)
            throws TransformerException {
        SAXResult result = new SAXResult(new BlancoCalcParserDefHandler() {

            /**
             * An abstract class of the block.
             */
            private AbstractBlancoCalcParserBlock blockHeader = null;

            /**
             * Stores a start string.
             */
            private List<java.lang.String> startStringList = new ArrayList<java.lang.String>();

            /**
             * PropertyKey related.
             */
            private BlancoCalcParserPropertyKey propKey = null;

            /**
             * To create an array of Value.
             */
            private List<java.lang.String> valueList = new ArrayList<java.lang.String>();

            /**
             * ValuMapping related.
             */
            private List<BlancoCalcParserValueMapping> valueMappingList = new ArrayList<BlancoCalcParserValueMapping>();

            private List<java.lang.String> sourceList = new ArrayList<java.lang.String>();

            private String result = null;

            /**
             * TableColumn related.
             */
            private BlancoCalcParserTableColumn tableColumn = null;

            public void startDocument() throws SAXException {
            }

            public void endDocument() throws SAXException {
            }

            public void startElementBlanco(String uri, String localName,
                    String qName, String attrVersion) throws SAXException {
                // System.out.println("start: blanco: version[" + attrVersion
                // + "]");
            }

            public void endElementBlanco(String uri, String localName,
                    String qName) throws SAXException {
            }

            public void charactersBlanco(char[] ch, int start, int length)
                    throws SAXException {
            }

            public void ignorableWhitespaceBlanco(char[] ch, int start,
                    int length) throws SAXException {
            }

            public void startElementTarget(String uri, String localName,
                    String qName, String attrName) throws SAXException {
            }

            public void endElementTarget(String uri, String localName,
                    String qName) throws SAXException {
            }

            public void charactersTarget(char[] ch, int start, int length)
                    throws SAXException {
            }

            public void ignorableWhitespaceTarget(char[] ch, int start,
                    int length) throws SAXException {
            }

            public void startElementBlancocalcparser(String uri,
                    String localName, String qName, String attrName)
                    throws SAXException {
            }

            public void endElementBlancocalcparser(String uri,
                    String localName, String qName) throws SAXException {
            }

            public void charactersBlancocalcparser(char[] ch, int start,
                    int length) throws SAXException {
            }

            public void ignorableWhitespaceBlancocalcparser(char[] ch,
                    int start, int length) throws SAXException {
            }

            public void startElementPropertyblock(String uri, String localName,
                    String qName, String attrName, String attrWaitY)
                    throws SAXException {
                // Creates a new block.
                blockHeader = new BlancoCalcParserPropertyBlock(attrName);
                blockHeader.setSearchRangeY(Integer.parseInt(attrWaitY));

                add(blockHeader);
            }

            public void endElementPropertyblock(String uri, String localName,
                    String qName) throws SAXException {
                final String[] startString = new String[startStringList.size()];
                startStringList.toArray(startString);
                startStringList.clear();

                final BlancoCalcParserValueMapping valuemappings[] = new BlancoCalcParserValueMapping[valueMappingList
                        .size()];
                valueMappingList.toArray(valuemappings);
                valueMappingList.clear();

                // End of the block.
                blockHeader.setStartString(startString);
                blockHeader.setValueMapping(valuemappings);
            }

            public void charactersPropertyblock(char[] ch, int start, int length)
                    throws SAXException {
            }

            public void ignorableWhitespacePropertyblock(char[] ch, int start,
                    int length) throws SAXException {
            }

            public void startElementStartstring(String uri, String localName,
                    String qName) throws SAXException {
            }

            public void endElementStartstring(String uri, String localName,
                    String qName) throws SAXException {
            }

            public void charactersStartstring(char[] ch, int start, int length)
                    throws SAXException {
                startStringList.add(new String(ch, start, length));
            }

            public void ignorableWhitespaceStartstring(char[] ch, int start,
                    int length) throws SAXException {
            }

            public void startElementPropertykey(String uri, String localName,
                    String qName, String attrName, String attrWaitX)
                    throws SAXException {
                propKey = new BlancoCalcParserPropertyKey(attrName);
                propKey.setSearchRangeX(Integer.parseInt(attrWaitX));

                ((BlancoCalcParserPropertyBlock) blockHeader).add(propKey);
            }

            public void endElementPropertykey(String uri, String localName,
                    String qName) throws SAXException {
                final String[] values = new String[valueList.size()];
                valueList.toArray(values);
                valueList.clear();
                propKey.setKeyString(values);
            }

            public void charactersPropertykey(char[] ch, int start, int length)
                    throws SAXException {
            }

            public void ignorableWhitespacePropertykey(char[] ch, int start,
                    int length) throws SAXException {
            }

            public void startElementValue(String uri, String localName,
                    String qName) throws SAXException {
            }

            public void endElementValue(String uri, String localName,
                    String qName) throws SAXException {
            }

            public void charactersValue(char[] ch, int start, int length)
                    throws SAXException {
                valueList.add(new String(ch, start, length));
            }

            public void ignorableWhitespaceValue(char[] ch, int start,
                    int length) throws SAXException {
            }

            public void startElementValuemapping(String uri, String localName,
                    String qName) throws SAXException {
            }

            public void endElementValuemapping(String uri, String localName,
                    String qName) throws SAXException {
                final String[] sources = new String[sourceList.size()];
                sourceList.toArray(sources);
                sourceList.clear();

                valueMappingList.add(new BlancoCalcParserValueMapping(sources,
                        result));
                result = null;
            }

            public void charactersValuemapping(char[] ch, int start, int length)
                    throws SAXException {
            }

            public void ignorableWhitespaceValuemapping(char[] ch, int start,
                    int length) throws SAXException {
            }

            public void startElementResult(String uri, String localName,
                    String qName) throws SAXException {
            }

            public void endElementResult(String uri, String localName,
                    String qName) throws SAXException {
            }

            public void charactersResult(char[] ch, int start, int length)
                    throws SAXException {
                result = new String(ch, start, length);
            }

            public void ignorableWhitespaceResult(char[] ch, int start,
                    int length) throws SAXException {
            }

            public void startElementSource(String uri, String localName,
                    String qName) throws SAXException {
            }

            public void endElementSource(String uri, String localName,
                    String qName) throws SAXException {
            }

            public void charactersSource(char[] ch, int start, int length)
                    throws SAXException {
                sourceList.add(new String(ch, start, length));
            }

            public void ignorableWhitespaceSource(char[] ch, int start,
                    int length) throws SAXException {
            }

            public void startElementTableblock(String uri, String localName,
                    String qName, String attrName, String attrWaitY,
                    String attrTitleheight, String attrRowname)
                    throws SAXException {

                // Creates a new block.
                blockHeader = new BlancoCalcParserTableBlock(attrName);
                blockHeader.setSearchRangeY(Integer.parseInt(attrWaitY));
                ((BlancoCalcParserTableBlock) blockHeader)
                        .setSearchRangeForTitleY(Integer
                                .parseInt(attrTitleheight));
                ((BlancoCalcParserTableBlock) blockHeader)
                        .setRowName(attrRowname);
                add(blockHeader);
            }

            public void endElementTableblock(String uri, String localName,
                    String qName) throws SAXException {
                final String[] startString = new String[startStringList.size()];
                startStringList.toArray(startString);
                startStringList.clear();

                final BlancoCalcParserValueMapping valuemappings[] = new BlancoCalcParserValueMapping[valueMappingList
                        .size()];
                valueMappingList.toArray(valuemappings);
                valueMappingList.clear();

                // End of the block.
                blockHeader.setStartString(startString);
                blockHeader.setValueMapping(valuemappings);
            }

            public void charactersTableblock(char[] ch, int start, int length)
                    throws SAXException {
            }

            public void ignorableWhitespaceTableblock(char[] ch, int start,
                    int length) throws SAXException {
            }

            public void startElementTablecolumn(String uri, String localName,
                    String qName, String attrName) throws SAXException {
                tableColumn = new BlancoCalcParserTableColumn(attrName);
            }

            public void endElementTablecolumn(String uri, String localName,
                    String qName) throws SAXException {
                final String[] values = new String[valueList.size()];
                valueList.toArray(values);
                valueList.clear();
                tableColumn.setColumnString(values);

                ((BlancoCalcParserTableBlock) blockHeader).add(tableColumn);
            }

            public void charactersTablecolumn(char[] ch, int start, int length)
                    throws SAXException {
            }

            public void ignorableWhitespaceTablecolumn(char[] ch, int start,
                    int length) throws SAXException {
            }
        });

        final TransformerFactory tf = TransformerFactory.newInstance();
        Transformer transformer = tf.newTransformer();
        transformer.transform(new StreamSource(inStreamDef), result);
    }

    /**
     * Adds a block.
     *
     * @param block
     *            The block object to be added.
     */
    public void add(final AbstractBlancoCalcParserBlock block) {
        listBlock.add(block);
    }

    protected void startSheet(String sheetName) throws SAXException {
        if (IS_DEBUG)
            System.out.println("Processes the sheet [" + sheetName + "]...");
    }

    protected void endSheet(Sheet sheet) throws SAXException {
        if (currentBlock != null) {
            getContentHandler().endElement("", currentBlock.getName(),
                    currentBlock.getName());
            currentBlock = null;
        }

        waitForValueX = -1;
        waitForValueY = -1;
        waitForIteratorTitleSearchY = -1;
        currentKeyMapItem = null;
    }

    protected void startRow(int row) throws SAXException {
        isNoCellExistOnRow = true;
        isFirstIteratorRowItem = true;
    }

    protected void endRow(int row) throws SAXException {
        waitForValueX = -1;

        if (waitForIteratorTitleSearchY >= 0) {
            // In the case of a title row search, enters here.
            // Whatever the state, the countdown will be performed.
            waitForIteratorTitleSearchY--;
        }

        if (currentBlock instanceof BlancoCalcParserTableBlock) {
            if (isFirstIteratorRowItem == false) {
                final BlancoCalcParserTableBlock blockLook = (BlancoCalcParserTableBlock) currentBlock;
                if (blockLook.getRowName() != null
                        && blockLook.getRowName().length() > 0) {
                    // Adds entities to repeating items in a block.
                    getContentHandler().endElement("", blockLook.getRowName(),
                            blockLook.getRowName());
                }
            }
        }

        if (isNoCellExistOnRow) {
            if (waitForValueY >= 0) {
                waitForValueY--;
            }
            if (waitForValueY <= 0) {
                if (currentBlock != null) {
                    if (IS_DEBUG)
                        System.out.println("Ends the block [" + currentBlock.getName()
                                + "].");
                    getContentHandler().endElement("", currentBlock.getName(),
                            currentBlock.getName());

                    currentBlock = null;
                }
            }
        }

        if (currentBlock == null) {
            return;
        }

        if (currentBlock instanceof BlancoCalcParserPropertyBlock) {
            currentKeyMapItem = null;
        }
    }

    protected void startColumn(int column) throws SAXException {
    }

    protected void endColumn(int column) throws SAXException {
        if (waitForValueX >= 0) {
            waitForValueX--;
        }

        if (currentBlock == null) {
            return;
        }

        if (waitForValueX < 0) {
            if (currentBlock instanceof BlancoCalcParserPropertyBlock) {
                currentKeyMapItem = null;
            }
        }
    }

    /**
     * Called when a cell is parsed.
     *
     * @param column
     *            Called with 1 origin here.
     * @param row
     *            Called with 1 origin here.
     * @param cellValue
     *            Cell value.
     * @throws SAXException
     *             If a SAX exception occurs.
     */
    @SuppressWarnings("deprecation")
    protected void fireCell(final int column, final int row,
            final String cellValue) throws SAXException {

        if (cellValue.length() == 0) {
            return;
        }

        // At least we found the entity.
        isNoCellExistOnRow = false;

        if (currentBlock != null) {
            if (currentBlock.isEndString(cellValue)) {
                // Now that we've found the "work", starts analyzing the working block.
                if (IS_DEBUG)
                    System.out.println("Found the forced termination string (" + cellValue + ") of block [" + currentBlock.getName()
                            + "].");

                getContentHandler().endElement("", currentBlock.getName(),
                        currentBlock.getName());

                // Discards the current block.
                currentBlock = null;

            }
        }

        if (currentBlock != null) {
            if (currentBlock instanceof BlancoCalcParserPropertyBlock) {
                if (currentKeyMapItem != null) {
                    final String value = BlancoCalcParserValueMapping.mapping(
                            cellValue, currentBlock.getValueMapping());
                    if (IS_DEBUG)
                        System.out.println("Key [" + currentKeyMapItem.getName()
                                + "] = Value [" + value + "]");
                    // Some kind of memory processing here.
                    saveNode(currentKeyMapItem.getName(), value);
                    return;
                }
            } else if (currentBlock instanceof BlancoCalcParserTableBlock) {
                if (waitForIteratorTitleSearchY <= 0) {
                    final BlancoCalcParserTableBlock blockLook = (BlancoCalcParserTableBlock) currentBlock;
                    final BlancoCalcParserTableColumn item = blockLook
                            .findByColumnPosition(column);
                    if (item == null) {
                        if (IS_DEBUG)
                            System.out
                                    .println("The corresponding column (" + column + ") cannot be found.");
                        return;
                    }

                    if (isFirstIteratorRowItem) {
                        isFirstIteratorRowItem = false;
                        if (blockLook.getRowName() != null
                                && blockLook.getRowName().length() > 0) {
                            // Adds entities to repeating items in a block.
                            getContentHandler().startElement("",
                                    blockLook.getRowName(),
                                    blockLook.getRowName(),
                                    new AttributesImpl());
                        }
                    }

                    // Some kind of memory processing here.
                    final String value = BlancoCalcParserValueMapping.mapping(
                            cellValue, blockLook.getValueMapping());
                    if (IS_DEBUG)
                        System.out.println("Column [" + item.getName() + "] = Value ["
                                + value + "]");
                    saveNode(item.getName(), value);
                    return;
                }
            }
        }

        if (IS_DEBUG)
            System.out.println("  (" + BlancoCalcUtil.columnToLabel(column)
                    + row + ")" + cellValue);

        for (int index = 0; index < listBlock.size(); index++) {
            AbstractBlancoCalcParserBlock blockItem = (AbstractBlancoCalcParserBlock) listBlock
                    .get(index);
            if (blockItem.isStartString(cellValue)) {
                // Now that we've found the "work", starts analyzing the working block.
                if (IS_DEBUG)
                    System.out.println("Found the block [" + blockItem.getName() + "].");

                final AttributesImpl attrImpl = new AttributesImpl();
                getContentHandler().startElement("", blockItem.getName(),
                        blockItem.getName(), attrImpl);

                // Stores the current block.
                currentBlock = blockItem;
                waitForValueY = currentBlock.getSearchRangeY();
                if (currentBlock instanceof BlancoCalcParserTableBlock) {
                    BlancoCalcParserTableBlock block = (BlancoCalcParserTableBlock) currentBlock;
                    waitForIteratorTitleSearchY = block
                            .getSearchRangeForTitleY();
                    /*
                     * Clears all saved column posions.
                     * Otherwise, first sheet column postions are used if multi sheets exists in a book.
                     */
                    block.clearPositions();
                    if (IS_DEBUG) {
                        System.out.println("Saved column posions are cleared.");
                    }
                }
            }
        }

        if (currentBlock == null) {
            return;
        }

        if (currentBlock instanceof BlancoCalcParserPropertyBlock) {
            // Performs the process of searching for the key.
            final BlancoCalcParserPropertyKey item = ((BlancoCalcParserPropertyBlock) currentBlock)
                    .findByStartString(cellValue);
            if (item != null) {
                currentKeyMapItem = item;
                waitForValueX = item.getSearchRangeX();
            }
        } else if (currentBlock instanceof BlancoCalcParserTableBlock) {
            final BlancoCalcParserTableBlock block = (BlancoCalcParserTableBlock) currentBlock;

            // Performs the process of searching for the title.
            final BlancoCalcParserTableColumn item = (block)
                    .findByTitleString(cellValue);
            if (item != null) {
                // Successfully searched for title position.
                if (IS_DEBUG)
                    System.out.println("Column (" + column + ") is a key [" + cellValue
                            + "].");
                item.setColumnPosition(column);
            } else {
                if (IS_DEBUG)
                    System.out.println("The key [" + cellValue
                            + "] of column (" + column + ") is not found among the registered ones.");
            }
        }
    }

    /**
     * Performs parsing.
     *
     * @param inputSource
     *            Input source to be parsed.
     * @see org.xml.sax.XMLReader#parse(org.xml.sax.InputSource)
     */
    public final void parse(final InputSource inputSource) throws IOException,
            SAXException {

//        System.out.println("AbstractBlancoCalcParser#:parse for " + inputSource.getPublicId());

        Workbook workbook = null;

        InputStream inStream = null;
        try {
            if (inputSource.getByteStream() != null) {
                // OK. We will continue with the process.
            } else if (inputSource.getSystemId() != null
                    && inputSource.getSystemId().length() > 0) {
                inStream = new FileInputStream(inputSource.getSystemId());
                inputSource.setByteStream(inStream);
            } else {
                throw new IOException("The specified InputSource cannot be processed.");
            }
            workbook = WorkbookFactory.create(inputSource.getByteStream());

            // This is where the actual parsing begins.
            parseWorkbook(workbook);
        } catch (IOException e) {
            e.printStackTrace();
            throw new IOException("An unexpected exception has occurred: " + e.toString());
//        } catch (InvalidFormatException e) {
//            e.printStackTrace();
//            throw new IOException("An unexpected exception has occurred: " + e.toString());
        } finally {
            if (workbook != null) {
                workbook.close();
            }

            // The InputSource is closed externally.
            // Only explicitly opened streams will be processed here.
            if (inStream != null) {
                inStream.close();
            }
        }
    }

    /**
     * Parses a sheet.
     *
     * @param sheet
     *            A sheet object.
     * @throws SAXException
     *             If a SAX exception occurs.
     */
    protected final void parseSheet(final Sheet sheet) throws SAXException {
        // Sheet elements are handled by the upper class.
        AttributesImpl attrImpl = new AttributesImpl();
        attrImpl.addAttribute("", "name", "name", "CDATA", sheet.getSheetName());
        getContentHandler().startElement("",
                (String) getProperty(URI_PROPERTY_NAME_SHEET),
                (String) getProperty(URI_PROPERTY_NAME_SHEET), attrImpl);

        startSheet(sheet.getSheetName());

        // getLastRowNum() counts from 0, so it should be +1.
        int maxRows = sheet.getLastRowNum() + 1;

        for (int row = 0; row < maxRows; row++) {
            startRow(row + 1);
            Row line = sheet.getRow(row);
            if (line != null) {
                for (int column = 0; column < line.getLastCellNum(); column++) {

                    startColumn(column + 1);
//                    System.out.println("### ROW = " + row + ", COL = " + column);
                    Cell cell = line.getCell(column);
                    // The content will be delivered without trim().
                    /*
                     * apache poi 4.1.2 (xmlbeans 3.1.0) Coping
                     * If a cell contains a formula, it may fail to evaluate and throw a javax.xml.transform.TransformerException.
                     *
                     * Rewriting the formula may help, so notifies here of the problem whenever possible.
                     * by tueda, 2020/10/06
                     */
                    String value = "";
                    try {
                        value = getCellValue(cell);
                    } catch (RuntimeException ex) {
                        System.err.println("BlancoCalcParser:  RuntimeException occurs @(" + (row + 1) +", " + (column + 1) + ") of sheet " + sheet.getSheetName());
                        ex.printStackTrace();
                        // Gives up on continuing the process.
                        throw ex;
                    }
                    fireCell(column + 1, row + 1, value);
                    endColumn(column + 1);
                }
            }
            endRow(row + 1);
        }

        endSheet(sheet);

        // Sheet elements are handled by the upper class.
        getContentHandler().endElement("",
                (String) getProperty(URI_PROPERTY_NAME_SHEET),
                (String) getProperty(URI_PROPERTY_NAME_SHEET));
    }

}
