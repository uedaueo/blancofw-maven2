/*
 * blanco Framework
 * Copyright (C) 2004-2009 IGA Tosiki
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 */
/*******************************************************************************
 * Copyright (c) 2009 IGA Tosiki, NTT DATA BUSINESS BRAINS Corp.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    IGA Tosiki (NTT DATA BUSINESS BRAINS Corp.) - initial API and implementation
 *******************************************************************************/
package blanco.commons.calc.parser;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerFactoryConfigurationError;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.*;
import org.xml.sax.ContentHandler;
import org.xml.sax.DTDHandler;
import org.xml.sax.EntityResolver;
import org.xml.sax.ErrorHandler;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.SAXNotRecognizedException;
import org.xml.sax.SAXNotSupportedException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.AttributesImpl;

import blanco.commons.parser.ContentHandlerStream;

/**
 * This is a SAX2 parser for reading Calc.<br>
 * Provides a generic and abstract SAX2 handler for reading spreadsheet files.
 *
 * @author IGA Tosiki
 */
public abstract class AbstractBlancoCalcParser implements XMLReader {
    /**
     * Stores the content handler.
     */
    private ContentHandler contentHandler = null;

    private ContentHandlerStream chainedContentHandler = null;

    public static final String URI_PROPERTY_NAME_WORKBOOK = "http://blanco/commons/calc/parser/workbook";

    public static final String URI_PROPERTY_NAME_SHEET = "http://blanco/commons/calc/parser/sheet";

    private String _propertyNameWorkbook = "workbook";

    private String _propertyNameSheet = "sheet";

    /**
     * Gets the feature.
     *
     * @param arg0
     *            The feature.
     * @see org.xml.sax.XMLReader#getFeature(java.lang.String)
     */
    public final boolean getFeature(final String arg0)
            throws SAXNotRecognizedException, SAXNotSupportedException {
        return false;
    }

    /**
     * Sets the feature.
     *
     * @param name
     *            Feature name.
     * @param value
     *            Feature value.
     * @see org.xml.sax.XMLReader#setFeature(java.lang.String, boolean)
     */
    public final void setFeature(final String name, boolean value)
            throws SAXNotRecognizedException, SAXNotSupportedException {
    }

    /**
     * Gets the property.
     */
    public final Object getProperty(final String name)
            throws SAXNotRecognizedException, SAXNotSupportedException {

        if (name.equals(URI_PROPERTY_NAME_WORKBOOK)) {
            return _propertyNameWorkbook;
        } else if (name.equals(URI_PROPERTY_NAME_SHEET)) {
            return _propertyNameSheet;
        } else {
            throw new SAXNotRecognizedException("This name cannot be handled." + name);
        }
    }

    /**
     * Sets the property.
     */
    public final void setProperty(final String name, final Object value)
            throws SAXNotRecognizedException, SAXNotSupportedException {
        if (name.equals(URI_PROPERTY_NAME_WORKBOOK)) {
            _propertyNameWorkbook = (String) value;
        } else if (name.equals(URI_PROPERTY_NAME_SHEET)) {
            _propertyNameSheet = (String) value;
        } else {
            throw new SAXNotRecognizedException("This name cannot be handled." + name);
        }
    }

    /**
     * Sets the entity resolver.
     *
     * @param arg0
     *            An object of entity resolver.
     * @see org.xml.sax.XMLReader#setEntityResolver(org.xml.sax.EntityResolver)
     */
    public final void setEntityResolver(final EntityResolver arg0) {
    }

    /**
     * Gets the entity resolver.
     *
     * @return An object of entity resolver.
     * @see org.xml.sax.XMLReader#getEntityResolver()
     */
    public final EntityResolver getEntityResolver() {
        return null;
    }

    /**
     * Sets the DTD handler.
     *
     * @param arg0
     *            An object of DTD handler.
     * @see org.xml.sax.XMLReader#setDTDHandler(org.xml.sax.DTDHandler)
     */
    public final void setDTDHandler(final DTDHandler arg0) {
    }

    /**
     * Gets the DTD handler.
     *
     * @return An object of DTD handler.
     * @see org.xml.sax.XMLReader#getDTDHandler()
     */
    public final DTDHandler getDTDHandler() {
        return null;
    }

    /**
     * Sets the content handler.
     */
    public final void setContentHandler(ContentHandler arg0) {
        contentHandler = arg0;
        if (chainedContentHandler != null) {
            chainedContentHandler.setContentHandler(arg0);
        }
    }

    /**
     * Gets the content handler.
     */
    public final ContentHandler getContentHandler() {
        if (chainedContentHandler == null) {
            return contentHandler;
        } else {
            return chainedContentHandler;
        }
    }

    public final void chainContentHandlerStream(ContentHandlerStream arg0) {
        chainedContentHandler = arg0;
    }

    /**
     * Sets the error handler.
     *
     * @param arg0
     *            An object of the error handler.
     * @see org.xml.sax.XMLReader#setErrorHandler(org.xml.sax.ErrorHandler)
     */
    public final void setErrorHandler(ErrorHandler arg0) {
    }

    /**
     * Gets the error handler.
     *
     * @return An object of the error handler.
     * @see org.xml.sax.XMLReader#getErrorHandler()
     */
    public final ErrorHandler getErrorHandler() {
        return null;
    }



    /**
     * Parses the given file.
     *
     * Basically, we recommend parsing the inputSource version.
     *
     * @param arg0
     *            Path of the file.
     */
    public final void parse(final String arg0) throws IOException, SAXException {
        InputSource inputSource = new InputSource(arg0);
        inputSource.setByteStream(new FileInputStream(arg0));
        parse(inputSource);
    }

    /**
     * Parses the workbook.
     *
     * @param workbook
     *            The workbook.
     * @throws SAXException
     *             If a SAX exception occurs.
     */
    protected void parseWorkbook(final Workbook workbook) throws SAXException {
        getContentHandler().startDocument();
        getContentHandler().startElement("",
                (String) getProperty(URI_PROPERTY_NAME_WORKBOOK),
                (String) getProperty(URI_PROPERTY_NAME_WORKBOOK),
                new AttributesImpl());

        for (int indexSheet = 0; indexSheet < workbook.getNumberOfSheets(); indexSheet++) {
            Sheet sheet = workbook.getSheetAt(indexSheet);
            parseSheet(sheet);
        }
        getContentHandler().endElement("",
                (String) getProperty(URI_PROPERTY_NAME_WORKBOOK),
                (String) getProperty(URI_PROPERTY_NAME_WORKBOOK));
        getContentHandler().endDocument();
    }

    protected abstract void parseSheet(final Sheet sheet) throws SAXException;

    public static String getCellValue(Cell cell) {
        // 2016.01.20 j.amano
        // Specification in this jxl to poi.
        //------------------------
        //cell format:\-1,000
        //jxl:($1,000)←It has become $.
        //poi:-1000
        //------------------------
        //cell format:2016/1/20
        //jxl:0020, 1月 20, 2016
        //poi:2016/01/20 00:00:00
        //------------------------
        //cell format:#REF!←In case of error
        //jxl:#REF!
        //poi:#REF!
        //------------------------
        //cell format:▲1,000
        //jxl:"▲ "1,000
        //poi:-1000
        //------------------------

        if(cell != null) {
            switch (cell.getCellType()) {
                case BLANK:
                    return "";
                case STRING:
                    return cell.getRichStringCellValue().getString();
                case BOOLEAN:
                    return String.valueOf(cell.getBooleanCellValue());
                case NUMERIC:
                    // Determines date, integer, and decimal.
                    if (DateUtil.isCellDateFormatted(cell)) {
                        // Gets a value as a date type
                        Date dt =cell.getDateCellValue();
                        // Specifies the format of the converted date string.
                        DateFormat df = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
                        String sDate = df.format(dt);
                        return sDate;
                    }
                    // For integers, removes ".0".
                    DecimalFormat format = new DecimalFormat("0.#");
                    return format.format(cell.getNumericCellValue());
                case FORMULA:
                    Workbook wb = cell.getSheet().getWorkbook();
                    CreationHelper crateHelper = wb.getCreationHelper();
                    FormulaEvaluator evaluator = crateHelper.createFormulaEvaluator();
                    return getCellValue(evaluator.evaluateInCell(cell));
                case ERROR:
                    byte errorCode = cell.getErrorCellValue();
                    FormulaError error = FormulaError.forInt(errorCode);
                    String errorText = error.getString();
                    return errorText;
                default:
                    return "";
            }
        }
        return "";
    }

    /**
     * Called when the sheet is started.
     *
     * @param sheetName
     *            Sheet name.
     * @throws SAXException
     *             If a SAX exception occurs.
     */
    protected abstract void startSheet(String sheetName) throws SAXException;

    /**
     * Called when the sheet is ended.
     *
     * @param sheet
     *            A sheet object.
     * @throws SAXException
     *             If a SAX exception occurs.
     */
    protected abstract void endSheet(final Sheet sheet) throws SAXException;

    protected abstract void startRow(int row) throws SAXException;

    protected abstract void endRow(int row) throws SAXException;

    protected abstract void startColumn(int column) throws SAXException;

    protected abstract void endColumn(int column) throws SAXException;

    /**
     * Called when a cell exists.
     *
     * @param column
     * @param row
     * @param cellValue
     * @throws SAXException
     */
    protected abstract void fireCell(int column, int row, String cellValue)
            throws SAXException;

    /**
     * Gets the Transformer.
     *
     * @return A transformer object.
     * @throws TransformerFactoryConfigurationError
     *             If a transformer factory configuration exception occurs.
     * @throws TransformerConfigurationException
     *             If a transformer configuration exception occurs.
     */
    public static final Transformer getTransformer()
            throws TransformerFactoryConfigurationError,
            TransformerConfigurationException {
        TransformerFactory tf = TransformerFactory.newInstance();
        Transformer transformer = tf.newTransformer();
        transformer.setOutputProperty("encoding", "UTF-8");
        transformer.setOutputProperty("standalone", "yes");
        transformer.setOutputProperty("indent", "yes");
        return transformer;
    }

    /**
     * Saves the node.
     *
     * @param key
     *            Key.
     * @param value
     *            Value.
     * @throws SAXException
     *             If a SAX exception occurs.
     */
    protected void saveNode(final String key, final String value)
            throws SAXException {
        getContentHandler().startElement("", key, key, new AttributesImpl());

        final char[] charArray = value.toCharArray();

        getContentHandler().characters(charArray, 0, charArray.length);
        getContentHandler().endElement("", key, key);
    }
}
