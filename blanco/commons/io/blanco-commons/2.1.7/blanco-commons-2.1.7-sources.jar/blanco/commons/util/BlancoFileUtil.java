/*
 * blanco Framework
 * Copyright (C) 2004-2009 IGA Tosiki
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 */
/*******************************************************************************
 * Copyright (c) 2009 IGA Tosiki, NTT DATA BUSINESS BRAINS Corp.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    IGA Tosiki (NTT DATA BUSINESS BRAINS Corp.) - initial API and implementation
 *******************************************************************************/
package blanco.commons.util;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * This class is a collection of file-related utilities in the blanco Framework.
 * 
 * @author IGA Tosiki
 */
public class BlancoFileUtil {
    /**
     * Flag whether or not to operate in debug mode.
     */
    private static final boolean IS_DEUBG = false;

    /**
     * Copies the given input file to the output file.
     * 
     * An exception will be thrown if the input file does not exist, for example.
     * 
     * @param fileInput
     *            Input file; do not give null.
     * @param fileOutput
     *            Output file; do not give null.
     * @throws IOException
     *             If an I/O exception occurs.
     */
    public static final void copy(final File fileInput, final File fileOutput)
            throws IOException {
        if (IS_DEUBG) {
            System.out.println("BlancoFileUtil.copy("
                    + fileInput.getAbsolutePath() + ", "
                    + fileOutput.getAbsolutePath() + ")");
        }
        if (fileInput == null) {
            throw new IllegalArgumentException("Null was given for the input file.");
        }
        if (fileOutput == null) {
            throw new IllegalArgumentException("Null was given for the output file.");
        }
        if (fileInput.exists() == false) {
            throw new IllegalArgumentException("Input file ["
                    + fileInput.getAbsolutePath() + "] not found.");
        }
        if (fileInput.isFile() == false) {
            throw new IllegalArgumentException("Input file ["
                    + fileInput.getAbsolutePath() + "] cannot be given a directory.");
        }
        if (fileOutput.exists()) {
            if (fileOutput.isFile() == false) {
                throw new IllegalArgumentException("Output file ["
                        + fileInput.getAbsolutePath() + "] cannot be given a directory.");
            }
            if (fileOutput.canWrite() == false) {
                throw new IllegalArgumentException("Output file ["
                        + fileInput.getAbsolutePath()
                        + "] exists and cannot be written to.");
            }
        }

        final File fileTargetParent = fileOutput.getParentFile();
        if (fileTargetParent.exists() == false) {
            // Creates if it does not exist.
            if (fileTargetParent.mkdirs() == false) {
                throw new IllegalArgumentException("The parent folder ["
                        + fileTargetParent.getAbsolutePath()
                        + "] of the output file ["
                        + fileInput.getAbsolutePath() + "] did not exist, so we tried to create it, but failed.");
            }
        }

        InputStream inStream = null;
        OutputStream outStream = null;
        try {
            inStream = new BufferedInputStream(new FileInputStream(fileInput));
            outStream = new BufferedOutputStream(new FileOutputStream(
                    fileOutput));

            // Copies the stream.
            BlancoStreamUtil.copy(inStream, outStream);

            outStream.flush();
        } finally {
            try {
                // Closes the stream definitely if it opens.
                if (inStream != null) {
                    inStream.close();
                }
            } finally {
                // Closes the stream definitely if it opens.
                if (outStream != null) {
                    outStream.close();
                }
            }
        }
    }

    /**
     * Copies the given input stream to the output stream.
     * 
     * No flushing is performed inside this method. If necessary, flush() should be performed in the caller method.<br>
     * Internally, it calls a stream copy of another class.
     * 
     * @deprecated It is recommended to call the BlancoStreamUtil.copy method instead of this method.
     * @param inStream
     *            Input stream.
     * @param outStream
     *            Output stream.
     * @throws IOException
     *             If an I/O exception occurs.
     */
    public static final void copy(final InputStream inStream,
            final OutputStream outStream) throws IOException {
        if (inStream == null) {
            throw new IllegalArgumentException(
                    "The input stream parameter for the BlancoFileUtil.copy method was given as null, please specify a non-null value.");
        }
        if (outStream == null) {
            throw new IllegalArgumentException(
                    "The output stream parameter for the BlancoFileUtil.copy method was given as null, please specify a non-null value.");
        }

        BlancoStreamUtil.copy(inStream, outStream);
    }

    /**
     * Reads the file and expands it into a byte array.
     * 
     * @param inputFile
     *            Input file.
     * @return The contents of the file as a byte array.
     * @throws IOException
     *             If an I/O exception occurs.
     * @throws IllegalArgumentException
     *             If the file does not exist, etc.
     */
    public static final byte[] file2Bytes(final File inputFile)
            throws IOException, IllegalArgumentException {
        if (inputFile == null) {
            throw new IllegalArgumentException(
                    "The file2Bytes() method has been given null as an input parameter.");
        }
        if (inputFile.exists() == false) {
            throw new IllegalArgumentException(
                    "The file given as input parameter to the file2Bytes() method does not exist.");
        }
        if (inputFile.canRead() == false) {
            throw new IllegalArgumentException(
                    "The file given as input parameter to the file2Bytes() method cannot be read.");
        }
        if (inputFile.isDirectory()) {
            throw new IllegalArgumentException(
                    "A directory was given as an input parameter to the file2Bytes() method. Directory cannot be processed.");
        }

        final ByteArrayOutputStream outStream = new ByteArrayOutputStream();
        final InputStream inStream = new BufferedInputStream(
                new FileInputStream(inputFile), BlancoStreamUtil.BUF_SIZE);
        try {
            BlancoStreamUtil.copy(inStream, outStream);
            outStream.flush();
            return outStream.toByteArray();
        } finally {
            inStream.close();
            outStream.close();
        }
    }

    /**
     * Outputs the given byte array to the given file.
     * 
     * @param inputBytes
     *            Byte array to be used as input.
     * @param outputFile
     *            Output file.
     * @throws IOException
     *             If an I/O exception occurs.
     * @throws IllegalArgumentException
     *             If the file is given as a null, etc.
     */
    public static final void bytes2File(final byte[] inputBytes,
            final File outputFile) throws IOException, IllegalArgumentException {
        if (inputBytes == null) {
            throw new IllegalArgumentException(
                    "The bytes2File() method has been given null as the byte array for the input parameter.");
        }
        if (outputFile == null) {
            throw new IllegalArgumentException(
                    "The bytes2File() method was given null as the output file for the input parameter.");
        }
        if (outputFile.exists()) {
            if (outputFile.isDirectory()) {
                throw new IllegalArgumentException(
                        "The bytes2File() method has been given a directory as the output file for the input parameter. Directory cannot be processed.");
            }
            if (outputFile.canWrite() == false) {
                throw new IllegalArgumentException(
                        "The file given as an input parameter to the bytes2File() method exists and is not writable.");
            }
        } else {
            if (outputFile.createNewFile() == false) {
                throw new IllegalArgumentException(
                        "The output file given as an input parameter to the bytes2File() method cannot be generated.");
            }
        }

        final ByteArrayInputStream inStream = new ByteArrayInputStream(
                inputBytes);
        final OutputStream outStream = new BufferedOutputStream(
                new FileOutputStream(outputFile), BlancoStreamUtil.BUF_SIZE);
        try {
            BlancoStreamUtil.copy(inStream, outStream);
            outStream.flush();
        } finally {
            outStream.close();
            inStream.close();
        }
    }

    /**
     * Outputs the byte array to a file, if necessary.
     * 
     * @param inputBytes
     *            Input byte array.
     * @param outputFile
     *            Output file.
     * @return 0:Neither created nor updated the file. 1:Created a new file. 2:Updated the file.
     * @throws IOException
     *             If an I/O exception occurs.
     */
    public static final int bytes2FileIfNecessary(final byte[] inputBytes,
            final File outputFile) throws IOException {

        byte[] originalFileImage = null;
        if (outputFile.exists()) {
            // Gets the original file image.
            originalFileImage = file2Bytes(outputFile);
        }

        if (originalFileImage == null) {
            //Forced to write.
            bytes2File(inputBytes, outputFile);
            return 1;
        } else {
            if (BlancoByteUtil.compare(originalFileImage, inputBytes) == 0) {
                // No need to write.
                return 0;
            } else {
                // Update writing.
                bytes2File(inputBytes, outputFile);
                return 2;
            }
        }
    }

    /**
     * Gets a newline.
     * 
     * @return Newline; \n for Windows
     */
    public static final String getNewLine() {
        return System.getProperty("line.separator");
    }
}
