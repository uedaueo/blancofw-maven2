/*
 * blanco Framework
 * Copyright (C) 2004-2009 IGA Tosiki
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 */
/*******************************************************************************
 * Copyright (c) 2009 IGA Tosiki, NTT DATA BUSINESS BRAINS Corp.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    IGA Tosiki (NTT DATA BUSINESS BRAINS Corp.) - initial API and implementation
 *******************************************************************************/
package blanco.commons.calc.parser;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.*;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.AttributesImpl;

import blanco.commons.calc.BlancoCalcUtil;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

/**
 * This is a very simple SAX2 parser to try to read Calc.<br>
 * This is a sample as a very simple SAX parsing implementation.
 *
 * @author IGA Tosiki
 */
public class BlancoSimpleCalcParser extends AbstractBlancoCalcParser {

    protected void startSheet(final String sheetName) throws SAXException {
        System.out.println("Processing a sheet [" + sheetName + "]...");
        AttributesImpl attrImpl = new AttributesImpl();
        attrImpl.addAttribute("", "name", "name", "CDATA", sheetName);
        getContentHandler().startElement("", "sheet", "sheet", attrImpl);
    }

    protected void endSheet(final Sheet sheet) throws SAXException {
        getContentHandler().endElement("", "sheet", "sheet");
    }

    protected void startRow(final int row) throws SAXException {
    }

    protected void endRow(final int row) throws SAXException {
    }

    protected void startColumn(final int column) throws SAXException {
    }

    protected void endColumn(final int column) throws SAXException {
    }

    /**
     * Called when a cell is parsed.
     *
     * @param column
     *            It is called with 1 origin here.
     * @param row
     *            It is called with 1 origin here.
     * @param cellValue
     *           The value of the cell.
     * @throws SAXException
     */
    protected void fireCell(final int column, final int row,
            final String cellValue) throws SAXException {
        if (cellValue.length() == 0) {
            return;
        }

        final StringBuffer strResult = new StringBuffer(256);
        strResult.append("  (");
        strResult.append(BlancoCalcUtil.columnToLabel(column));
        strResult.append(row);
        strResult.append(")  ");
        strResult.append(cellValue);
        System.out.println(strResult.toString());

        final AttributesImpl attrImpl = new AttributesImpl();
        attrImpl.addAttribute("", "position", "position", "CDATA",
                BlancoCalcUtil.columnToLabel(column) + row);
        getContentHandler().startElement("", "cell", "cell", attrImpl);
        final char[] charArray = cellValue.toCharArray();
        getContentHandler().characters(charArray, 0, charArray.length);
        getContentHandler().endElement("", "cell", "cell");
    }

    /**
     * Performs parsing.
     *
     * @param inputSource
     *            Input source to be parsed.
     * @see org.xml.sax.XMLReader#parse(org.xml.sax.InputSource)
     */
    public final void parse(final InputSource inputSource) throws IOException,
            SAXException {

        System.out.println("AbstractBlancoCalcParser#:parse");

        Workbook workbook = null;

        InputStream inStream = null;
        try {
            if (inputSource.getByteStream() != null) {
                // OK. We will continue with the process.
            } else if (inputSource.getSystemId() != null
                    && inputSource.getSystemId().length() > 0) {
                inStream = new FileInputStream(inputSource.getSystemId());
                inputSource.setByteStream(inStream);
            } else {
                throw new IOException("The specified InputSource cannot be processed.");
            }
            workbook = WorkbookFactory.create(inputSource.getByteStream());

            // This is where the real parsing begins.
            parseWorkbook(workbook);
        } catch (IOException e) {
            e.printStackTrace();
            throw new IOException("An unexpected exception has occurred: " + e.toString());
//        } catch (InvalidFormatException e) {
//            e.printStackTrace();
//            throw new IOException("An unexpected exception has occurred: " + e.toString());
        } finally {
            if (workbook != null) {
                workbook.close();
            }

            // The InputSource is closed externally.
            // In this case, only explicitly opened streams will be processed.
            if (inStream != null) {
                inStream.close();
            }
        }
    }

    /**
     * Parses the sheet.
     *
     * @param sheet
     *            A sheet object.
     * @throws SAXException
     *              If a SAX exception occurs.
     */
    protected final void parseSheet(final Sheet sheet) throws SAXException {
        // Sheet elements are handled by the upper class.
        AttributesImpl attrImpl = new AttributesImpl();
        attrImpl.addAttribute("", "name", "name", "CDATA", sheet.getSheetName());
        getContentHandler().startElement("",
                (String) getProperty(URI_PROPERTY_NAME_SHEET),
                (String) getProperty(URI_PROPERTY_NAME_SHEET), attrImpl);

        startSheet(sheet.getSheetName());

        // getLastRowNum() counts from 0, so it should be +1.
        int maxRows = sheet.getLastRowNum() + 1;

        for (int row = 0; row < maxRows; row++) {
            startRow(row + 1);
            Row line = sheet.getRow(row);
            if (line != null) {
                for (int column = 0; column < line.getLastCellNum(); column++) {

                    startColumn(column + 1);
                    Cell cell = line.getCell(column);
                    // The content will be delivered without trim().
                    String value = getCellValue(cell);
                    fireCell(column + 1, row + 1, value);
                    endColumn(column + 1);
                }
            }
            endRow(row + 1);
        }

        endSheet(sheet);

        // Sheet elements are handled by the upper class.
        getContentHandler().endElement("",
                (String) getProperty(URI_PROPERTY_NAME_SHEET),
                (String) getProperty(URI_PROPERTY_NAME_SHEET));
    }

}
