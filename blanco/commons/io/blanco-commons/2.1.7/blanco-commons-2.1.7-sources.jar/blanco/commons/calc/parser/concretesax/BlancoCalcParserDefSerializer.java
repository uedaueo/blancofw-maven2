/*
 * blanco Framework
 * Copyright (C) 2004-2009 IGA Tosiki
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 */
/*******************************************************************************
 * Copyright (c) 2009 IGA Tosiki, NTT DATA BUSINESS BRAINS Corp.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    IGA Tosiki (NTT DATA BUSINESS BRAINS Corp.) - initial API and implementation
 *******************************************************************************/
package blanco.commons.calc.parser.concretesax;

import java.io.OutputStream;
import java.io.Writer;

import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.sax.SAXTransformerFactory;
import javax.xml.transform.sax.TransformerHandler;
import javax.xml.transform.stream.StreamResult;

import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.AttributesImpl;

;

/**
 * BlancoCalcParserDefSerializer SAX class for embodiment.<br>
 * This is a class for wrapping XML export using SAX.<br>
 * This class was generated as a SAX class for embodiment with an XML file for analysis as input.<br>
 * This source code is auto-generated mechanically by blancoIg. This class does not implements ContentHandler.<br>
 * A typical usage is as follows.<br>
 * 
 * <pre>
 * BlancoCalcParserDefSerializer serializer = new BlancoCalcParserDefSerializer(
 *         outStream);
 * serializer.startDocument();
 * serializer.startElementXXXX();
 * serializer.characters(&quot;The string you want to generate&quot;);
 * serializer.endElementXXXX();
 * serializer.endDocument();
 * </pre>
 */
public class BlancoCalcParserDefSerializer {
    /**
     * SAX handler for output to be used internally<br>
     * The stream to be concatenated needs to be closed externally.
     */
    private TransformerHandler _saxHandler;

    public BlancoCalcParserDefSerializer(OutputStream outStream)
            throws TransformerConfigurationException {
        TransformerFactory tf = TransformerFactory.newInstance();
        SAXTransformerFactory saxTf = (SAXTransformerFactory) tf;
        _saxHandler = saxTf.newTransformerHandler();
        _saxHandler.setResult(new StreamResult(outStream));
    }

    public BlancoCalcParserDefSerializer(Writer writer)
            throws TransformerConfigurationException {
        TransformerFactory tf = TransformerFactory.newInstance();
        SAXTransformerFactory saxTf = (SAXTransformerFactory) tf;
        _saxHandler = saxTf.newTransformerHandler();
        _saxHandler.setResult(new StreamResult(writer));
    }

    /**
     * Causes a startDocument to be generated.
     * 
     * @throws SAXException
     *             If a SAX-related exception occurs.
     */
    public void startDocument() throws SAXException {
        _saxHandler.startDocument();
    }

    /**
     * Causes endDocument to be generated.
     * 
     * @throws SAXException
     *             If a SAX-related exception occurs.
     */
    public void endDocument() throws SAXException {
        _saxHandler.endDocument();
    }

    /** startPrefixMapping to be generated. */
    public void startPrefixMapping(String prefix, String uri)
            throws SAXException {
        _saxHandler.startPrefixMapping(prefix, uri);
    }

    /**
     * endPrefixMapping to be generated.
     * 
     * @throws SAXException
     *             If a SAX-related exception occurs.
     */
    public void endPrefixMapping(String prefix) throws SAXException {
        _saxHandler.endPrefixMapping(prefix);
    }

    /**
     * setDocumentLocator to be generated.
     *
     * @param locator
     *            A locator
     */
    public void setDocumentLocator(Locator locator) {
        _saxHandler.setDocumentLocator(locator);
    }

    /**
     * processingInstruction to be generated.
     * 
     * @throws SAXException
     *             If a SAX-related exception occurs.
     */
    public void processingInstruction(String target, String data)
            throws SAXException {
        _saxHandler.processingInstruction(target, data);
    }

    /**
     * skippedEntity to be generated.
     * 
     * @throws SAXException
     *             If a SAX-related exception occurs.
     */
    public void skippedEntity(String name) throws SAXException {
        _saxHandler.skippedEntity(name);
    }

    /**
     * Calls characters method.<br>
     * 
     * @param ch
     *            The string you want to output
     * @param start
     *            Start position
     * @param length
     *            Length of the string
     * 
     * @throws SAXException
     *             If a SAX-related exception occurs.
     */
    public void characters(char[] ch, int start, int length)
            throws SAXException {
        _saxHandler.characters(ch, start, length);
    }

    /**
     * Calls characters method.<br>
     * Note: For simplicity, the arguments have been converted to java.lang.
     * 
     * @param data
     *            The string you want to output
     * 
     * @throws SAXException
     *             If a SAX-related exception occurs.
     */
    public void characters(String data) throws SAXException {
        final char[] chars = data.toCharArray();
        _saxHandler.characters(chars, 0, chars.length);
    }

    /**
     * ignorableWhitespace to be generated.
     * 
     * @throws SAXException
     *             If a SAX-related exception occurs.
     */
    public void ignorableWhitespace(char[] ch, int start, int length)
            throws SAXException {
        _saxHandler.ignorableWhitespace(ch, start, length);
    }

    /**
     * Calls startElement as the qualified name with prefix [blanco].<br>
     * Note: The basic information is included in the method implementation, so it is excluded from the arguments.<br>
     * Namespace URI []<br>
     * Local name [blanco]<br>
     * Qualified name with prefix [blanco]<br>
     * 
     * @param attrVersion
     *            Passes the value of attribute [version]. If you do not want to set the attribute, set it to null.
     */
    public void startElementBlanco(String attrVersion) throws SAXException {
        AttributesImpl attributes = new AttributesImpl();
        if (attrVersion != null) {
            attributes.addAttribute("", "version", "version", "CDATA",
                    attrVersion);
        }
        _saxHandler.startElement("", "blanco", "blanco", attributes);
    }

    /**
     * Calls endElement as the qualified name with prefix [blanco].<br>
     * Note: The basic information is included in the method implementation, so it is excluded from the arguments.<br>
     * Namespace URI []<br>
     * Local name [blanco]<br>
     * Qualified name with prefix [blanco]<br>
     */
    public void endElementBlanco() throws SAXException {
        _saxHandler.endElement("", "blanco", "blanco");
    }

    /**
     * Calls startElement as the qualified name with prefix [target].<br>
     * Note: The basic information is included in the method implementation, so it is excluded from the arguments.<br>
     * Namespace URI []<br>
     * Local name [target]<br>
     * Qualified name with prefix [target]<br>
     * 
     * @param attrName
     *            Passes the value of attribute [name]. If you do not want to set the attribute, set it to null.
     */
    public void startElementTarget(String attrName) throws SAXException {
        AttributesImpl attributes = new AttributesImpl();
        if (attrName != null) {
            attributes.addAttribute("", "name", "name", "CDATA", attrName);
        }
        _saxHandler.startElement("", "target", "target", attributes);
    }

    /**
     * Calls endElement as the qualified name with prefix [target].<br>
     * Note: The basic information is included in the method implementation, so it is excluded from the arguments.<br>
     * Namespace URI []<br>
     * Local name [target]<br>
     * Qualified name with prefix [target]<br>
     */
    public void endElementTarget() throws SAXException {
        _saxHandler.endElement("", "target", "target");
    }

    /**
     * Calls startElement as the qualified name with prefix [blancocalcparser].<br>
     * Note: The basic information is included in the method implementation, so it is excluded from the arguments.<br>
     * Namespace URI []<br>
     * Local name [blancocalcparser]<br>
     * Qualified name with prefix [blancocalcparser]<br>
     * 
     * @param attrName
     *            Passes the value of attribute [name]. If you do not want to set the attribute, set it to null.
     */
    public void startElementBlancocalcparser(String attrName)
            throws SAXException {
        AttributesImpl attributes = new AttributesImpl();
        if (attrName != null) {
            attributes.addAttribute("", "name", "name", "CDATA", attrName);
        }
        _saxHandler.startElement("", "blancocalcparser", "blancocalcparser",
                attributes);
    }

    /**
     * Calls endElement as the qualified name with prefix [blancocalcparser].<br>
     * Note: The basic information is included in the method implementation, so it is excluded from the arguments.<br>
     * Namespace URI []<br>
     * Local name [blancocalcparser]<br>
     * Qualified name with prefix [blancocalcparser]<br>
     */
    public void endElementBlancocalcparser() throws SAXException {
        _saxHandler.endElement("", "blancocalcparser", "blancocalcparser");
    }

    /**
     * Calls startElement as the qualified name with prefix [propertyblock].<br>
     * Note: The basic information is included in the method implementation, so it is excluded from the arguments.<br>
     * Namespace URI []<br>
     * Local name [propertyblock]<br>
     * Qualified name with prefix [propertyblock]<br>
     * 
     * @param attrName
     *            Passes the value of attribute [name]. If you do not want to set the attribute, set it to null.
     * @param attrWaitY
     *            Passes the value of attribute [waitY]. If you do not want to set the attribute, set it to null.
     */
    public void startElementPropertyblock(String attrName, String attrWaitY)
            throws SAXException {
        AttributesImpl attributes = new AttributesImpl();
        if (attrName != null) {
            attributes.addAttribute("", "name", "name", "CDATA", attrName);
        }
        if (attrWaitY != null) {
            attributes.addAttribute("", "waitY", "waitY", "CDATA", attrWaitY);
        }
        _saxHandler.startElement("", "propertyblock", "propertyblock",
                attributes);
    }

    /**
     * Calls endElement as the qualified name with prefix [propertyblock].<br>
     * Note: The basic information is included in the method implementation, so it is excluded from the arguments.<br>
     * Namespace URI []<br>
     * Local name [propertyblock]<br>
     * Qualified name with prefix [propertyblock]<br>
     */
    public void endElementPropertyblock() throws SAXException {
        _saxHandler.endElement("", "propertyblock", "propertyblock");
    }

    /**
     * Calls startElement as the qualified name with prefix [startstring].<br>
     * Note: The basic information is included in the method implementation, so it is excluded from the arguments.<br>
     * Namespace URI []<br>
     * Local name [startstring]<br>
     * Qualified name with prefix [startstring]<br>
     */
    public void startElementStartstring() throws SAXException {
        AttributesImpl attributes = new AttributesImpl();
        _saxHandler.startElement("", "startstring", "startstring", attributes);
    }

    /**
     * Calls endElement as the qualified name with prefix [startstring].<br>
     * Note: The basic information is included in the method implementation, so it is excluded from the arguments.<br>
     * Namespace URI []<br>
     * Local name [startstring]<br>
     * Qualified name with prefix [startstring]<br>
     */
    public void endElementStartstring() throws SAXException {
        _saxHandler.endElement("", "startstring", "startstring");
    }

    /**
     * Calls startElement as the qualified name with prefix [propertykey].<br>
     * Note: The basic information is included in the method implementation, so it is excluded from the arguments.<br>
     * Namespace URI []<br>
     * Local name [propertykey]<br>
     * Qualified name with prefix [propertykey]<br>
     * 
     * @param attrName
     *            Passes the value of attribute [name]. If you do not want to set the attribute, set it to null.
     * @param attrWaitX
     *            Passes the value of attribute [waitX]. If you do not want to set the attribute, set it to null.
     */
    public void startElementPropertykey(String attrName, String attrWaitX)
            throws SAXException {
        AttributesImpl attributes = new AttributesImpl();
        if (attrName != null) {
            attributes.addAttribute("", "name", "name", "CDATA", attrName);
        }
        if (attrWaitX != null) {
            attributes.addAttribute("", "waitX", "waitX", "CDATA", attrWaitX);
        }
        _saxHandler.startElement("", "propertykey", "propertykey", attributes);
    }

    /**
     * Calls endElement as the qualified name with prefix [propertykey].<br>
     * Note: The basic information is included in the method implementation, so it is excluded from the arguments.<br>
     * Namespace URI []<br>
     * Local name [propertykey]<br>
     * Qualified name with prefix [propertykey]<br>
     */
    public void endElementPropertykey() throws SAXException {
        _saxHandler.endElement("", "propertykey", "propertykey");
    }

    /**
     * Calls startElement as the qualified name with prefix [value].<br>
     * Note: The basic information is included in the method implementation, so it is excluded from the arguments.<br>
     * Namespace URI []<br>
     * Local name [value]<br>
     * Qualified name with prefix [value]<br>
     */
    public void startElementValue() throws SAXException {
        AttributesImpl attributes = new AttributesImpl();
        _saxHandler.startElement("", "value", "value", attributes);
    }

    /**
     * Calls endElement as the qualified name with prefix [value].<br>
     * Note: The basic information is included in the method implementation, so it is excluded from the arguments.<br>
     * Namespace URI []<br>
     * Local name [value]<br>
     * Qualified name with prefix [value]<br>
     */
    public void endElementValue() throws SAXException {
        _saxHandler.endElement("", "value", "value");
    }

    /**
     * Calls startElement as the qualified name with prefix [valuemapping].<br>
     * Note: The basic information is included in the method implementation, so it is excluded from the arguments.<br>
     * Namespace URI []<br>
     * Local name [valuemapping]<br>
     * Qualified name with prefix [valuemapping]<br>
     */
    public void startElementValuemapping() throws SAXException {
        AttributesImpl attributes = new AttributesImpl();
        _saxHandler
                .startElement("", "valuemapping", "valuemapping", attributes);
    }

    /**
     * Calls endElement as the qualified name with prefix [valuemapping].<br>
     * Note: The basic information is included in the method implementation, so it is excluded from the arguments.<br>
     * Namespace URI []<br>
     * Local name [valuemapping]<br>
     * Qualified name with prefix [valuemapping]<br>
     */
    public void endElementValuemapping() throws SAXException {
        _saxHandler.endElement("", "valuemapping", "valuemapping");
    }

    /**
     * Calls startElement as the qualified name with prefix [result].<br>
     * Note: The basic information is included in the method implementation, so it is excluded from the arguments.<br>
     * Namespace URI []<br>
     * Local name [result]<br>
     * Qualified name with prefix [result]<br>
     */
    public void startElementResult() throws SAXException {
        AttributesImpl attributes = new AttributesImpl();
        _saxHandler.startElement("", "result", "result", attributes);
    }

    /**
     * Calls endElement as the qualified name with prefix [result].<br>
     * Note: The basic information is included in the method implementation, so it is excluded from the arguments.<br>
     * Namespace URI []<br>
     * Local name [result]<br>
     * Qualified name with prefix [result]<br>
     */
    public void endElementResult() throws SAXException {
        _saxHandler.endElement("", "result", "result");
    }

    /**
     * Calls startElement as the qualified name with prefix [source].<br>
     * Note: The basic information is included in the method implementation, so it is excluded from the arguments.<br>
     * Namespace URI []<br>
     * Local name [source]<br>
     * Qualified name with prefix [source]<br>
     */
    public void startElementSource() throws SAXException {
        AttributesImpl attributes = new AttributesImpl();
        _saxHandler.startElement("", "source", "source", attributes);
    }

    /**
     * Calls endElement as the qualified name with prefix [source].<br>
     * Note: The basic information is included in the method implementation, so it is excluded from the arguments.<br>
     * Namespace URI []<br>
     * Local name [source]<br>
     * Qualified name with prefix [source]<br>
     */
    public void endElementSource() throws SAXException {
        _saxHandler.endElement("", "source", "source");
    }

    /**
     * Calls startElement as the qualified name with prefix [tableblock].<br>
     * Note: The basic information is included in the method implementation, so it is excluded from the arguments.<br>
     * Namespace URI []<br>
     * Local name [tableblock]<br>
     * Qualified name with prefix [tableblock]<br>
     * 
     * @param attrName
     *            Passes the value of attribute [name]. If you do not want to set the attribute, set it to null.
     * @param attrWaitY
     *            Passes the value of attribute [waitY]. If you do not want to set the attribute, set it to null.
     * @param attrTitleheight
     *            Passes the value of attribute [titleheight]. If you do not want to set the attribute, set it to null.
     * @param attrRowname
     *            Passes the value of attribute [rowname]. If you do not want to set the attribute, set it to null.
     */
    public void startElementTableblock(String attrName, String attrWaitY,
            String attrTitleheight, String attrRowname) throws SAXException {
        AttributesImpl attributes = new AttributesImpl();
        if (attrName != null) {
            attributes.addAttribute("", "name", "name", "CDATA", attrName);
        }
        if (attrWaitY != null) {
            attributes.addAttribute("", "waitY", "waitY", "CDATA", attrWaitY);
        }
        if (attrTitleheight != null) {
            attributes.addAttribute("", "titleheight", "titleheight", "CDATA",
                    attrTitleheight);
        }
        if (attrRowname != null) {
            attributes.addAttribute("", "rowname", "rowname", "CDATA",
                    attrRowname);
        }
        _saxHandler.startElement("", "tableblock", "tableblock", attributes);
    }

    /**
     * Calls endElement as the qualified name with prefix [tableblock].<br>
     * Note: The basic information is included in the method implementation, so it is excluded from the arguments.<br>
     * Namespace URI []<br>
     * Local name [tableblock]<br>
     * Qualified name with prefix [tableblock]<br>
     */
    public void endElementTableblock() throws SAXException {
        _saxHandler.endElement("", "tableblock", "tableblock");
    }

    /**
     * Calls startElement as the qualified name with prefix [tablecolumn].<br>
     * Note: The basic information is included in the method implementation, so it is excluded from the arguments.<br>
     * Namespace URI []<br>
     * Local name [tablecolumn]<br>
     * Qualified name with prefix [tablecolumn]<br>
     * 
     * @param attrName
     *            Passes the value of attribute [name]. If you do not want to set the attribute, set it to null.
     */
    public void startElementTablecolumn(String attrName) throws SAXException {
        AttributesImpl attributes = new AttributesImpl();
        if (attrName != null) {
            attributes.addAttribute("", "name", "name", "CDATA", attrName);
        }
        _saxHandler.startElement("", "tablecolumn", "tablecolumn", attributes);
    }

    /**
     * Calls endElement as the qualified name with prefix [tablecolumn].<br>
     * Note: The basic information is included in the method implementation, so it is excluded from the arguments.<br>
     * Namespace URI []<br>
     * Local name [tablecolumn]<br>
     * Qualified name with prefix [tablecolumn]<br>
     */
    public void endElementTablecolumn() throws SAXException {
        _saxHandler.endElement("", "tablecolumn", "tablecolumn");
    }
}
