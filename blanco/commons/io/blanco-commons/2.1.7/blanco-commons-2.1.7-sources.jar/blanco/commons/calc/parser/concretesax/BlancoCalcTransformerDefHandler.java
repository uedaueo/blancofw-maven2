/*
 * blanco Framework
 * Copyright (C) 2004-2009 IGA Tosiki
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 */
/*******************************************************************************
 * Copyright (c) 2009 IGA Tosiki, NTT DATA BUSINESS BRAINS Corp.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    IGA Tosiki (NTT DATA BUSINESS BRAINS Corp.) - initial API and implementation
 *******************************************************************************/
package blanco.commons.calc.parser.concretesax;

import java.io.CharArrayWriter;
import java.util.Stack;

import org.xml.sax.Attributes;
import org.xml.sax.ContentHandler;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;

/**
 * BlancoCalcTransformerDefHandler SAX class for embodiment.<br>
 * This class was generated as a SAX class for embodiment with an XML file for analysis as input.<br>
 * This source code is auto-generated mechanically by blancoIg.<br>
 * A typical usage is as follows.<br>
 * 
 * <pre>
 * TransformerFactory tf = TransformerFactory.newInstance();
 * Transformer transformer = tf.newTransformer();
 * transformer.transform(new StreamSource(inStream), new SAXResult(
 *         new BlancoCalcParserDefHandler())); // In fact, gives the Handler of the implementing class.
 * </pre>
 */
public abstract class BlancoCalcTransformerDefHandler implements ContentHandler {
    /**
     * Stack of the element.<br>
     * Stores the XML hierarchical structure.
     */
    private Stack<java.lang.String> _elementStack = new Stack<java.lang.String>();

    /**
     * A cache to pass to characters.<br>
     * Stores string data.
     */
    private CharArrayWriter _writerBlanco = new CharArrayWriter();

    /**
     * A cache to pass to characters.<br>
     * Stores string data.
     */
    private CharArrayWriter _writerTarget = new CharArrayWriter();

    /**
     * A cache to pass to characters.<br>
     * Stores string data.
     */
    private CharArrayWriter _writerBlancocalcparser = new CharArrayWriter();

    /**
     * A cache to pass to characters.<br>
     * Stores string data.
     */
    private CharArrayWriter _writerPropertyblock = new CharArrayWriter();

    /**
     * A cache to pass to characters.<br>
     * Stores string data.
     */
    private CharArrayWriter _writerStartstring = new CharArrayWriter();

    /**
     * A cache to pass to characters.<br>
     * Stores string data.
     */
    private CharArrayWriter _writerPropertykey = new CharArrayWriter();

    /**
     * A cache to pass to characters.<br>
     * Stores string data.
     */
    private CharArrayWriter _writerValue = new CharArrayWriter();

    /**
     * A cache to pass to characters.<br>
     * Stores string data.(added)
     */
    private CharArrayWriter _writerPropertydata = new CharArrayWriter();

    /**
     * A cache to pass to characters.<br>
     * Stores string data.(added)
     */
    private CharArrayWriter _writerColumndata = new CharArrayWriter();

    /**
     * A cache to pass to characters.<br>
     * Stores string data.
     */
    private CharArrayWriter _writerValuemapping = new CharArrayWriter();

    /**
     * A cache to pass to characters.<br>
     * Stores string data.
     */
    private CharArrayWriter _writerResult = new CharArrayWriter();

    /**
     * A cache to pass to characters.<br>
     * Stores string data.
     */
    private CharArrayWriter _writerSource = new CharArrayWriter();

    /**
     * A cache to pass to characters.<br>
     * Stores string data.
     */
    private CharArrayWriter _writerTableblock = new CharArrayWriter();

    /**
     * A cache to pass to characters.<br>
     * Stores string data.
     */
    private CharArrayWriter _writerTablecolumn = new CharArrayWriter();

    /**
     * startElement has been called with the prefix qualified name [blanco].<br>
     * Note: Qualified names with prefixes are given equivalent to those in the method name.
     * 
     * @param uri
     *            Namespace URI
     * @param localName
     *            Local name
     * @param qName
     *            Qualified name with prefix
     * @param attrVersion
     *            The value of the attribute [version] will be passed.
     */
    public abstract void startElementBlanco(String uri, String localName,
            String qName, String attrVersion) throws SAXException;

    /**
     * endElement has been called with the prefix qualified name [blanco].<br>
     * Note: Qualified names with prefixes are given equivalent to those in the method name.
     * 
     * @param uri
     *            Namespace URI
     * @param localName
     *            Local name
     * @param qName
     *            Qualified name with prefix
     */
    public abstract void endElementBlanco(String uri, String localName,
            String qName) throws SAXException;

    /**
     * characters has been called with the prefix qualified name [blanco].<br>
     * The method will be called after aggregating the original characters method.
     * 
     * @param ch
     *            Characters in XML documents
     * @param start
     *            Start position in the array
     * @param length
     *            The number of characters to read from the array
     */
    public abstract void charactersBlanco(char[] ch, int start, int length)
            throws SAXException;

    /**
     * ignorableWhitespace has been called with the prefix qualified name [blanco].<br>
     * The method will be called after aggregating the original characters method.
     * 
     * @param ch
     *            Characters in XML documents
     * @param start
     *            Start position in the array
     * @param length
     *            The number of characters to read from the array
     */
    public abstract void ignorableWhitespaceBlanco(char[] ch, int start,
            int length) throws SAXException;

    /**
     * startElement has been called with the prefix qualified name [target].<br>
     * Note: Qualified names with prefixes are given equivalent to those in the method name.
     * 
     * @param uri
     *            Namespace URI
     * @param localName
     *            Local name
     * @param qName
     *            Qualified name with prefix
     * @param attrName
     *            The value of the attribute [name] will be passed.
     */
    public abstract void startElementTarget(String uri, String localName,
            String qName, String attrName) throws SAXException;

    /**
     * endElement has been called with the prefix qualified name [target].<br>
     * Note: Qualified names with prefixes are given equivalent to those in the method name.
     * 
     * @param uri
     *            Namespace URI
     * @param localName
     *            Local name
     * @param qName
     *            Qualified name with prefix
     */
    public abstract void endElementTarget(String uri, String localName,
            String qName) throws SAXException;

    /**
     * characters has been called with the prefix qualified name [target].<br>
     * The method will be called after aggregating the original characters method.
     * 
     * @param ch
     *            Characters in XML documents
     * @param start
     *            Start position in the array
     * @param length
     *            The number of characters to read from the array
     */
    public abstract void charactersTarget(char[] ch, int start, int length)
            throws SAXException;

    /**
     * ignorableWhitespace has been called with the prefix qualified name [target].<br>
     * The method will be called after aggregating the original characters method.
     * 
     * @param ch
     *            Characters in XML documents
     * @param start
     *            Start position in the array
     * @param length
     *            The number of characters to read from the array
     */
    public abstract void ignorableWhitespaceTarget(char[] ch, int start,
            int length) throws SAXException;

    /**
     * startElement has been called with the prefix qualified name [blancocalcparser].<br>
     * Note: Qualified names with prefixes are given equivalent to those in the method name.
     * 
     * @param uri
     *            Namespace URI
     * @param localName
     *            Local name
     * @param qName
     *            Qualified name with prefix
     * @param attrName
     *            The value of the attribute [name] will be passed.
     */
    public abstract void startElementBlancocalcparser(String uri,
            String localName, String qName, String attrName)
            throws SAXException;

    /**
     * endElement has been called with the prefix qualified name [blancocalcparser].<br>
     * Note: Qualified names with prefixes are given equivalent to those in the method name.
     * 
     * @param uri
     *            Namespace URI
     * @param localName
     *            Local name
     * @param qName
     *            Qualified name with prefix
     */
    public abstract void endElementBlancocalcparser(String uri,
            String localName, String qName) throws SAXException;

    /**
     * characters has been called with the prefix qualified name [blancocalcparser].<br>
     * The method will be called after aggregating the original characters method.
     * 
     * @param ch
     *            Characters in XML documents
     * @param start
     *            Start position in the array
     * @param length
     *            The number of characters to read from the array
     */
    public abstract void charactersBlancocalcparser(char[] ch, int start,
            int length) throws SAXException;

    /**
     * ignorableWhitespace has been called with the prefix qualified name [blancocalcparser].<br>
     * The method will be called after aggregating the original characters method.
     * 
     * @param ch
     *            Characters in XML documents
     * @param start
     *            Start position in the array
     * @param length
     *            The number of characters to read from the array
     */
    public abstract void ignorableWhitespaceBlancocalcparser(char[] ch,
            int start, int length) throws SAXException;

    /**
     * startElement has been called with the prefix qualified name [propertyblock].<br>
     * Note: Qualified names with prefixes are given equivalent to those in the method name.
     * 
     * @param uri
     *            Namespace URI
     * @param localName
     *            Local name
     * @param qName
     *            Qualified name with prefix
     * @param attrName
     *            The value of the attribute [name] will be passed.
     * @param attrWaitY
     *            The value of the attribute [waitY] will be passed.
     */
    public abstract void startElementPropertyblock(String uri,
            String localName, String qName, String attrName, String attrWaitY)
            throws SAXException;

    /**
     * endElement has been called with the prefix qualified name [propertyblock].<br>
     * Note: Qualified names with prefixes are given equivalent to those in the method name.
     * 
     * @param uri
     *            Namespace URI
     * @param localName
     *            Local name
     * @param qName
     *            Qualified name with prefix
     */
    public abstract void endElementPropertyblock(String uri, String localName,
            String qName) throws SAXException;

    /**
     * characters has been called with the prefix qualified name [propertyblock].<br>
     * The method will be called after aggregating the original characters method.
     * 
     * @param ch
     *            Characters in XML documents
     * @param start
     *            Start position in the array
     * @param length
     *            The number of characters to read from the array
     */
    public abstract void charactersPropertyblock(char[] ch, int start,
            int length) throws SAXException;

    /**
     * ignorableWhitespace has been called with the prefix qualified name [propertyblock].<br>
     * The method will be called after aggregating the original characters method.
     * 
     * @param ch
     *            Characters in XML documents
     * @param start
     *            Start position in the array
     * @param length
     *            The number of characters to read from the array
     */
    public abstract void ignorableWhitespacePropertyblock(char[] ch, int start,
            int length) throws SAXException;

    /**
     * startElement has been called with the prefix qualified name [startstring].<br>
     * Note: Qualified names with prefixes are given equivalent to those in the method name.
     * 
     * @param uri
     *            Namespace URI
     * @param localName
     *            Local name
     * @param qName
     *            Qualified name with prefix
     */
    public abstract void startElementStartstring(String uri, String localName,
            String qName) throws SAXException;

    /**
     * endElement has been called with the prefix qualified name [startstring].<br>
     * Note: Qualified names with prefixes are given equivalent to those in the method name.
     * 
     * @param uri
     *            Namespace URI
     * @param localName
     *            Local name
     * @param qName
     *            Qualified name with prefix
     */
    public abstract void endElementStartstring(String uri, String localName,
            String qName) throws SAXException;

    /**
     * characters has been called with the prefix qualified name [startstring].<br>
     * The method will be called after aggregating the original characters method.
     * 
     * @param ch
     *            Characters in XML documents
     * @param start
     *            Start position in the array
     * @param length
     *            The number of characters to read from the array
     */
    public abstract void charactersStartstring(char[] ch, int start, int length)
            throws SAXException;

    /**
     * ignorableWhitespace has been called with the prefix qualified name [startstring].<br>
     * The method will be called after aggregating the original characters method.
     * 
     * @param ch
     *            Characters in XML documents
     * @param start
     *            Start position in the array
     * @param length
     *            The number of characters to read from the array
     */
    public abstract void ignorableWhitespaceStartstring(char[] ch, int start,
            int length) throws SAXException;

    /**
     * startElement has been called with the prefix qualified name [propertykey].<br>
     * Note: Qualified names with prefixes are given equivalent to those in the method name.
     * 
     * @param uri
     *            Namespace URI
     * @param localName
     *            Local name
     * @param qName
     *            Qualified name with prefix
     * @param attrName
     *            The value of the attribute [name] will be passed.
     * @param attrWaitX
     *            The value of the attribute [waitX] will be passed.
     */
    public abstract void startElementPropertykey(String uri, String localName,
            String qName, String attrName, String attrWaitX)
            throws SAXException;

    /**
     * endElement has been called with the prefix qualified name [propertykey].<br>
     * Note: Qualified names with prefixes are given equivalent to those in the method name.
     * 
     * @param uri
     *            Namespace URI
     * @param localName
     *            Local name
     * @param qName
     *            Qualified name with prefix
     */
    public abstract void endElementPropertykey(String uri, String localName,
            String qName) throws SAXException;

    /**
     * characters has been called with the prefix qualified name [propertykey].<br>
     * The method will be called after aggregating the original characters method.
     * 
     * @param ch
     *            Characters in XML documents
     * @param start
     *            Start position in the array
     * @param length
     *            The number of characters to read from the array
     */
    public abstract void charactersPropertykey(char[] ch, int start, int length)
            throws SAXException;

    /**
     * ignorableWhitespace has been called with the prefix qualified name [propertykey].<br>
     * The method will be called after aggregating the original characters method.
     * 
     * @param ch
     *            Characters in XML documents
     * @param start
     *            Start position in the array
     * @param length
     *            The number of characters to read from the array
     */
    public abstract void ignorableWhitespacePropertykey(char[] ch, int start,
            int length) throws SAXException;

    /**
     * startElement has been called with the prefix qualified name [value].<br>
     * Note: Qualified names with prefixes are given equivalent to those in the method name.
     * 
     * @param uri
     *            Namespace URI
     * @param localName
     *            Local name
     * @param qName
     *            Qualified name with prefix
     */
    public abstract void startElementValue(String uri, String localName,
            String qName) throws SAXException;

    // added
    public abstract void startElementPropertyData(String uri, String localName,
                                           String qName) throws SAXException;

    // added
    public abstract void startElementColumnData(String uri, String localName,
                                                  String qName) throws SAXException;

    /**
     * endElement has been called with the prefix qualified name [value].<br>
     * Note: Qualified names with prefixes are given equivalent to those in the method name.
     * 
     * @param uri
     *            Namespace URI
     * @param localName
     *            Local name
     * @param qName
     *            Qualified name with prefix
     */
    public abstract void endElementValue(String uri, String localName,
            String qName) throws SAXException;

    // added
    public abstract void endElementPropertyData(String uri, String localName,
                                         String qName) throws SAXException;

    // added
    public abstract void endElementColumnData(String uri, String localName,
                                                String qName) throws SAXException;

    /**
     * characters has been called with the prefix qualified name [value].<br>
     * The method will be called after aggregating the original characters method.
     * 
     * @param ch
     *            Characters in XML documents
     * @param start
     *            Start position in the array
     * @param length
     *            The number of characters to read from the array
     */
    public abstract void charactersValue(char[] ch, int start, int length)
            throws SAXException;

    // added
    public abstract void charactersPropertyData(char[] ch, int start, int length)
            throws SAXException;

    // added
    public abstract void charactersColumnData(char[] ch, int start, int length)
            throws SAXException;

    /**
     * ignorableWhitespace has been called with the prefix qualified name [value].<br>
     * The method will be called after aggregating the original characters method.
     * 
     * @param ch
     *            Characters in XML documents
     * @param start
     *            Start position in the array
     * @param length
     *            The number of characters to read from the array
     */
    public abstract void ignorableWhitespaceValue(char[] ch, int start,
            int length) throws SAXException;

    // added
    public abstract void ignorableWhitespacePropertyData(char[] ch, int start,
                                                  int length) throws SAXException;

    // added
    public abstract void ignorableWhitespaceColumnData(char[] ch, int start,
                                                         int length) throws SAXException;

    /**
     * startElement has been called with the prefix qualified name [valuemapping].<br>
     * Note: Qualified names with prefixes are given equivalent to those in the method name.
     * 
     * @param uri
     *            Namespace URI
     * @param localName
     *            Local name
     * @param qName
     *            Qualified name with prefix
     */
    public abstract void startElementValuemapping(String uri, String localName,
            String qName) throws SAXException;

    /**
     * endElement has been called with the prefix qualified name [valuemapping].<br>
     * Note: Qualified names with prefixes are given equivalent to those in the method name.
     * 
     * @param uri
     *            Namespace URI
     * @param localName
     *            Local name
     * @param qName
     *            Qualified name with prefix
     */
    public abstract void endElementValuemapping(String uri, String localName,
            String qName) throws SAXException;

    /**
     * characters has been called with the prefix qualified name [valuemapping].<br>
     * The method will be called after aggregating the original characters method.
     * 
     * @param ch
     *            Characters in XML documents
     * @param start
     *            Start position in the array
     * @param length
     *            The number of characters to read from the array
     */
    public abstract void charactersValuemapping(char[] ch, int start, int length)
            throws SAXException;

    /**
     * ignorableWhitespace has been called with the prefix qualified name [valuemapping].<br>
     * The method will be called after aggregating the original characters method.
     * 
     * @param ch
     *            Characters in XML documents
     * @param start
     *            Start position in the array
     * @param length
     *            The number of characters to read from the array
     */
    public abstract void ignorableWhitespaceValuemapping(char[] ch, int start,
            int length) throws SAXException;

    /**
     * startElement has been called with the prefix qualified name [result].<br>
     * Note: Qualified names with prefixes are given equivalent to those in the method name.
     * 
     * @param uri
     *            Namespace URI
     * @param localName
     *            Local name
     * @param qName
     *            Qualified name with prefix
     */
    public abstract void startElementResult(String uri, String localName,
            String qName) throws SAXException;

    /**
     * endElement has been called with the prefix qualified name [result].<br>
     * Note: Qualified names with prefixes are given equivalent to those in the method name.
     * 
     * @param uri
     *            Namespace URI
     * @param localName
     *            Local name
     * @param qName
     *            Qualified name with prefix
     */
    public abstract void endElementResult(String uri, String localName,
            String qName) throws SAXException;

    /**
     * characters has been called with the prefix qualified name [result].<br>
     * The method will be called after aggregating the original characters method.
     * 
     * @param ch
     *            Characters in XML documents
     * @param start
     *            Start position in the array
     * @param length
     *            The number of characters to read from the array
     */
    public abstract void charactersResult(char[] ch, int start, int length)
            throws SAXException;

    /**
     * ignorableWhitespace has been called with the prefix qualified name [result].<br>
     * The method will be called after aggregating the original characters method.
     * 
     * @param ch
     *            Characters in XML documents
     * @param start
     *            Start position in the array
     * @param length
     *            The number of characters to read from the array
     */
    public abstract void ignorableWhitespaceResult(char[] ch, int start,
            int length) throws SAXException;

    /**
     * startElement has been called with the prefix qualified name [source].<br>
     * Note: Qualified names with prefixes are given equivalent to those in the method name.
     * 
     * @param uri
     *            Namespace URI
     * @param localName
     *            Local name
     * @param qName
     *            Qualified name with prefix
     */
    public abstract void startElementSource(String uri, String localName,
            String qName) throws SAXException;

    /**
     * endElement has been called with the prefix qualified name [source].<br>
     * Note: Qualified names with prefixes are given equivalent to those in the method name.
     * 
     * @param uri
     *            Namespace URI
     * @param localName
     *            Local name
     * @param qName
     *            Qualified name with prefix
     */
    public abstract void endElementSource(String uri, String localName,
            String qName) throws SAXException;

    /**
     * characters has been called with the prefix qualified name [source].<br>
     * The method will be called after aggregating the original characters method.
     * 
     * @param ch
     *            Characters in XML documents
     * @param start
     *            Start position in the array
     * @param length
     *            The number of characters to read from the array
     */
    public abstract void charactersSource(char[] ch, int start, int length)
            throws SAXException;

    /**
     * ignorableWhitespace has been called with the prefix qualified name [source].<br>
     * The method will be called after aggregating the original characters method.
     * 
     * @param ch
     *            Characters in XML documents
     * @param start
     *            Start position in the array
     * @param length
     *            The number of characters to read from the array
     */
    public abstract void ignorableWhitespaceSource(char[] ch, int start,
            int length) throws SAXException;

    /**
     * startElement has been called with the prefix qualified name [tableblock].<br>
     * Note: Qualified names with prefixes are given equivalent to those in the method name.
     * 
     * @param uri
     *            Namespace URI
     * @param localName
     *            Local name
     * @param qName
     *            Qualified name with prefix
     * @param attrName
     *            The value of the attribute [name] will be passed.
     * @param attrWaitY
     *            The value of the attribute [waitY] will be passed.
     * @param attrTitleheight
     *            The value of the attribute [titleheight] will be passed.
     * @param attrRowname
     *            The value of the attribute [rowname] will be passed.
     */
    public abstract void startElementTableblock(String uri, String localName,
            String qName, String attrName, String attrWaitY,
            String attrTitleheight, String attrRowname) throws SAXException;

    /**
     * endElement has been called with the prefix qualified name [tableblock].<br>
     * Note: Qualified names with prefixes are given equivalent to those in the method name.
     * 
     * @param uri
     *            Namespace URI
     * @param localName
     *            Local name
     * @param qName
     *            Qualified name with prefix
     */
    public abstract void endElementTableblock(String uri, String localName,
            String qName) throws SAXException;

    /**
     * characters has been called with the prefix qualified name [tableblock].<br>
     * The method will be called after aggregating the original characters method.
     * 
     * @param ch
     *            Characters in XML documents
     * @param start
     *            Start position in the array
     * @param length
     *            The number of characters to read from the array
     */
    public abstract void charactersTableblock(char[] ch, int start, int length)
            throws SAXException;

    /**
     * ignorableWhitespace has been called with the prefix qualified name [tableblock].<br>
     * The method will be called after aggregating the original characters method.
     * 
     * @param ch
     *            Characters in XML documents
     * @param start
     *            Start position in the array
     * @param length
     *            The number of characters to read from the array
     */
    public abstract void ignorableWhitespaceTableblock(char[] ch, int start,
            int length) throws SAXException;

    /**
     * startElement has been called with the prefix qualified name [tablecolumn].<br>
     * Note: Qualified names with prefixes are given equivalent to those in the method name.
     * 
     * @param uri
     *            Namespace URI
     * @param localName
     *            Local name
     * @param qName
     *            Qualified name with prefix
     * @param attrName
     *            The value of the attribute [name] will be passed.
     */
    public abstract void startElementTablecolumn(String uri, String localName,
            String qName, String attrName) throws SAXException;

    /**
     * endElement has been called with the prefix qualified name [tablecolumn].<br>
     * Note: Qualified names with prefixes are given equivalent to those in the method name.
     * 
     * @param uri
     *            Namespace URI
     * @param localName
     *            Local name
     * @param qName
     *            Qualified name with prefix
     */
    public abstract void endElementTablecolumn(String uri, String localName,
            String qName) throws SAXException;

    /**
     * characters has been called with the prefix qualified name [tablecolumn].<br>
     * The method will be called after aggregating the original characters method.
     * 
     * @param ch
     *            Characters in XML documents
     * @param start
     *            Start position in the array
     * @param length
     *            The number of characters to read from the array
     */
    public abstract void charactersTablecolumn(char[] ch, int start, int length)
            throws SAXException;

    /**
     * ignorableWhitespace has been called with the prefix qualified name [tablecolumn].<br>
     * The method will be called after aggregating the original characters method.
     * 
     * @param ch
     *            Characters in XML documents
     * @param start
     *            Start position in the array
     * @param length
     *            The number of characters to read from the array
     */
    public abstract void ignorableWhitespaceTablecolumn(char[] ch, int start,
            int length) throws SAXException;

    /**
     * Now that the original startElement has been called, calls the concrete method by different names.
     * 
     * @param uri
     *            Namespace URI
     * @param localName
     *            Local name
     * @param qName
     *            Qualified name with prefix
     * @param atts
     *            A list of attributes
     */
    public final void startElement(String uri, String localName, String qName,
            Attributes atts) throws SAXException {
        if (_elementStack.empty() == false) {
            final String previousElementOnStack = (String) _elementStack.peek();
            if (previousElementOnStack.equals("source")) {
                _writerSource.flush();
                char[] wrk = _writerSource.toCharArray();
                _writerSource.reset();
                if (wrk.length > 0) {
                    charactersSource(wrk, 0, wrk.length);
                }

            } else if (previousElementOnStack.equals("blanco")) {
                _writerBlanco.flush();
                char[] wrk = _writerBlanco.toCharArray();
                _writerBlanco.reset();
                if (wrk.length > 0) {
                    charactersBlanco(wrk, 0, wrk.length);
                }

            } else if (previousElementOnStack.equals("propertyblock")) {
                _writerPropertyblock.flush();
                char[] wrk = _writerPropertyblock.toCharArray();
                _writerPropertyblock.reset();
                if (wrk.length > 0) {
                    charactersPropertyblock(wrk, 0, wrk.length);
                }

            } else if (previousElementOnStack.equals("propertykey")) {
                _writerPropertykey.flush();
                char[] wrk = _writerPropertykey.toCharArray();
                _writerPropertykey.reset();
                if (wrk.length > 0) {
                    charactersPropertykey(wrk, 0, wrk.length);
                }

            } else if (previousElementOnStack.equals("startstring")) {
                _writerStartstring.flush();
                char[] wrk = _writerStartstring.toCharArray();
                _writerStartstring.reset();
                if (wrk.length > 0) {
                    charactersStartstring(wrk, 0, wrk.length);
                }

            } else if (previousElementOnStack.equals("tablecolumn")) {
                _writerTablecolumn.flush();
                char[] wrk = _writerTablecolumn.toCharArray();
                _writerTablecolumn.reset();
                if (wrk.length > 0) {
                    charactersTablecolumn(wrk, 0, wrk.length);
                }

            } else if (previousElementOnStack.equals("target")) {
                _writerTarget.flush();
                char[] wrk = _writerTarget.toCharArray();
                _writerTarget.reset();
                if (wrk.length > 0) {
                    charactersTarget(wrk, 0, wrk.length);
                }

            } else if (previousElementOnStack.equals("blancocalcparser")) {
                _writerBlancocalcparser.flush();
                char[] wrk = _writerBlancocalcparser.toCharArray();
                _writerBlancocalcparser.reset();
                if (wrk.length > 0) {
                    charactersBlancocalcparser(wrk, 0, wrk.length);
                }

            } else if (previousElementOnStack.equals("value")) {
                _writerValue.flush();
                char[] wrk = _writerValue.toCharArray();
                _writerValue.reset();
                if (wrk.length > 0) {
                    charactersValue(wrk, 0, wrk.length);
                }
            } else if (previousElementOnStack.equals("propertydata")) {// added
                _writerPropertydata.flush();
                char[] wrk = _writerPropertydata.toCharArray();
                _writerPropertydata.reset();
                if (wrk.length > 0) {
                    charactersPropertyData(wrk, 0, wrk.length);
                }

            } else if (previousElementOnStack.equals("columndata")) {// added
                _writerColumndata.flush();
                char[] wrk = _writerColumndata.toCharArray();
                _writerColumndata.reset();
                if (wrk.length > 0) {
                    charactersColumnData(wrk, 0, wrk.length);
                }


            } else if (previousElementOnStack.equals("valuemapping")) {
                _writerValuemapping.flush();
                char[] wrk = _writerValuemapping.toCharArray();
                _writerValuemapping.reset();
                if (wrk.length > 0) {
                    charactersValuemapping(wrk, 0, wrk.length);
                }

            } else if (previousElementOnStack.equals("tableblock")) {
                _writerTableblock.flush();
                char[] wrk = _writerTableblock.toCharArray();
                _writerTableblock.reset();
                if (wrk.length > 0) {
                    charactersTableblock(wrk, 0, wrk.length);
                }

            } else if (previousElementOnStack.equals("result")) {
                _writerResult.flush();
                char[] wrk = _writerResult.toCharArray();
                _writerResult.reset();
                if (wrk.length > 0) {
                    charactersResult(wrk, 0, wrk.length);
                }

            }
        }
        _elementStack.push(qName);
        if (qName.equals("source")) {
            startElementSource(uri, localName, qName);
        } else if (qName.equals("blanco")) {
            startElementBlanco(uri, localName, qName, atts.getValue("version"));
        } else if (qName.equals("propertyblock")) {
            startElementPropertyblock(uri, localName, qName, atts
                    .getValue("name"), atts.getValue("waitY"));
        } else if (qName.equals("propertykey")) {
            startElementPropertykey(uri, localName, qName, atts
                    .getValue("name"), atts.getValue("waitX"));
        } else if (qName.equals("startstring")) {
            startElementStartstring(uri, localName, qName);
        } else if (qName.equals("tablecolumn")) {
            startElementTablecolumn(uri, localName, qName, atts
                    .getValue("name"));
        } else if (qName.equals("target")) {
            startElementTarget(uri, localName, qName, atts.getValue("name"));
        } else if (qName.equals("blancocalcparser")) {
            startElementBlancocalcparser(uri, localName, qName, atts
                    .getValue("name"));
        } else if (qName.equals("value")) {
            startElementValue(uri, localName, qName);
        } else if (qName.equals("propertydata")) {// added
            startElementPropertyData(uri, localName, qName);
        } else if (qName.equals("columndata")) {// added
            startElementColumnData(uri, localName, qName);
        } else if (qName.equals("valuemapping")) {
            startElementValuemapping(uri, localName, qName);
        } else if (qName.equals("tableblock")) {
            startElementTableblock(uri, localName, qName,
                    atts.getValue("name"), atts.getValue("waitY"), atts
                            .getValue("titleheight"), atts.getValue("rowname"));
        } else if (qName.equals("result")) {
            startElementResult(uri, localName, qName);
        }
    }

    /**
     * Now that the original endElement has been called, calls the concrete method by different names.
     * 
     * @param uri
     *            Namespace URI
     * @param localName
     *            Local name
     * @param qName
     *            Qualified name with prefix
     */
    public final void endElement(String uri, String localName, String qName)
            throws SAXException {
        final String currentElementOnStack = (String) _elementStack.peek();
        if (currentElementOnStack.equals(qName) == false) {
            throw new SAXException("XML anomaly. The expected element [" + currentElementOnStack
                    + "] is not the same as the qualified name with prefix [" + qName + "].");
        }
        if (qName.equals("source")) {
            _writerSource.flush();
            char[] wrk = _writerSource.toCharArray();
            _writerSource.reset();
            if (wrk.length > 0) {
                charactersSource(wrk, 0, wrk.length);
            }
            endElementSource(uri, localName, qName);
        } else if (qName.equals("blanco")) {
            _writerBlanco.flush();
            char[] wrk = _writerBlanco.toCharArray();
            _writerBlanco.reset();
            if (wrk.length > 0) {
                charactersBlanco(wrk, 0, wrk.length);
            }
            endElementBlanco(uri, localName, qName);
        } else if (qName.equals("propertyblock")) {
            _writerPropertyblock.flush();
            char[] wrk = _writerPropertyblock.toCharArray();
            _writerPropertyblock.reset();
            if (wrk.length > 0) {
                charactersPropertyblock(wrk, 0, wrk.length);
            }
            endElementPropertyblock(uri, localName, qName);
        } else if (qName.equals("propertykey")) {
            _writerPropertykey.flush();
            char[] wrk = _writerPropertykey.toCharArray();
            _writerPropertykey.reset();
            if (wrk.length > 0) {
                charactersPropertykey(wrk, 0, wrk.length);
            }
            endElementPropertykey(uri, localName, qName);
        } else if (qName.equals("startstring")) {
            _writerStartstring.flush();
            char[] wrk = _writerStartstring.toCharArray();
            _writerStartstring.reset();
            if (wrk.length > 0) {
                charactersStartstring(wrk, 0, wrk.length);
            }
            endElementStartstring(uri, localName, qName);
        } else if (qName.equals("tablecolumn")) {
            _writerTablecolumn.flush();
            char[] wrk = _writerTablecolumn.toCharArray();
            _writerTablecolumn.reset();
            if (wrk.length > 0) {
                charactersTablecolumn(wrk, 0, wrk.length);
            }
            endElementTablecolumn(uri, localName, qName);
        } else if (qName.equals("target")) {
            _writerTarget.flush();
            char[] wrk = _writerTarget.toCharArray();
            _writerTarget.reset();
            if (wrk.length > 0) {
                charactersTarget(wrk, 0, wrk.length);
            }
            endElementTarget(uri, localName, qName);
        } else if (qName.equals("blancocalcparser")) {
            _writerBlancocalcparser.flush();
            char[] wrk = _writerBlancocalcparser.toCharArray();
            _writerBlancocalcparser.reset();
            if (wrk.length > 0) {
                charactersBlancocalcparser(wrk, 0, wrk.length);
            }
            endElementBlancocalcparser(uri, localName, qName);
        } else if (qName.equals("value")) {
            _writerValue.flush();
            char[] wrk = _writerValue.toCharArray();
            _writerValue.reset();
            if (wrk.length > 0) {
                charactersValue(wrk, 0, wrk.length);
            }
            endElementValue(uri, localName, qName);
        } else if (qName.equals("propertydata")) {// added
            _writerPropertydata.flush();
            char[] wrk = _writerPropertydata.toCharArray();
            _writerPropertydata.reset();
            if (wrk.length > 0) {
                charactersPropertyData(wrk, 0, wrk.length);
            }
            endElementPropertyData(uri, localName, qName);
        } else if (qName.equals("columndata")) {// added
            _writerColumndata.flush();
            char[] wrk = _writerColumndata.toCharArray();
            _writerColumndata.reset();
            // Counts Spaces.
            //if (wrk.length > 0) {
                charactersColumnData(wrk, 0, wrk.length);
            //}
            endElementColumnData(uri, localName, qName);
        } else if (qName.equals("valuemapping")) {
            _writerValuemapping.flush();
            char[] wrk = _writerValuemapping.toCharArray();
            _writerValuemapping.reset();
            if (wrk.length > 0) {
                charactersValuemapping(wrk, 0, wrk.length);
            }
            endElementValuemapping(uri, localName, qName);
        } else if (qName.equals("tableblock")) {
            _writerTableblock.flush();
            char[] wrk = _writerTableblock.toCharArray();
            _writerTableblock.reset();
            if (wrk.length > 0) {
                charactersTableblock(wrk, 0, wrk.length);
            }
            endElementTableblock(uri, localName, qName);
        } else if (qName.equals("result")) {
            _writerResult.flush();
            char[] wrk = _writerResult.toCharArray();
            _writerResult.reset();
            if (wrk.length > 0) {
                charactersResult(wrk, 0, wrk.length);
            }
            endElementResult(uri, localName, qName);
        }
        // Finally, pops it back one level in the hierarchy.
        _elementStack.pop();
    }

    /**
     * Now that the original characters has been called, calls the concrete method by different names. We will aggregate and then call them.
     * 
     * @param ch
     *            Characters in XML documents
     * @param start
     *            Start position in the array
     * @param length
     *            The number of characters to read from the array
     */
    public final void characters(char[] ch, int start, int length)
            throws SAXException {
        final String currentElementOnStack = (String) _elementStack.peek();
        if (currentElementOnStack.equals("source")) {
            // charactersSource(ch, start, length);
            _writerSource.write(ch, start, length);
        } else if (currentElementOnStack.equals("blanco")) {
            // charactersBlanco(ch, start, length);
            _writerBlanco.write(ch, start, length);
        } else if (currentElementOnStack.equals("propertyblock")) {
            // charactersPropertyblock(ch, start, length);
            _writerPropertyblock.write(ch, start, length);
        } else if (currentElementOnStack.equals("propertykey")) {
            // charactersPropertykey(ch, start, length);
            _writerPropertykey.write(ch, start, length);
        } else if (currentElementOnStack.equals("startstring")) {
            // charactersStartstring(ch, start, length);
            _writerStartstring.write(ch, start, length);
        } else if (currentElementOnStack.equals("tablecolumn")) {
            // charactersTablecolumn(ch, start, length);
            _writerTablecolumn.write(ch, start, length);
        } else if (currentElementOnStack.equals("target")) {
            // charactersTarget(ch, start, length);
            _writerTarget.write(ch, start, length);
        } else if (currentElementOnStack.equals("blancocalcparser")) {
            // charactersBlancocalcparser(ch, start, length);
            _writerBlancocalcparser.write(ch, start, length);
        } else if (currentElementOnStack.equals("value")) {
            // charactersValue(ch, start, length);
            _writerValue.write(ch, start, length);
        } else if (currentElementOnStack.equals("propertydata")) {// added
            // charactersPropertyData(ch, start, length);
            _writerPropertydata.write(ch, start, length);
        } else if (currentElementOnStack.equals("columndata")) {// added
            // charactersColumnData(ch, start, length);
            _writerColumndata.write(ch, start, length);
        } else if (currentElementOnStack.equals("valuemapping")) {
            // charactersValuemapping(ch, start, length);
            _writerValuemapping.write(ch, start, length);
        } else if (currentElementOnStack.equals("tableblock")) {
            // charactersTableblock(ch, start, length);
            _writerTableblock.write(ch, start, length);
        } else if (currentElementOnStack.equals("result")) {
            // charactersResult(ch, start, length);
            _writerResult.write(ch, start, length);
        }
    }

    /**
     * Now that the original ignorableWhitespace has been called, calls the concrete method by different names. We will aggregate and then call them.
     * 
     * @param ch
     *            Characters in XML documents
     * @param start
     *            Start position in the array
     * @param length
     *            The number of characters to read from the array
     */
    public final void ignorableWhitespace(char[] ch, int start, int length)
            throws SAXException {
        final String currentElementOnStack = (String) _elementStack.peek();
        if (currentElementOnStack.equals("source")) {
            ignorableWhitespaceSource(ch, start, length);
        } else if (currentElementOnStack.equals("blanco")) {
            ignorableWhitespaceBlanco(ch, start, length);
        } else if (currentElementOnStack.equals("propertyblock")) {
            ignorableWhitespacePropertyblock(ch, start, length);
        } else if (currentElementOnStack.equals("propertykey")) {
            ignorableWhitespacePropertykey(ch, start, length);
        } else if (currentElementOnStack.equals("startstring")) {
            ignorableWhitespaceStartstring(ch, start, length);
        } else if (currentElementOnStack.equals("tablecolumn")) {
            ignorableWhitespaceTablecolumn(ch, start, length);
        } else if (currentElementOnStack.equals("target")) {
            ignorableWhitespaceTarget(ch, start, length);
        } else if (currentElementOnStack.equals("blancocalcparser")) {
            ignorableWhitespaceBlancocalcparser(ch, start, length);
        } else if (currentElementOnStack.equals("value")) {
            ignorableWhitespaceValue(ch, start, length);
        } else if (currentElementOnStack.equals("propertydata")) {// added
            ignorableWhitespacePropertyData(ch, start, length);
        } else if (currentElementOnStack.equals("columndata")) {// added
            ignorableWhitespaceColumnData(ch, start, length);
        } else if (currentElementOnStack.equals("valuemapping")) {
            ignorableWhitespaceValuemapping(ch, start, length);
        } else if (currentElementOnStack.equals("tableblock")) {
            ignorableWhitespaceTableblock(ch, start, length);
        } else if (currentElementOnStack.equals("result")) {
            ignorableWhitespaceResult(ch, start, length);
        }
    }

    /** This method is used to ignore this method. */
    public void setDocumentLocator(Locator locator) {
    }

    public void startPrefixMapping(String prefix, String uri)
            throws SAXException {
    }

    public void endPrefixMapping(String prefix) throws SAXException {
    }

    public void processingInstruction(String target, String data)
            throws SAXException {
    }

    public void skippedEntity(String name) throws SAXException {
    }
}
