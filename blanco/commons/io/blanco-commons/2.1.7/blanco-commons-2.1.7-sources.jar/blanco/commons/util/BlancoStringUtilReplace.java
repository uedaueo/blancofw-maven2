/*
 * blanco Framework
 * Copyright (C) 2004-2009 IGA Tosiki
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 */
/*******************************************************************************
 * Copyright (c) 2009 IGA Tosiki, NTT DATA BUSINESS BRAINS Corp.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    IGA Tosiki (NTT DATA BUSINESS BRAINS Corp.) - initial API and implementation
 *******************************************************************************/
package blanco.commons.util;

import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;

/**
 * Contains the internal processing of string-related utilities in the blanco Framework.
 * 
 * This class is set to be private outside the package.
 * 
 * @author IGA Tosiki
 */
class BlancoStringUtilReplace {
    /**
     * Performs string substitution independent of regular expressions.
     * 
     * This method does not involve regular expressions, unlike java.lang.String.<br>
     * This is used for string substitution where you do not want regular expressions to work.
     * 
     * @param source
     *            The string before conversion.
     * @param replaceFrom
     *            Replacement source character.
     * @param replaceTo
     *            Replacement destination character.
     * @return The string after conversion.
     */
    public static final String replaceAll(final String source,
            final char replaceFrom, final char replaceTo) {
        if (source == null) {
            throw new IllegalArgumentException(
                    "The string substitution method was given a null value as the source string. Give it a non-null value.");
        }

        try {
            final StringReader reader = new StringReader(source);
            final StringWriter writer = new StringWriter();
            try {
                for (;;) {
                    int iRead = reader.read();
                    if (iRead < 0) {
                        break;
                    }
                    if (iRead == replaceFrom) {
                        iRead = replaceTo;
                    }
                    writer.write(iRead);
                }
                return writer.toString();
            } finally {
                reader.close();
                writer.close();
            }
        } catch (IOException ex) {
            throw new IllegalArgumentException(
                    "An unexpected exception occurred during processing of the string replacement method. The process will be aborted." + ex.toString());
        }
    }

    /**
     * Performs string substitution independent of regular expressions.
     * 
     * This method does not involve regular expressions, unlike java.lang.String.<br>
     * This is used for string substitution where you do not want regular expressions to work.
     * 
     * @param source
     *            The string before conversion.
     * @param replaceFrom
     *            Replacement source character.
     * @param replaceTo
     *            Replacement destination character.
     * @param isReplaceAll
     *            Whether to replace all.
     * @return The string after conversion.
     */
    public static final String replace(final String source,
            final String replaceFrom, final String replaceTo,
            final boolean isReplaceAll) {
        if (source == null) {
            throw new IllegalArgumentException(
                    "The string substitution method was given a null value as the source string. Give it a non-null value.");
        }
        if (replaceFrom == null) {
            throw new IllegalArgumentException(
                    "The method for string replacement was given null as the source character.");
        }
        if (replaceFrom.length() == 0) {
            throw new IllegalArgumentException(
                    "The method for string replacement was given a string of zero length as the source character.");
        }
        if (replaceTo == null) {
            throw new IllegalArgumentException(
                    "The method for string replacement has been given null as the destination character.");
        }

        final int indexFound = source.indexOf(replaceFrom);
        if (indexFound < 0) {
            return source;
        }
        final String pre = source.substring(0, indexFound);

        String suffix = source.substring(indexFound + replaceFrom.length());
        if (isReplaceAll) {
            final String suffixCheck = replace(suffix, replaceFrom, replaceTo,
                    false);
            if (suffix.equals(suffixCheck) == false) {
                suffix = replace(suffix, replaceFrom, replaceTo, true);
            }
        }

        return pre + replaceTo + suffix;
    }
}
