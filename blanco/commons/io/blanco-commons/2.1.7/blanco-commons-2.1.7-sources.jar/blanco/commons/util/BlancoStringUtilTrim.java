/*
 * blanco Framework
 * Copyright (C) 2004-2009 IGA Tosiki
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 */
/*******************************************************************************
 * Copyright (c) 2009 IGA Tosiki, NTT DATA BUSINESS BRAINS Corp.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    IGA Tosiki (NTT DATA BUSINESS BRAINS Corp.) - initial API and implementation
 *******************************************************************************/
package blanco.commons.util;

/**
 * Contains the internal processing of string-related utilities in the blanco Framework.
 * 
 * This class is set to be private outside the package.
 * 
 * @author IGA Tosiki
 */
class BlancoStringUtilTrim {
    /**
     * For the given string, if there are spaces on the left side, removes them.
     * 
     * Removes only single-byte spaces. Full-width whitespace is not processed.
     * 
     * @param originalString
     *            The string to be processed.
     * @return The string after half-width spaces have been trimmed.
     */
    public static final String trimLeft(final String originalString) {
        if (originalString == null) {
            throw new IllegalArgumentException(
                    "The string trimming (left) method has been given null as the original string. Give it a non-null value.");
        }
        int lastSpace = -1;
        for (int index = 0; index < originalString.length(); index++) {
            if (originalString.charAt(index) != ' ') {
                break;
            }
            lastSpace = index;
        }
        if (lastSpace < 0) {
            return originalString;
        }
        return originalString.substring(lastSpace + 1);
    }

    /**
     * For the given string, if there are spaces on the right side, removes them.
     * 
     * Removes only single-byte spaces. Full-width whitespace is not processed.
     * 
     * @param originalString
     *            The string to be processed.
     * @return The string after half-width spaces have been trimmed.
     */
    public static final String trimRight(final String originalString) {
        if (originalString == null) {
            throw new IllegalArgumentException(
                    "The string trimming (right) method has been given null as the original string. Give it a non-null value.");
        }
        int lastSpace = -1;
        for (int index = originalString.length() - 1; index >= 0; index--) {
            if (originalString.charAt(index) != ' ') {
                break;
            }
            lastSpace = index;
        }
        if (lastSpace < 0) {
            return originalString;
        }
        return originalString.substring(0, lastSpace);
    }

    /**
     * For the given string, if there are spaces on the right side or left side, removes them.
     * 
     * Removes only single-byte spaces. Full-width whitespace is not processed.
     * 
     * @param originalString
     *            The string to be processed.
     * @return The string after half-width spaces have been trimmed.
     */
    public static final String trim(final String originalString) {
        if (originalString == null) {
            throw new IllegalArgumentException(
                    "The string trimming (left and right) method has been given null as the original string. Give it a non-null value.");
        }
        return trimRight(trimLeft(originalString));
    }
}
