/*
 * blanco Framework
 * Copyright (C) 2004-2009 IGA Tosiki
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 */
/*******************************************************************************
 * Copyright (c) 2009 IGA Tosiki, NTT DATA BUSINESS BRAINS Corp.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    IGA Tosiki (NTT DATA BUSINESS BRAINS Corp.) - initial API and implementation
 *******************************************************************************/
package blanco.commons.io;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * File to stream input/output wrapper.<br>
 * Converts from java.io.File to input/output of java.io.XXPutStream.
 * 
 * @author IGA Tosiki
 */
public abstract class File2StreamWrapper {
    private InputStream inStream = null;

    private OutputStream outStream = null;

    /**
     * Converts input/output given by java.io.File to stream-based.<br>
     * If there is only one stream, give it to the execution point by a different route.
     * 
     * @param fileInput
     * @param fileOutput
     * @throws Exception
     */
    public File2StreamWrapper(final File fileInput, final File fileOutput)
            throws Exception {
        if (fileInput != null) {
            inStream = new BufferedInputStream(new FileInputStream(fileInput));
        }
        if (fileOutput != null) {
            outStream = new BufferedOutputStream(new FileOutputStream(
                    fileOutput));
        }
    }

    /**
     * Executes the actual input/output process.
     * 
     * @throws Exception
     *             If any exception occurs.
     */
    public void run() throws Exception {
        try {
            process(inStream, outStream);

            // When the process finishes successfully, flush is called to write the pending data.
            if (outStream != null) {
                outStream.flush();
            }
        } finally {
            // Always closes.
            closeStream();
        }
    }

    /**
     * The actual input/output process is described here.
     * 
     * @param inStream
     * @param outStream
     * @throws Exception
     */
    protected abstract void process(final InputStream inStream,
            final OutputStream outStream) throws Exception;

    /**
     * Closes the stream. This method is automatically called from within the constructor.
     * 
     * @throws IOException
     */
    protected void closeStream() throws IOException {
        try {
            if (inStream != null) {
                inStream.close();
                inStream = null;
            }
        } finally {
            if (outStream != null) {
                outStream.close();
                outStream = null;
            }
        }
    }
}
