/*
 * blanco Framework
 * Copyright (C) 2004-2009 IGA Tosiki
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 */
/*******************************************************************************
 * Copyright (c) 2009 IGA Tosiki, NTT DATA BUSINESS BRAINS Corp.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    IGA Tosiki (NTT DATA BUSINESS BRAINS Corp.) - initial API and implementation
 *******************************************************************************/
package blanco.commons.calc.parser.block;

/**
 * Represents a table column.
 * 
 * @author IGA Tosiki
 */
public class BlancoCalcParserTableColumn {

    private String _columnName = "name";

    private String[] _columnString = null;

    private int columnPosition = -1;

    /**
     * A constructor for a table column object.
     * 
     * @param name
     *            The column name.
     */
    public BlancoCalcParserTableColumn(final String name) {
        this._columnName = name;
    }

    /**
     * A constructor for an object related with the table.
     * 
     * @param name
     *            The column name.
     * @param columnString
     *            An array of the column strings.
     */
    public BlancoCalcParserTableColumn(final String name,
            final String[] columnString) {
        this._columnName = name;
        this._columnString = columnString;
    }

    /**
     * Gets the column name.
     * 
     * @return The column name.
     */
    public String getName() {
        return _columnName;
    }

    /**
     * Sets the column name.
     * 
     * @param arg
     *            The column name.
     */
    public void setName(final String arg) {
        _columnName = arg;
    }

    /**
     * Saves the column strings.
     * 
     * @param arg
     *            An array of the column strings.
     */
    public void setColumnString(final String[] arg) {
        _columnString = arg;
    }

    /**
     * Checks the string matches the start string.
     * 
     * @param arg
     *            A string to be checked.
     * @return Whether or not the string matches the start string.
     */
    public boolean isStartString(String arg) {
        final int columnStringLength = _columnString.length;
        for (int index = 0; index < columnStringLength; index++) {
            if (_columnString[index].equals(arg)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Gets the column number.
     * 
     * @return The column number.
     */
    public int getColumnPosition() {
        return columnPosition;
    }

    /**
     * Saves the column number.
     * 
     * @param arg
     *            The column number.
     */
    public void setColumnPosition(int arg) {
        columnPosition = arg;
    }
}
