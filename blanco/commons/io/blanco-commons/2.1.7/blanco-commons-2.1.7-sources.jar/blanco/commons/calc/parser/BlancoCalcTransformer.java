/*
 * blanco Framework
 * Copyright (C) 2004-2009 IGA Tosiki
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 */
/*******************************************************************************
 * Copyright (c) 2009 IGA Tosiki, NTT DATA BUSINESS BRAINS Corp.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    IGA Tosiki (NTT DATA BUSINESS BRAINS Corp.) - initial API and implementation
 *******************************************************************************/
package blanco.commons.calc.parser;

import java.io.*;

import java.util.*;

import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.sax.SAXResult;
import javax.xml.transform.sax.SAXSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.apache.poi.ss.usermodel.*;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.AttributesImpl;

import blanco.commons.calc.BlancoCalcUtil;
import blanco.commons.calc.parser.block.*;
import blanco.commons.calc.parser.concretesax.BlancoCalcTransformerDefHandler;
import blanco.commons.calc.parser.constants.BlancoCommonsConstantsConstants;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;

/**
 * This is a SAX2 parser for reading Calc.<br>
 * Enables the association of the start string with the entity name, etc.
 *
 * @author IGA Tosiki
 */
public class BlancoCalcTransformer extends AbstractBlancoCalcParser {
    /**
     * Whether the system is running in debug mode or not.
     */
    private static final boolean IS_DEBUG = true;

    /**
     * Gets the tabs of Excel you want to output. (added)
     */
    List <String> strTabSheetName = new ArrayList<String>();

    /**
     * A block that is held internally.
     */
    private List<AbstractBlancoCalcParserBlock> listBlock = new ArrayList<AbstractBlancoCalcParserBlock>();

    /**
     * Current block.
     */
    private AbstractBlancoCalcParserBlock currentBlock = null;

    /**
     * Current item during keymap.
     */
    private BlancoCalcTransformerPropertyKey currentKeyMapItem = null;

    private int waitForValueX = -1;

    private int waitForValueY = -1;

    private int waitForIteratorTitleSearchY = -1;

    private boolean isNoCellExistOnRow = true;

    private boolean isFirstIteratorRowItem = true;

    private static Workbook workbook = null;

    /**
     * It is currently the startup entry point for BlancoCalcTransformer.<br>
     * Example:
     * <code>BlancoCalcTransformer ./meta/BlancoCalcTransformerDef.xml ./meta/blancoCsvTemplate.xls ./output.xml</code>
     *
     * @param args
     *            0th:configuration file 1st:input file 2nd:output xml file 3rd:output excel file (added)
     */
    public static final void main(final String[] args) {
        if (args.length < 4) {
            System.out.println("usage: BlancoCalcTransformer Configuration-file Input-file Xml-file Excel-file");
            return;
        }

        InputStream inStreamDef = null;
        InputStream inStream = null;
        OutputStream outStream = null;
        OutputStream outStreamExcel = null;
        try {
            inStreamDef = new BufferedInputStream(new FileInputStream(
                    args[0]));
            inStream = new BufferedInputStream(new FileInputStream(
                    args[1]));
            outStream = new BufferedOutputStream(new FileOutputStream(
                    args[2]));
            outStreamExcel = new BufferedOutputStream(new FileOutputStream(
                    args[3]));
            new BlancoCalcTransformer().process(inStreamDef, inStream, outStream, outStreamExcel);
            outStream.flush();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (TransformerException e) {
            e.printStackTrace();
        } catch (InvalidFormatException e) {
            e.printStackTrace();
        } finally {
            if (inStreamDef != null) {
                try {
                    inStreamDef.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (inStream != null) {
                try {
                    inStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (outStream != null) {
                try {
                    outStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (outStreamExcel != null) {
                try {
                    outStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

    }

    /**
     * A constructor of BlancoCalcTransformer.
     */
    public BlancoCalcTransformer() {
    }

    /**
     * Converts the Excel file to XML based on the configuration information.
     *
     * @param inStreamDef
     *            Configuration information.
     * @param inStreamCalc
     *            Excel input stream.
     * @param outStreamXml
     *            XML output stream.
     * @param outStreamMeta
     *            Excel output stream.
     * @throws TransformerException
     */
    public void process(final InputStream inStreamDef,
            final InputStream inStreamCalc, final OutputStream outStreamXml, final OutputStream outStreamMeta)
            throws TransformerException, IOException, InvalidFormatException {

        final BlancoCalcTransformer parser = new BlancoCalcTransformer();


        parser.readDef(inStreamDef);

        final SAXSource source = new SAXSource(parser, new InputSource(
                inStreamCalc));

        final TransformerFactory tf = TransformerFactory.newInstance();
        Transformer transformer = tf.newTransformer();
        transformer.transform(source, new StreamResult(outStreamXml));

        // (added)
        // After parsing, exports to Excel here. xml will be exported by transformer.
        try{
            workbook.write(outStreamMeta);
        }catch(IOException e){
            System.out.println(e.toString());
        }finally{
            try {
                outStreamMeta.close();
            }catch(IOException e){
                System.out.println(e.toString());
            }
        }

    }

    /**
     * Loads the specified definition file.
     *
     * @param inStreamDef
     *            Input stream, This stream is not closed internally.
     * @throws TransformerException
     */
    public void readDef(final InputStream inStreamDef)
            throws TransformerException {
        SAXResult result = new SAXResult(new BlancoCalcTransformerDefHandler() {

            /**
             * An abstract class of the block.
             */
            private AbstractBlancoCalcParserBlock blockHeader = null;

            /**
             * Stores a start string.
             */
            private List<String> startStringList = new ArrayList<String>();

            /**
             * PropertyKey related.
             */
            private BlancoCalcTransformerPropertyKey propKey = null;

            /**
             * To create an array of Value.
             */
            private List<String> valueList = new ArrayList<String>();

            /**
             * To create an array of Value. (added)
             */
            private List<String> propertydataList = new ArrayList<String>();

            /**
             * To create an array of Value. (added)
             */
            private List<String> columndataList = new ArrayList<String>();
            //private Map<String,String> columndataList = new TreeMap<String,String>();
            /**
             * ValuMapping related.
             */
            private List<BlancoCalcParserValueMapping> valueMappingList = new ArrayList<BlancoCalcParserValueMapping>();

            private List<String> sourceList = new ArrayList<String>();

            private String result = null;

            /**
             * TableColumn related.
             */
            private BlancoCalcTransformerTableColumn tableColumn = null;

            public void startDocument() throws SAXException {
            }

            public void endDocument() throws SAXException {
            }

            public void startElementBlanco(String uri, String localName,
                    String qName, String attrVersion) throws SAXException {
                // System.out.println("start: blanco: version[" + attrVersion
                // + "]");
            }

            public void endElementBlanco(String uri, String localName,
                    String qName) throws SAXException {
            }

            public void charactersBlanco(char[] ch, int start, int length)
                    throws SAXException {
            }

            public void ignorableWhitespaceBlanco(char[] ch, int start,
                    int length) throws SAXException {
            }

            public void startElementTarget(String uri, String localName,
                    String qName, String attrName) throws SAXException {
            }

            public void endElementTarget(String uri, String localName,
                    String qName) throws SAXException {
            }

            public void charactersTarget(char[] ch, int start, int length)
                    throws SAXException {
            }

            public void ignorableWhitespaceTarget(char[] ch, int start,
                    int length) throws SAXException {
            }

            @Override
            public void startElementBlancocalcparser(String uri, String localName, String qName, String attrName) throws SAXException {

            }

            @Override
            public void endElementBlancocalcparser(String uri, String localName, String qName) throws SAXException {

            }

            @Override
            public void charactersBlancocalcparser(char[] ch, int start, int length) throws SAXException {

            }

            @Override
            public void ignorableWhitespaceBlancocalcparser(char[] ch, int start, int length) throws SAXException {

            }

            public void startElementPropertyblock(String uri, String localName,
                    String qName, String attrName, String attrWaitY)
                    throws SAXException {
                // Creates a new block.
                blockHeader = new BlancoCalcTransformerPropertyBlock(attrName);
                blockHeader.setSearchRangeY(Integer.parseInt(attrWaitY));

                add(blockHeader);
            }

            public void endElementPropertyblock(String uri, String localName,
                    String qName) throws SAXException {
                final String[] startString = new String[startStringList.size()];
                startStringList.toArray(startString);
                startStringList.clear();

                final BlancoCalcParserValueMapping valuemappings[] = new BlancoCalcParserValueMapping[valueMappingList
                        .size()];
                valueMappingList.toArray(valuemappings);
                valueMappingList.clear();

                // End of the block.
                blockHeader.setStartString(startString);
                blockHeader.setValueMapping(valuemappings);
            }

            public void charactersPropertyblock(char[] ch, int start, int length)
                    throws SAXException {
            }

            public void ignorableWhitespacePropertyblock(char[] ch, int start,
                    int length) throws SAXException {
            }

            public void startElementStartstring(String uri, String localName,
                    String qName) throws SAXException {
            }

            public void endElementStartstring(String uri, String localName,
                    String qName) throws SAXException {
            }

            public void charactersStartstring(char[] ch, int start, int length)
                    throws SAXException {
                startStringList.add(new String(ch, start, length));
            }

            public void ignorableWhitespaceStartstring(char[] ch, int start,
                    int length) throws SAXException {
            }

            public void startElementPropertykey(String uri, String localName,
                    String qName, String attrName, String attrWaitX)
                    throws SAXException {
                propKey = new BlancoCalcTransformerPropertyKey(attrName);
                propKey.setSearchRangeX(Integer.parseInt(attrWaitX));

                ((BlancoCalcTransformerPropertyBlock) blockHeader).add(propKey);
            }

            public void endElementPropertykey(String uri, String localName,
                    String qName) throws SAXException {
                final String[] values = new String[valueList.size()];
                valueList.toArray(values);
                valueList.clear();
                propKey.setKeyString(values);

                // added
                final String[] data = new String[propertydataList.size()];
                propertydataList.toArray(data);
                propertydataList.clear();
                propKey.setPropertyData(data);

            }

            public void charactersPropertykey(char[] ch, int start, int length)
                    throws SAXException {
            }

            public void ignorableWhitespacePropertykey(char[] ch, int start,
                    int length) throws SAXException {
            }

            public void startElementValue(String uri, String localName,
                    String qName) throws SAXException {
            }

            // added
            public void startElementPropertyData(String uri, String localName,
                                          String qName) throws SAXException {
            }

            // added
            public void startElementColumnData(String uri, String localName,
                                                 String qName) throws SAXException {
            }

            public void endElementValue(String uri, String localName,
                    String qName) throws SAXException {
            }

            // added
            public void endElementPropertyData(String uri, String localName,
                                        String qName) throws SAXException {
            }

            // added
            public void endElementColumnData(String uri, String localName,
                                               String qName) throws SAXException {
            }

            public void charactersValue(char[] ch, int start, int length)
                    throws SAXException {
                valueList.add(new String(ch, start, length));
            }

            // added
            public void charactersPropertyData(char[] ch, int start, int length)
                    throws SAXException {
                propertydataList.add(new String(ch, start, length));
            }

            // added
            public void charactersColumnData(char[] ch, int start, int length)
                    throws SAXException {
                columndataList.add(new String(ch, start, length));
            }

            public void ignorableWhitespaceValue(char[] ch, int start,
                    int length) throws SAXException {
            }

            // added
            public void ignorableWhitespacePropertyData(char[] ch, int start,
                                                 int length) throws SAXException {
            }

            // added
            public void ignorableWhitespaceColumnData(char[] ch, int start,
                                                        int length) throws SAXException {
            }

            public void startElementValuemapping(String uri, String localName,
                    String qName) throws SAXException {
            }

            public void endElementValuemapping(String uri, String localName,
                    String qName) throws SAXException {
                final String[] sources = new String[sourceList.size()];
                sourceList.toArray(sources);
                sourceList.clear();

                valueMappingList.add(new BlancoCalcParserValueMapping(sources,
                        result));
                result = null;
            }

            public void charactersValuemapping(char[] ch, int start, int length)
                    throws SAXException {
            }

            public void ignorableWhitespaceValuemapping(char[] ch, int start,
                    int length) throws SAXException {
            }

            public void startElementResult(String uri, String localName,
                    String qName) throws SAXException {
            }

            public void endElementResult(String uri, String localName,
                    String qName) throws SAXException {
            }

            public void charactersResult(char[] ch, int start, int length)
                    throws SAXException {
                result = new String(ch, start, length);
            }

            public void ignorableWhitespaceResult(char[] ch, int start,
                    int length) throws SAXException {
            }

            public void startElementSource(String uri, String localName,
                    String qName) throws SAXException {
            }

            public void endElementSource(String uri, String localName,
                    String qName) throws SAXException {
            }

            public void charactersSource(char[] ch, int start, int length)
                    throws SAXException {
                sourceList.add(new String(ch, start, length));
            }

            public void ignorableWhitespaceSource(char[] ch, int start,
                    int length) throws SAXException {
            }

            public void startElementTableblock(String uri, String localName,
                    String qName, String attrName, String attrWaitY,
                    String attrTitleheight, String attrRowname)
                    throws SAXException {

                // Creates a new block.
                blockHeader = new BlancoCalcTransformerTableBlock(attrName);
                blockHeader.setSearchRangeY(Integer.parseInt(attrWaitY));
                ((BlancoCalcTransformerTableBlock) blockHeader)
                        .setSearchRangeForTitleY(Integer
                                .parseInt(attrTitleheight));
                ((BlancoCalcTransformerTableBlock) blockHeader)
                        .setRowName(attrRowname);
                add(blockHeader);
            }

            public void endElementTableblock(String uri, String localName,
                    String qName) throws SAXException {
                final String[] startString = new String[startStringList.size()];
                startStringList.toArray(startString);
                startStringList.clear();

                final BlancoCalcParserValueMapping valuemappings[] = new BlancoCalcParserValueMapping[valueMappingList
                        .size()];
                valueMappingList.toArray(valuemappings);
                valueMappingList.clear();

                // End of the block.
                blockHeader.setStartString(startString);
                blockHeader.setValueMapping(valuemappings);
            }

            public void charactersTableblock(char[] ch, int start, int length)
                    throws SAXException {
            }

            public void ignorableWhitespaceTableblock(char[] ch, int start,
                    int length) throws SAXException {
            }

            public void startElementTablecolumn(String uri, String localName,
                    String qName, String attrName) throws SAXException {
                tableColumn = new BlancoCalcTransformerTableColumn(attrName);
            }

            public void endElementTablecolumn(String uri, String localName,
                    String qName) throws SAXException {
                final String[] values = new String[valueList.size()];
                valueList.toArray(values);
                valueList.clear();
                tableColumn.setColumnString(values);

                // added
                final String[] data = new String[columndataList.size()];
                columndataList.toArray(data);
                columndataList.clear();
                tableColumn.setColumnData(data);

                ((BlancoCalcTransformerTableBlock) blockHeader).add(tableColumn);
            }

            public void charactersTablecolumn(char[] ch, int start, int length)
                    throws SAXException {
            }

            public void ignorableWhitespaceTablecolumn(char[] ch, int start,
                    int length) throws SAXException {
            }
        });

        final TransformerFactory tf = TransformerFactory.newInstance();
        Transformer transformer = tf.newTransformer();
        transformer.transform(new StreamSource(inStreamDef), result);
    }

    /**
     * Performs parsing.
     *
     * @param inputSource
     *            Input source to be parsed.
     * @see org.xml.sax.XMLReader#parse(org.xml.sax.InputSource)
     */
    public final void parse(final InputSource inputSource) throws IOException,
            SAXException {

        System.out.println("BlancoCalcTransformer#:parse");


        InputStream inStream = null;
        try {
            if (inputSource.getByteStream() != null) {
                // OK. We will continue with the process.
            } else if (inputSource.getSystemId() != null
                    && inputSource.getSystemId().length() > 0) {
                inStream = new FileInputStream(inputSource.getSystemId());
                inputSource.setByteStream(inStream);
            } else {
                throw new IOException("The specified InputSource cannot be processed.");
            }
            workbook = WorkbookFactory.create(inputSource.getByteStream());

            // Gets the tab of the Excel file you want to output.
            for (int index = 0; index < listBlock.size(); index++) {

                AbstractBlancoCalcParserBlock blockItem = (AbstractBlancoCalcParserBlock) listBlock
                        .get(index);

                if (blockItem instanceof BlancoCalcTransformerPropertyBlock) {

                    if(blockItem.getName().equals(BlancoCommonsConstantsConstants.SHEETNAME_META2XML)){

                        strTabSheetName.add(blockItem.getName());
                        System.out.println(blockItem.getName());

                    }
                    if(blockItem.getName().startsWith(BlancoCommonsConstantsConstants.SHEET_PREFIX_PROPERTY)){

                        strTabSheetName.add(blockItem.getName().substring(22));
                        System.out.println(blockItem.getName().substring(22));

                    }

                }
            }

            // Renames sheet tabs in Excel.
            for (int indexSheet = 0; indexSheet < strTabSheetName.size(); indexSheet++) {
                if(indexSheet < workbook.getNumberOfSheets()){
                    Sheet sheet = workbook.getSheetAt(indexSheet);
                    // If it's not meta2xml in blancotelegram, changes it.
                    if(sheet.getSheetName().equals(BlancoCommonsConstantsConstants.SHEETNAME_TEMPLATE) && !strTabSheetName.get(indexSheet).equals(BlancoCommonsConstantsConstants.SHEETNAME_META2XML)){
                        workbook.setSheetName(indexSheet, strTabSheetName.get(indexSheet));
                    }
                }else {
                    // Copies and adds the previous sheet if it needs to add more tabs in Excel.
                    workbook.cloneSheet(indexSheet-1);
                    // Name change.
                    workbook.setSheetName(indexSheet, strTabSheetName.get(indexSheet));
                }
            }


            // This is where the actual parsing begins.
            // This time, it will parse and insert the interrupt value at the same time.
            parseWorkbook(workbook);


        } catch (IOException e) {
            e.printStackTrace();
            throw new IOException("An unexpected exception has occurred: " + e.toString());
//        } catch (InvalidFormatException e) {
//            e.printStackTrace();
//            throw new IOException("An unexpected exception has occurred: " + e.toString());
        } finally {
            // Not done here. → In process().
//            if (workbook != null) {
//                workbook.close();
//            }

            // The InputSource is closed externally.
            // Only explicitly opened streams will be processed here.
            if (inStream != null) {
                inStream.close();
            }
        }
    }

    /**
     * Adds a block.
     *
     * @param block
     *            The block object to be added.
     */
    public void add(final AbstractBlancoCalcParserBlock block) {
        listBlock.add(block);
    }

    protected void startSheet(String sheetName) throws SAXException {
        if (IS_DEBUG)
            System.out.println("Processes the sheet [" + sheetName + "]...");
    }

    protected void endSheet(Sheet sheet) throws SAXException {
        if (currentBlock != null) {
            getContentHandler().endElement("", currentBlock.getName(),
                    currentBlock.getName());
            currentBlock = null;
        }

        waitForValueX = -1;
        waitForValueY = -1;
        waitForIteratorTitleSearchY = -1;
        currentKeyMapItem = null;
    }

    protected void startRow(int row) throws SAXException {
        isNoCellExistOnRow = true;
        isFirstIteratorRowItem = true;
    }
    protected void endRow(int row) throws SAXException{

    };

    protected void endRow(final Sheet sheet,int row) throws SAXException {

        waitForValueX = -1;

        if (waitForIteratorTitleSearchY >= 0) {
            // In the case of a title row search, enters here.
            // Whatever the state, the countdown will be performed.
            waitForIteratorTitleSearchY--;
        }

        if (currentBlock instanceof BlancoCalcTransformerTableBlock) {
            if (isFirstIteratorRowItem == false) {
                final BlancoCalcTransformerTableBlock blockLook = (BlancoCalcTransformerTableBlock) currentBlock;
                if (blockLook.getRowName() != null
                        && blockLook.getRowName().length() > 0) {
                    // Adds entities to repeating items in a block.
                    getContentHandler().endElement("", blockLook.getRowName(),
                            blockLook.getRowName());
                }
            }
        }

        // If none of the cell values are found in that row.
        if (isNoCellExistOnRow) {
            if (waitForValueY >= 0) {
                waitForValueY--;
            }
            if (waitForValueY <= 0) {
                if (currentBlock != null) {

                    // Table block value insertion. (added)
                    if (currentBlock instanceof BlancoCalcTransformerTableBlock) {

                        final BlancoCalcTransformerTableBlock blockLook = (BlancoCalcTransformerTableBlock) currentBlock;

                        TreeMap <Integer,LinkedHashMap<String, String>> mapTableData = new TreeMap <Integer,LinkedHashMap<String, String>>();

                        for (int intColumn = 0; intColumn < blockLook.getListSize(); intColumn++) {

                            final BlancoCalcTransformerTableColumn item = blockLook
                                    .findByColumnPosition(intColumn + 1); // ColumnPosition starts from 1.

                            //System.out.println("BlancoCalcTransformer size:" + item.getColumnData().length);
                            for(int i = 0; i < item.getColumnData().length; i++){
                                Row wbRow = sheet.getRow(row + i);
                                Cell wbCell = wbRow.getCell(intColumn);
                                String itemData = item.getColumnDataByIndex(i);
                                System.out.println("BlancoCalcTransformer data:" + itemData);
                                // excel output.
                                if(isNum(itemData)) {
                                    // For Integer.
                                    wbCell.setCellValue(Integer.valueOf(itemData).intValue());
                                }else if(isDouble(itemData)){
                                    // For Double.
                                    wbCell.setCellValue(Double.parseDouble(itemData));
                                }else{
                                    wbCell.setCellValue(itemData);
                                }

                                // Saves it for the xml output process.
                                if(!mapTableData.containsKey(i)){
                                    mapTableData.put(i, new LinkedHashMap<String, String>());
                                }
                                mapTableData.get(i).put(item.getName(), itemData);

                            }
                            //System.out.println("BlancoCalcTransformer:" + currentKeyMapItem.getName() + "(" + row + "," + column + ",test)");
                        }
                        // Saves it for the xml output process.
                        if(!mapTableData.isEmpty()){

                            for (int intRowData = 0; intRowData < mapTableData.size(); intRowData++) {
                                if (blockLook.getRowName() != null
                                        && blockLook.getRowName().length() > 0) {
                                    // Add entities to repeating items in a block.
                                    getContentHandler().startElement("",
                                            blockLook.getRowName(),
                                            blockLook.getRowName(),
                                            new AttributesImpl());
                                }
                                Iterator entries = mapTableData.get(intRowData).entrySet().iterator();
                                while (entries.hasNext()) {
                                    Map.Entry entry= (Map.Entry) entries.next();
                                    String keyName = (String) entry.getKey();
                                    String valName = (String) entry.getValue();
                                    // Some kind of memory processing here.
                                    saveNode(keyName, valName);
                                }
                                if (blockLook.getRowName() != null
                                        && blockLook.getRowName().length() > 0) {
                                    // Add entities to repeating items in a block.
                                    getContentHandler().endElement("", blockLook.getRowName(),
                                            blockLook.getRowName());
                                }
                            }
                        }
                    }
                    if (IS_DEBUG)
                        System.out.println("Ends the block [" + currentBlock.getName()
                                + "].");
                    getContentHandler().endElement("", currentBlock.getName(),
                            currentBlock.getName());

                    currentBlock = null;
                }
            }
        }

        if (currentBlock instanceof BlancoCalcTransformerPropertyBlock) {
            currentKeyMapItem = null;
        }
    }

    static boolean isNum(String number) {
        try {
            Integer.parseInt(number);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    static boolean isDouble(String number) {
        try {
            Double.parseDouble(number);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    protected void startColumn(int column) throws SAXException {
    }

    protected void endColumn(int column) throws SAXException {
        if (waitForValueX >= 0) {
            waitForValueX--;
        }

        if (currentBlock == null) {
            return;
        }

        if (waitForValueX < 0) {
            if (currentBlock instanceof BlancoCalcTransformerPropertyBlock) {
                currentKeyMapItem = null;
            }
        }
    }

    protected void endColumn(final int column, final int row,
                             final Cell cell) throws SAXException {
        if (waitForValueX >= 0) {
            waitForValueX--;
        }

        if (currentBlock == null) {
            return;
        }

        if (waitForValueX < 0) {
            if (currentBlock instanceof BlancoCalcTransformerPropertyBlock) {

                // Property block value insertion. (added)
                // Assigns an interrupt value to a Cell when a key is present.
                if(currentKeyMapItem != null){

                    if(isNum(currentKeyMapItem.getConcatenatedPropertyData())) {
                        // For Integer.
                        cell.setCellValue(Integer.valueOf(currentKeyMapItem.getConcatenatedPropertyData()).intValue());
                    }else if(isDouble(currentKeyMapItem.getConcatenatedPropertyData())){
                        // For Double.
                        cell.setCellValue(Double.parseDouble(currentKeyMapItem.getConcatenatedPropertyData()));
                    }else{
                        cell.setCellValue(currentKeyMapItem.getConcatenatedPropertyData());
                    }

                    //System.out.println("BlancoCalcTransformer:" + currentKeyMapItem.getName() + "(" + row + "," + column + "," + currentKeyMapItem.getConcatenatedPropertyData() + ")");
                    // Some kind of memory processing here.
                    saveNode(currentKeyMapItem.getName(), currentKeyMapItem.getConcatenatedPropertyData());

                }

                currentKeyMapItem = null;
            }
        }
    }

    @Override
    protected void fireCell(final int column, final int row,final String cellValue) throws SAXException {}

    /**
     * Called when a cell is parsed.
     *
     * @param column
     *            Called with 1 origin here.
     * @param row
     *            Called with 1 origin here.
     * @param cellValue
     *            Cell value.
     * @param strSheetname
     *            Current sheet name.
     * @throws SAXException
     *             If a SAX exception occurs.
     */
    @SuppressWarnings("deprecation")
    protected void fireCell(final int column, final int row,
                            final String cellValue,
                            final String strSheetname
                            ) throws SAXException {

        // Returns if there is no cell value.
        if (cellValue.length() == 0) {
            return;
        }

        // At least we found the entity.
        isNoCellExistOnRow = false;

        // The working block (block in the xml definition file) when Excel is searched and found by currentBlock = the start keyword (startstring tag).
        if (currentBlock != null) {
            // If the cell value is an end keyword (endstring tag)
            if (currentBlock.isEndString(cellValue)) {
                // Now that we've found the "work", starts analyzing the working block.
                if (IS_DEBUG)
                    System.out.println("Found the forced termination string (" + cellValue + ") of block [" + currentBlock.getName()
                            + "].");

                getContentHandler().endElement("", currentBlock.getName(),
                        currentBlock.getName());

                // Discards the current block.
                currentBlock = null;

            }
        }

        // Saves the value.
        if (currentBlock != null) {
            // If the property block
            if (currentBlock instanceof BlancoCalcTransformerPropertyBlock) {
                // If the key is found
                if (currentKeyMapItem != null) {
                    // Reads the cell value and maps it to a different value.
                    // If no mapping was done, inputs value itself.
                    final String value = BlancoCalcParserValueMapping.mapping(
                            cellValue, currentBlock.getValueMapping());
                    if (IS_DEBUG)
                        System.out.println("Key [" + currentKeyMapItem.getName()
                                + "] = Value [" + value + "]");
                    // Some kind of memory processing here.
                    saveNode(currentKeyMapItem.getName(), value);
                    return;
                }
                // When the table block
            } else if (currentBlock instanceof BlancoCalcTransformerTableBlock) {
                if (waitForIteratorTitleSearchY <= 0) {
                    final BlancoCalcTransformerTableBlock blockLook = (BlancoCalcTransformerTableBlock) currentBlock;
                    final BlancoCalcTransformerTableColumn item = blockLook
                            .findByColumnPosition(column);
                    if (item == null) {
                        if (IS_DEBUG)
                            System.out
                                    .println("The corresponding column (" + column + ") cannot be found.");
                        return;
                    }

                    if (isFirstIteratorRowItem) {
                        isFirstIteratorRowItem = false;
                        if (blockLook.getRowName() != null
                                && blockLook.getRowName().length() > 0) {
                            // Adds entities to repeating items in a block.
                            getContentHandler().startElement("",
                                    blockLook.getRowName(),
                                    blockLook.getRowName(),
                                    new AttributesImpl());
                        }
                    }

                    // Some kind of memory processing here.
                    final String value = BlancoCalcParserValueMapping.mapping(
                            cellValue, blockLook.getValueMapping());
                    if (IS_DEBUG)
                        System.out.println("Column [" + item.getName() + "] = Value ["
                                + value + "]");
                    saveNode(item.getName(), value);
                    return;
                }
            }
        }

        if (IS_DEBUG)
            System.out.println("  (" + BlancoCalcUtil.columnToLabel(column)
                    + row + ")" + cellValue);

        // Found the "work".
        for (int index = 0; index < listBlock.size(); index++) {
            AbstractBlancoCalcParserBlock blockItem = (AbstractBlancoCalcParserBlock) listBlock
                    .get(index);
            if(blockItem.getName().equals(strSheetname)
                    || blockItem.getName().equals(BlancoCommonsConstantsConstants.SHEET_PREFIX_PROPERTY + strSheetname)
                    || blockItem.getName().equals(BlancoCommonsConstantsConstants.SHEET_PREFIX_TABLE + strSheetname)) { // (added)

                if (blockItem.isStartString(cellValue)) {
                    // Now that we've found the "work", starts analyzing the working block.
                    if (IS_DEBUG)
                        System.out.println("Found the block [" + blockItem.getName() + "].");

                    final AttributesImpl attrImpl = new AttributesImpl();
                    getContentHandler().startElement("", blockItem.getName(),
                            blockItem.getName(), attrImpl);

                    // Stores the current block.
                    currentBlock = blockItem;
                    waitForValueY = currentBlock.getSearchRangeY();
                    if (currentBlock instanceof BlancoCalcTransformerTableBlock) {
                        BlancoCalcTransformerTableBlock block = (BlancoCalcTransformerTableBlock) currentBlock;
                        waitForIteratorTitleSearchY = block
                                .getSearchRangeForTitleY();
                    }
                }
            }
        }

        if (currentBlock == null) {
            return;
        }

        // Verifies the presence of cell values in the key definitions of property blocks or table blocks.
        if (currentBlock instanceof BlancoCalcTransformerPropertyBlock) {
            // Performs the process of searching for the key.
            final BlancoCalcTransformerPropertyKey item = ((BlancoCalcTransformerPropertyBlock) currentBlock)
                    .findByStartString(cellValue);
            if (item != null) {
                currentKeyMapItem = item;
                waitForValueX = item.getSearchRangeX();
            }
        } else if (currentBlock instanceof BlancoCalcTransformerTableBlock) {
            final BlancoCalcTransformerTableBlock block = (BlancoCalcTransformerTableBlock) currentBlock;

            // Performs the process of searching for the title.
            final BlancoCalcTransformerTableColumn item = (block)
                    .findByTitleString(cellValue);
            if (item != null) {
                // Successfully searched for title position.
                if (IS_DEBUG)
                    System.out.println("Column (" + column + ") is a key [" + cellValue
                            + "].");
                item.setColumnPosition(column);
            } else {
                if (IS_DEBUG)
                    System.out.println("The key [" + cellValue
                            + "] of column (" + column + ") is not found among the registered ones.");
            }
        }
    }

    public void parseSheet(final Sheet sheet) throws SAXException {
        // Sheet elements are handled by the upper class.
        System.out.println("ama debug:parseSheet:" + sheet.getSheetName());

        AttributesImpl attrImpl = new AttributesImpl();
        attrImpl.addAttribute("", "name", "name", "CDATA", sheet.getSheetName());
        getContentHandler().startElement("",
                (String) getProperty(URI_PROPERTY_NAME_SHEET),
                (String) getProperty(URI_PROPERTY_NAME_SHEET), attrImpl);

        startSheet(sheet.getSheetName());

        // getLastRowNum() counts from 0, so it should be +1.
        int maxRows = sheet.getLastRowNum() + 1;

        for (int row = 0; row < maxRows; row++) {
            startRow(row + 1);
            Row line = sheet.getRow(row);
            if (line != null) {
                for (int column = 0; column < line.getLastCellNum(); column++) {

                    startColumn(column + 1);
                    Cell cell = line.getCell(column);
                    // The content will be delivered without trim().
                    String value = getCellValue(cell);

                    fireCell(column + 1, row + 1, value,sheet.getSheetName());
                    endColumn(column , row , cell);
                }
            }
            endRow(sheet, row);
        }

        endSheet(sheet);

        // Sheet elements are handled by the upper class.
        getContentHandler().endElement("",
                (String) getProperty(URI_PROPERTY_NAME_SHEET),
                (String) getProperty(URI_PROPERTY_NAME_SHEET));
    }


}
