package blanco.commons.calc.parser.task;

import java.io.IOException;

import blanco.commons.calc.parser.task.valueobject.BlancoCommonsProcessInput;

/**
 * Batch process class [BlancoCommonsBatchProcess].
 *
 * <P>Example of a batch processing call.</P>
 * <code>
 * java -classpath (classpath) blanco.commons.calc.parser.task.BlancoCommonsBatchProcess -help
 * </code>
 */
public class BlancoCommonsBatchProcess {
    /**
     * Normal end.
     */
    public static final int END_SUCCESS = 0;

    /**
     * Termination due to abnormal input. In the case that java.lang.IllegalArgumentException is raised internally.
     */
    public static final int END_ILLEGAL_ARGUMENT_EXCEPTION = 7;

    /**
     * Termination due to I/O exception. In the case that java.io.IOException is raised internally.
     */
    public static final int END_IO_EXCEPTION = 8;

    /**
     * Abnormal end. In the case that batch process fails to start or java.lang.Error or java.lang.RuntimeException is raised internally.
     */
    public static final int END_ERROR = 9;

    /**
     * The entry point when executed from the command line.
     *
     * @param args Agruments inherited from the console.
     */
    public static final void main(final String[] args) {
        final BlancoCommonsBatchProcess batchProcess = new BlancoCommonsBatchProcess();

        // Arguments for batch process.
        final BlancoCommonsProcessInput input = new BlancoCommonsProcessInput();

        boolean isNeedUsage = false;
        boolean isFieldInStreamProcessed = false;
        boolean isFieldOutStreamProcessed = false;
        boolean isFieldInStreamDefProcessed = false;
        boolean isFieldOutStreamExcelProcessed = false;

        // Parses command line arguments.
        for (int index = 0; index < args.length; index++) {
            String arg = args[index];
            if (arg.startsWith("-verbose=")) {
                input.setVerbose(Boolean.valueOf(arg.substring(9)).booleanValue());
            } else if (arg.startsWith("-inStream=")) {
                input.setInStream(arg.substring(10));
                isFieldInStreamProcessed = true;
            } else if (arg.startsWith("-outStream=")) {
                input.setOutStream(arg.substring(11));
                isFieldOutStreamProcessed = true;
            } else if (arg.startsWith("-inStreamDef=")) {
                input.setInStreamDef(arg.substring(13));
                isFieldInStreamDefProcessed = true;
            } else if (arg.startsWith("-outStreamExcel=")) {
                input.setOutStreamExcel(arg.substring(16));
                isFieldOutStreamExcelProcessed = true;
            } else if (arg.startsWith("-metadir=")) {
                input.setMetadir(arg.substring(9));
            } else if (arg.startsWith("-targetdir=")) {
                input.setTargetdir(arg.substring(11));
            } else if (arg.startsWith("-sheetType=")) {
                input.setSheetType(arg.substring(11));
            } else if (arg.equals("-?") || arg.equals("-help")) {
                usage();
                System.exit(END_SUCCESS);
            } else {
                System.out.println("BlancoCommonsBatchProcess: The input parameter[" + arg + "] was ignored.");
                isNeedUsage = true;
            }
        }

        if (isNeedUsage) {
            usage();
        }

        if( isFieldInStreamProcessed == false) {
            System.out.println("BlancoCommonsBatchProcess: Failed to start the process. The required field value[inStream] in the input parameter[input] is not set to a value.");
            System.exit(END_ILLEGAL_ARGUMENT_EXCEPTION);
        }
        if( isFieldOutStreamProcessed == false) {
            System.out.println("BlancoCommonsBatchProcess: Failed to start the process. The required field value[outStream] in the input parameter[input] is not set to a value.");
            System.exit(END_ILLEGAL_ARGUMENT_EXCEPTION);
        }
        if( isFieldInStreamDefProcessed == false) {
            System.out.println("BlancoCommonsBatchProcess: Failed to start the process. The required field value[inStreamDef] in the input parameter[input] is not set to a value.");
            System.exit(END_ILLEGAL_ARGUMENT_EXCEPTION);
        }
        if( isFieldOutStreamExcelProcessed == false) {
            System.out.println("BlancoCommonsBatchProcess: Failed to start the process. The required field value[outStreamExcel] in the input parameter[input] is not set to a value.");
            System.exit(END_ILLEGAL_ARGUMENT_EXCEPTION);
        }

        int retCode = batchProcess.execute(input);

        // Returns the exit code.
        // Note: Please note that calling System.exit().
        System.exit(retCode);
    }

    /**
     * A method to describe the specific batch processing contents.
     *
     * This method is used to describe the actual process.
     *
     * @param input Input parameters for batch process.
     * @return The exit code for batch process. Returns one of the values END_SUCCESS, END_ILLEGAL_ARGUMENT_EXCEPTION, END_IO_EXCEPTION, END_ERROR
     * @throws IOException If an I/O exception occurs.
     * @throws IllegalArgumentException If an invalid input value is found.
     */
    public int process(final BlancoCommonsProcessInput input) throws IOException, IllegalArgumentException {
        // Checks the input parameters.
        validateInput(input);

        // If you get a compile error at this point, You may be able to solve it by implementing a BlancoCommonsProcess interface and creating an BlancoCommonsProcessImpl class in package blanco.commons.calc.parser.task.
        final BlancoCommonsProcess process = new BlancoCommonsProcessImpl();

        // Executes the main body of the process.
        final int retCode = process.execute(input);

        return retCode;
    }

    /**
     * The entry point for instantiating a class and running a batch.
     *
     * This method provides the following specifications.
     * <ul>
     * <li>Checks the contents of the input parameters of the method.
     * <li>Catches exceptions such as IllegalArgumentException, RuntimeException, Error, etc. and converts them to return values.
     * </ul>
     *
     * @param input Input parameters for batch process.
     * @return The exit code for batch process. Returns one of the values END_SUCCESS, END_ILLEGAL_ARGUMENT_EXCEPTION, END_IO_EXCEPTION, END_ERROR
     * @throws IllegalArgumentException If an invalid input value is found.
     */
    public final int execute(final BlancoCommonsProcessInput input) throws IllegalArgumentException {
        try {
            // Executes the main body of the batch process.
            int retCode = process(input);

            return retCode;
        } catch (IllegalArgumentException ex) {
            System.out.println("BlancoCommonsBatchProcess: An input exception has occurred. Abort the batch process.:" + ex.toString());
            // Termination due to abnormal input.
            return END_ILLEGAL_ARGUMENT_EXCEPTION;
        } catch (IOException ex) {
            System.out.println("BlancoCommonsBatchProcess: An I/O exception has occurred. Abort the batch process.:" + ex.toString());
            // Termination due to abnormal input.
            return END_IO_EXCEPTION;
        } catch (RuntimeException ex) {
            System.out.println("BlancoCommonsBatchProcess: A runtime exception has occurred. Abort the batch process.:" + ex.toString());
            ex.printStackTrace();
            // Abnormal end.
            return END_ERROR;
        } catch (Error er) {
            System.out.println("BlancoCommonsBatchProcess: A runtime exception has occurred. Abort the batch process.:" + er.toString());
            er.printStackTrace();
            // Abnormal end.
            return END_ERROR;
        }
    }

    /**
     * A method to show an explanation of how to use this batch processing class on the stdout.
     */
    public static final void usage() {
        System.out.println("BlancoCommonsBatchProcess: Usage:");
        System.out.println("  java blanco.commons.calc.parser.task.BlancoCommonsBatchProcess -verbose=value1 -inStream=value2 -outStream=value3 -inStreamDef=value4 -outStreamExcel=value5 -metadir=value6 -targetdir=value7 -sheetType=value8");
        System.out.println("    -verbose");
        System.out.println("      explanation[verboseモードで動作させるかどうか。]");
        System.out.println("      type[boolean]");
        System.out.println("      default value[false]");
        System.out.println("    -inStream");
        System.out.println("      explanation[ひな形メタファイル]");
        System.out.println("      type[string]");
        System.out.println("      a required parameter");
        System.out.println("    -outStream");
        System.out.println("      explanation[出力される中間xml]");
        System.out.println("      type[string]");
        System.out.println("      a required parameter");
        System.out.println("    -inStreamDef");
        System.out.println("      explanation[ひな形定義xml]");
        System.out.println("      type[string]");
        System.out.println("      a required parameter");
        System.out.println("    -outStreamExcel");
        System.out.println("      explanation[出力されるひな形メタファイル]");
        System.out.println("      type[string]");
        System.out.println("      a required parameter");
        System.out.println("    -metadir");
        System.out.println("      explanation[メタディレクトリ]");
        System.out.println("      type[string]");
        System.out.println("      default value[blanco]");
        System.out.println("    -targetdir");
        System.out.println("      explanation[出力先フォルダを指定します。無指定の場合にはカレント直下のblancoを用います。]");
        System.out.println("      type[string]");
        System.out.println("      default value[blanco]");
        System.out.println("    -sheetType");
        System.out.println("      type[string]");
        System.out.println("      default value[java]");
        System.out.println("    -? , -help");
        System.out.println("      explanation[show the usage.]");
    }

    /**
     * A method to check the validity of input parameters for this batch processing class.
     *
     * @param input Input parameters for batch process.
     * @throws IllegalArgumentException If an invalid input value is found.
     */
    public void validateInput(final BlancoCommonsProcessInput input) throws IllegalArgumentException {
        if (input == null) {
            throw new IllegalArgumentException("BlancoBatchProcessBatchProcess: Failed to start the process. The input parameter[input] was given as null.");
        }
        if (input.getInStream() == null) {
            throw new IllegalArgumentException("BlancoCommonsBatchProcess: Failed to start the process. The required field value[inStream] in the input parameter[input] is not set to a value.");
        }
        if (input.getOutStream() == null) {
            throw new IllegalArgumentException("BlancoCommonsBatchProcess: Failed to start the process. The required field value[outStream] in the input parameter[input] is not set to a value.");
        }
        if (input.getInStreamDef() == null) {
            throw new IllegalArgumentException("BlancoCommonsBatchProcess: Failed to start the process. The required field value[inStreamDef] in the input parameter[input] is not set to a value.");
        }
        if (input.getOutStreamExcel() == null) {
            throw new IllegalArgumentException("BlancoCommonsBatchProcess: Failed to start the process. The required field value[outStreamExcel] in the input parameter[input] is not set to a value.");
        }
    }
}
