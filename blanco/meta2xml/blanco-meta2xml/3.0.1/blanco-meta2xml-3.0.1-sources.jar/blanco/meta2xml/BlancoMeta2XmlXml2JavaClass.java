/*
 * blanco Framework
 * Copyright (C) 2004-2009 IGA Tosiki
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 */
package blanco.meta2xml;

import java.io.File;
import java.io.IOException;
import java.util.List;

import javax.xml.transform.dom.DOMResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import blanco.cg.BlancoCgObjectFactory;
import blanco.cg.transformer.BlancoCgTransformerFactory;
import blanco.cg.valueobject.BlancoCgClass;
import blanco.cg.valueobject.BlancoCgField;
import blanco.cg.valueobject.BlancoCgMethod;
import blanco.cg.valueobject.BlancoCgSourceFile;
import blanco.commons.util.BlancoJavaSourceUtil;
import blanco.commons.util.BlancoStringUtil;
import blanco.commons.util.BlancoXmlUtil;
import blanco.meta2xml.valueobject.BlancoMeta2XmlStructure;

/**
 * The main class of blancoValueObject.
 * 
 * Auto-generates Java source code from an XML file representing a blancoValueObject.
 * 
 * @author IGA Tosiki
 */
public class BlancoMeta2XmlXml2JavaClass {
    /**
     * A factory for blancoCg to be used internally.
     */
    private BlancoCgObjectFactory fCgFactory = null;

    /**
     * Source file information for blancoCg to be used internally.
     */
    private BlancoCgSourceFile fCgSourceFile = null;

    /**
     * Class information for blancoCg to be used internally.
     */
    private BlancoCgClass fCgClass = null;

    /**
     * Character encoding of auto-generated source files.
     */
    private String fEncoding = null;

    public void setEncoding(final String argEncoding) {
        fEncoding = argEncoding;
    }

    /**
     * Auto-generates Java source code from an XML file representing a ValueObject.
     * 
     * @param metaXmlSourceFile
     *            An XML file containing meta-information about the ValueObject.
     * @param directoryTarget
     *            Source code generation destination directory.
     * @throws IOException
     *             If an I/O exception occurs.
     */
    public void process(final File metaXmlSourceFile, final File directoryTarget)
            throws IOException {

        final DOMResult result = BlancoXmlUtil
                .transformFile2Dom(metaXmlSourceFile);

        final Node rootNode = result.getNode();
        if (rootNode instanceof Document) {
            // This is the normal system. Gets the document root.
            final Document rootDocument = (Document) rootNode;
            final NodeList listSheet = rootDocument
                    .getElementsByTagName("sheet");
            final int sizeListSheet = listSheet.getLength();
            for (int index = 0; index < sizeListSheet; index++) {
                final Element elementCommon = BlancoXmlUtil.getElement(
                        listSheet.item(index), "blancometa2xml-process-common");
                if (elementCommon == null) {
                    // Skips if there is no common.
                    continue;
                }

                final String name = BlancoXmlUtil.getTextContent(elementCommon,
                        "name");
                if (name == null || name.trim().length() == 0) {
                    continue;
                }

                expandSheet(elementCommon, directoryTarget);
            }
        }
    }

    /**
     * Expands the sheet.
     * 
     * @param elementCommon
     *            Common node that is currently being processed.
     * @param directoryTarget
     *            Output destination folder.
     */
    private void expandSheet(final Element elementCommon,
            final File directoryTarget) {
        final BlancoMeta2XmlStructure processStructure = new BlancoMeta2XmlStructure();
        processStructure.setName(BlancoXmlUtil.getTextContent(elementCommon,
                "name"));
        processStructure.setPackage(BlancoXmlUtil.getTextContent(elementCommon,
                "package"));
        if (processStructure.getPackage() == null
                || processStructure.getPackage().trim().length() == 0) {
            throw new IllegalArgumentException("Metafile-XML conversion process definition The package of class name ["
                    + processStructure.getName() + "] is not specified.");
        }

        if (BlancoXmlUtil.getTextContent(elementCommon, "description") != null) {
            processStructure.setDescription(BlancoXmlUtil.getTextContent(
                    elementCommon, "description"));
        }
        if (BlancoXmlUtil.getTextContent(elementCommon, "fileDescription") != null) {
            processStructure.setFileDescription(BlancoXmlUtil.getTextContent(
                    elementCommon, "fileDescription"));
        }

        processStructure.setConvertDefFile(BlancoXmlUtil.getTextContent(
                elementCommon, "convertDefFile"));
        if (processStructure.getConvertDefFile() == null
                || processStructure.getConvertDefFile().trim().length() == 0) {
            throw new IllegalArgumentException("Metafile-XML conversion process definition The conversion definition file for class name ["
                    + processStructure.getName() + "] is not specified.");
        }

        if (BlancoXmlUtil.getTextContent(elementCommon, "inputFileExt") != null) {
            processStructure.setInputFileExt(BlancoXmlUtil.getTextContent(
                    elementCommon, "inputFileExt"));
        }
        if (BlancoXmlUtil.getTextContent(elementCommon, "outputFileExt") != null) {
            processStructure.setOutputFileExt(BlancoXmlUtil.getTextContent(
                    elementCommon, "outputFileExt"));
        }
        if (BlancoXmlUtil.getTextContent(elementCommon, "inputFileExtSub") != null) {
            processStructure.setInputFileExtSub(BlancoXmlUtil.getTextContent(
                    elementCommon, "inputFileExtSub"));
        }
        /* added by KINOKO */
        if (BlancoXmlUtil.getTextContent(elementCommon, "excludedFileRegex") != null) {
            processStructure.setExcludedFileRegex(BlancoXmlUtil.getTextContent(
                    elementCommon, "excludedFileRegex"));
        }

        expandJavaSource(processStructure, directoryTarget);
    }

    /**
     * Outputs the Java source code based on the collected information.
     * 
     * @param processStructure
     *            Processing structure.
     * @param directoryTarget
     *            Output destination folder.
     */
    private void expandJavaSource(
            final BlancoMeta2XmlStructure processStructure,
            final File directoryTarget) {
        // To make it compatible with the previous version, outputs to the /main subfolder.
        final File fileBlancoMain = new File(directoryTarget.getAbsolutePath()
                + "/main");

        fCgFactory = BlancoCgObjectFactory.getInstance();
        fCgSourceFile = fCgFactory.createSourceFile(processStructure
                .getPackage(), "This source code has been generated by blanco Framework.");
        fCgSourceFile.setEncoding(fEncoding);
        if (processStructure.getFileDescription() != null) {
            fCgSourceFile.getLangDoc().getDescriptionList().add(
                    processStructure.getFileDescription());
        }

        fCgClass = fCgFactory.createClass(processStructure.getName(),
                BlancoStringUtil.null2Blank(processStructure.getDescription()));
        fCgSourceFile.getClassList().add(fCgClass);

        fCgSourceFile.getImportList().add("java.io.BufferedInputStream");
        fCgSourceFile.getImportList().add("java.io.BufferedOutputStream");
        fCgSourceFile.getImportList().add("java.io.FileInputStream");
        fCgSourceFile.getImportList().add("java.io.FileOutputStream");
        fCgSourceFile.getImportList().add("java.io.IOException");
        fCgSourceFile.getImportList().add("java.io.InputStream");
        fCgSourceFile.getImportList().add("java.io.OutputStream");
        fCgSourceFile.getImportList().add(
                "javax.xml.transform.TransformerException");
        fCgSourceFile.getImportList().add(
                "blanco.commons.calc.parser.BlancoCalcParser");

        {
            final BlancoCgField field = fCgFactory.createField(
                    "fCacheMeta2Xml", "boolean",
                    "Flag whether the conversion from definition metafile to intermediate XML file should be done in cache or not.");
            fCgClass.getFieldList().add(field);
            field.setAccess("protected");
            field.setDefault("false");
        }

        {
            final BlancoCgField field = fCgFactory.createField(
                    "fCacheMeta2XmlCount", "int",
                    "The number of times the conversion from a definition metafile to an intermediate XML file was completed in cache.");
            fCgClass.getFieldList().add(field);
            field.setAccess("protected");
            field.setDefault("0");
        }

        {
            final BlancoCgField field = fCgFactory.createField(
                    "fCacheMetaDefXml", "byte[]",
                    "A cache to reduce the number of times the definition structure XML file is read from the class loader.");
            fCgClass.getFieldList().add(field);
            field.setAccess("protected");
            field.setDefault("null");
        }

        {
            final BlancoCgMethod method = fCgFactory.createMethod(
                    "setCacheMeta2Xml",
                    "Sets the flag whether the conversion from definition metafile to intermediate XML file should be done in cache or not.");
            fCgClass.getMethodList().add(method);

            method.getParameterList().add(
                    fCgFactory.createParameter("argCacheMeta2Xml", "boolean",
                            "Whether the conversion from the definition metafile to the intermediate XML file should be done in cache."));

            final List<java.lang.String> listLine = method.getLineList();
            listLine.add("fCacheMeta2Xml = argCacheMeta2Xml;");
        }

        {
            final BlancoCgMethod methodProcess1 = fCgFactory.createMethod(
                    "process", "Converts a stream of an Excel file to a stream of an XML file.");
            fCgClass.getMethodList().add(methodProcess1);
            methodProcess1.getLangDoc().getDescriptionList().add(
                    "The definition file holds the path internally.");
            methodProcess1.getParameterList().add(
                    fCgFactory.createParameter("inStreamMetaSource",
                            "java.io.InputStream", "Input stream of the metafile."));
            methodProcess1.getParameterList().add(
                    fCgFactory.createParameter("outStreamTarget",
                            "java.io.OutputStream", "Output stream of an XML file."));
            methodProcess1.getThrowList().add(
                    fCgFactory.createException("java.io.IOException",
                            "If an I/O exception occurs."));
            methodProcess1.getThrowList().add(
                    fCgFactory.createException(
                            "javax.xml.transform.TransformerException",
                            "If an XML conversion exception occurs."));
            final List<java.lang.String> listLine = methodProcess1
                    .getLineList();
            listLine.add("if (inStreamMetaSource == null) {");

            listLine.add("throw new IllegalArgumentException(\""
                    + processStructure.getName()
                    + ": Invalid argument: inStreamMetaSource is null.\");");
            listLine.add("}");
            listLine.add("if (outStreamTarget == null) {");
            listLine.add("throw new IllegalArgumentException(\""
                    + processStructure.getName()
                    + ": Invalid argument: outStreamTarget is null.\");");
            listLine.add("}");
            listLine.add("");
            listLine.add("if (fCacheMetaDefXml == null) {");
            listLine.add("// Loads the XML configuration file from the same class loader as itself.");
            listLine
                    .add("final InputStream meta2xmlStream = getClass().getClassLoader().getResourceAsStream(\""
                            + processStructure.getConvertDefFile() + "\");");
            listLine.add("if (meta2xmlStream == null) {");
            listLine
                    .add("throw new IllegalArgumentException(\""
                            + processStructure.getName() + ": Resource ["
                            + processStructure.getConvertDefFile()
                            + "] failed to be obtained.\");");
            listLine.add("}");
            fCgSourceFile.getImportList().add("java.io.ByteArrayOutputStream");
            fCgSourceFile.getImportList().add("java.io.ByteArrayInputStream");
            listLine
                    .add("final ByteArrayOutputStream outStream = new ByteArrayOutputStream();");
            listLine.add("final byte[] bufWrk = new byte[8192];");
            listLine.add("for (;;) {");
            listLine.add("final int readLength = meta2xmlStream.read(bufWrk);");
            listLine.add("if (readLength <= 0) {");
            listLine.add("break;");
            listLine.add("}");
            listLine.add("outStream.write(bufWrk, 0, readLength);");
            listLine.add("}");
            listLine.add("outStream.flush();");
            listLine.add("meta2xmlStream.close();");
            listLine.add("fCacheMetaDefXml = outStream.toByteArray();");

            listLine.add("}");
            listLine.add("");
            listLine
                    .add("InputStream inStreamDef = new ByteArrayInputStream(fCacheMetaDefXml);");
            listLine.add("try {");
            listLine
                    .add("new BlancoCalcParser().process(inStreamDef, inStreamMetaSource, outStreamTarget);");
            listLine.add("} finally {");
            listLine.add("if (inStreamDef != null) {");
            listLine.add("inStreamDef.close();");
            listLine.add("}");
            listLine.add("}");
        }

        {
            final BlancoCgMethod methodProcess2 = fCgFactory.createMethod(
                    "process", "Convert an Excel file to an XML file.");
            fCgClass.getMethodList().add(methodProcess2);
            methodProcess2.getParameterList().add(
                    fCgFactory.createParameter("fileMeta", "java.io.File",
                            "Input file for the metafile."));
            methodProcess2.getParameterList().add(
                    fCgFactory.createParameter("fileOutput", "java.io.File",
                            "XML file output."));
            methodProcess2.getThrowList().add(
                    fCgFactory.createException("java.io.IOException",
                            "If an I/O exception occurs."));
            methodProcess2.getThrowList().add(
                    fCgFactory.createException(
                            "javax.xml.transform.TransformerException",
                            "If an XML conversion exception occurs."));
            final List<java.lang.String> listLine = methodProcess2
                    .getLineList();

            listLine.add("if (fileMeta == null) {");
            listLine.add("throw new IllegalArgumentException(\""
                    + processStructure.getName()
                    + ": Invalid argument: fileMeta is null.\");");
            listLine.add("}");
            listLine.add("if (fileOutput == null) {");
            listLine.add("throw new IllegalArgumentException(\""
                    + processStructure.getName()
                    + ": Invalid argument: fileOutput is null.\");");
            listLine.add("}");
            listLine.add("if (fileMeta.exists() == false) {");
            listLine
                    .add("throw new IllegalArgumentException(\""
                            + processStructure.getName()
                            + ": Invalid argument: file file [\" + fileMeta.getAbsolutePath() + \"] not found.\");");
            listLine.add("}");
            listLine.add("");
            listLine
                    .add("if (fCacheMeta2Xml && fileMeta.lastModified() < fileOutput.lastModified()) {");
            listLine.add("// Uses the cache to skips the process.");
            listLine.add("fCacheMeta2XmlCount++;");
            listLine.add("return;");
            listLine.add("}");
            listLine.add("");
            listLine.add("InputStream inStream = null;");
            listLine.add("OutputStream outStream = null;");
            listLine.add("try {");
            listLine
                    .add("inStream = new BufferedInputStream(new FileInputStream(fileMeta), 8192);");
            listLine
                    .add("outStream = new BufferedOutputStream(new FileOutputStream(fileOutput), 8192);");
            listLine.add("");
            listLine.add("// Now that the stream is ready, it will do the actual processing.");
            listLine.add("process(inStream, outStream);");
            listLine.add("");
            listLine.add("outStream.flush();");
            listLine.add("} finally {");
            listLine.add("if (inStream != null) {");
            listLine.add("inStream.close();");
            listLine.add("}");
            listLine.add("if (outStream != null) {");
            listLine.add("outStream.close();");
            listLine.add("}");
            listLine.add("}");
        }

        {
            final BlancoCgMethod methodProcessDirectory = fCgFactory
                    .createMethod("processDirectory",
                            "Converts the Excel file in the specified directory to the XML file.");
            fCgClass.getMethodList().add(methodProcessDirectory);
            methodProcessDirectory.getLangDoc().getDescriptionList().add(
                    "Processes a file with the extension [" + processStructure.getInputFileExt()
                            + "] in the specified folder.<br>");
            if(processStructure.getInputFileExtSub() != null) {
                methodProcessDirectory.getLangDoc().getDescriptionList().add(
                        "Processes a file with the extension [" + processStructure.getInputFileExtSub()
                                + "] in the specified folder.<br>");
            }
            methodProcessDirectory.getLangDoc().getDescriptionList().add(
                    "The processed data will be saved to a file with the extension ["
                            + processStructure.getOutputFileExt()
                            + "] added to the original file name.");
            methodProcessDirectory.getParameterList().add(
                    fCgFactory.createParameter("fileMetadir", "java.io.File",
                            "The input directory where the metafile is stored."));
            methodProcessDirectory.getParameterList().add(
                    fCgFactory.createParameter("targetDirectory",
                            "java.lang.String", "Output directory."));
            methodProcessDirectory.getThrowList().add(
                    fCgFactory.createException("java.io.IOException",
                            "If an I/O exception occurs."));
            methodProcessDirectory.getThrowList().add(
                    fCgFactory.createException(
                            "javax.xml.transform.TransformerException",
                            "If an XML conversion exception occurs."));
            final List<java.lang.String> listLine = methodProcessDirectory
                    .getLineList();

            listLine.add("System.out.println(\"m2x: begin.\");");
            listLine.add("final long startMills = System.currentTimeMillis();");
            listLine.add("long totalFileCount = 0;");
            listLine.add("long totalFileBytes = 0;");
            listLine.add("");
            listLine.add("if (fileMetadir == null) {");
            listLine.add("throw new IllegalArgumentException(\""
                    + processStructure.getName()
                    + ": Invalid argument: fileMetadir is null.\");");
            listLine.add("}");
            listLine.add("if (targetDirectory == null) {");
            listLine.add("throw new IllegalArgumentException(\""
                    + processStructure.getName()
                    + ": Invalid argument: targetDirectory is null.\");");
            listLine.add("}");
            listLine.add("if (fileMetadir.exists() == false) {");
            listLine
                    .add("throw new IllegalArgumentException(\""
                            + processStructure.getName()
                            + ": Invalid argument: file [\" + fileMetadir.getAbsolutePath() + \"] not found.\");");
            listLine.add("}");
            listLine
                    .add("final File fileTargetDirectory = new File(targetDirectory);");
            listLine.add("if (fileTargetDirectory.exists() == false) {");
            listLine.add("// Since the output directory does not exist, creates it in advance.");
            listLine.add("fileTargetDirectory.mkdirs();");
            listLine.add("}");
            listLine.add("");
            listLine.add("// Gets a list of files in the specified directory.");
            listLine.add("final File[] fileMeta = fileMetadir.listFiles();");
            listLine.add("if (fileMeta == null) {");
            listLine
                    .add("throw new IllegalArgumentException(\"BlancoMeta2XmlProcessMeta2Xml: list directory [\" + fileMetadir.getAbsolutePath() + \"] is failed.\");");
            listLine.add("}");
            listLine
                    .add("for (int index = 0; index < fileMeta.length; index++) {");
            listLine.add("if ((fileMeta[index].getName().endsWith(\""
                    + BlancoJavaSourceUtil
                    .escapeStringAsJavaSource(processStructure
                            .getInputFileExt()) + "\") == false");
            if(processStructure.getInputFileExtSub() != null){
                listLine.add(" && fileMeta[index].getName().endsWith(\""
                        + BlancoJavaSourceUtil
                        .escapeStringAsJavaSource(processStructure
                                .getInputFileExtSub()) + "\") == false)");
            }
            /* added by KINOKO Skip files that should be excluded from loading (temporary files).
             * @TODO startsWith should be matches.
            */
            listLine.add("|| fileMeta[index].getName().startsWith(\""
                    + BlancoJavaSourceUtil
                    .escapeStringAsJavaSource(processStructure
                            .getExcludedFileRegex()) + "\")");
            listLine.add(") {");
            listLine.add("// Skips processing because the file extension is different from the one that should be processed.");
            listLine.add("continue;");
            listLine.add("}");
            listLine.add("");

            listLine
                    .add("if (progress(index + 1, fileMeta.length, fileMeta[index].getName()) == false) {");
            listLine.add("// Since the command to suspend processing came from the progress indicator, so we will.");
            listLine.add("break;");
            listLine.add("}");

            listLine.add("");
            listLine.add("try {");
            listLine.add("totalFileCount++;");
            listLine.add("totalFileBytes += fileMeta[index].length();");
            listLine
                    .add("process(fileMeta[index], new File(targetDirectory + \"/\" + fileMeta[index].getName() + \""
                            + BlancoJavaSourceUtil
                                    .escapeStringAsJavaSource(processStructure
                                            .getOutputFileExt()) + "\"));");
            listLine.add("} catch (Exception ex) {");
            listLine.add("ex.printStackTrace();");
            listLine
                    .add("throw new IllegalArgumentException(\""
                            + processStructure.getName()
                            + ": Exception occurs during processing the file [\" + fileMeta[index].getAbsolutePath() + \"]. \" + ex.toString());");
            listLine.add("}");
            listLine.add("}");
            listLine.add("");
            listLine.add("if (fCacheMeta2Xml) {");
            listLine
                    .add("System.out.println(\"m2x: cache: \" + fCacheMeta2XmlCount + \" file skipped.\");");
            listLine.add("}");
            listLine
                    .add("final long costMills = System.currentTimeMillis() - startMills + 1;");
            listLine
                    .add("System.out.println(\"m2x: end: \" + (costMills / 1000) + \" sec, \" + totalFileCount + \" file, \" + totalFileBytes + \" byte (\" + (totalFileBytes * 1000 / costMills) + \" byte/sec).\");");
        }

        {
            final BlancoCgMethod methodProgress = fCgFactory.createMethod(
                    "progress", "Indicates the progress of the process.");
            fCgClass.getMethodList().add(methodProgress);
            methodProgress.setAccess("protected");
            methodProgress.getLangDoc().getDescriptionList().add(
                    "Inherit from it and create the process if you want to display the progress.");
            methodProgress.getParameterList().add(
                    fCgFactory.createParameter("progressCurrent", "int",
                            "The number of cases currently being processed."));
            methodProgress.getParameterList().add(
                    fCgFactory
                            .createParameter("progressTotal", "int", "Total number of cases processed."));
            methodProgress.getParameterList().add(
                    fCgFactory.createParameter("progressItem",
                            "java.lang.String", "The name of the item being processed."));
            methodProgress.setReturn(fCgFactory.createReturn("boolean",
                    "Whether the process can be continued or not. Aborts the process if false."));
            final List<java.lang.String> listLine = methodProgress
                    .getLineList();

            listLine.add("// Always returns true to indicate that processing continues.");
            listLine.add("return true;");
        }

        BlancoCgTransformerFactory.getJavaSourceTransformer().transform(
                fCgSourceFile, fileBlancoMain);
    }
}
