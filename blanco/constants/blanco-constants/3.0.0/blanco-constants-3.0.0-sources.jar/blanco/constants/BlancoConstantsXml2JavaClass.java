/*
 * blanco Framework
 * Copyright (C) 2004-2005 IGA Tosiki
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 */
package blanco.constants;

import java.io.File;
import java.io.IOException;
import java.util.List;

import blanco.cg.BlancoCgObjectFactory;
import blanco.cg.transformer.BlancoCgTransformerFactory;
import blanco.cg.valueobject.BlancoCgClass;
import blanco.cg.valueobject.BlancoCgField;
import blanco.cg.valueobject.BlancoCgSourceFile;
import blanco.commons.util.BlancoJavaSourceUtil;
import blanco.commons.util.BlancoNameUtil;
import blanco.commons.util.BlancoStringUtil;
import blanco.constants.message.BlancoConstantsMessage;
import blanco.constants.resourcebundle.BlancoConstantsResourceBundle;
import blanco.constants.valueobject.BlancoConstantsFieldStructure;
import blanco.constants.valueobject.BlancoConstantsStructure;

/**
 * This class auto-generates Java source code from intermediate XML files.
 *
 * This is part of a project to auto-generate source code from constant definitions (XLS).
 *
 * @author IGA Tosiki
 */
public class BlancoConstantsXml2JavaClass {
    /**
     * A message.
     */
    private final BlancoConstantsMessage fMsg = new BlancoConstantsMessage();

    /**
     * An object of the accessor class to the resource bundle.
     */
    private final BlancoConstantsResourceBundle fBundle = new BlancoConstantsResourceBundle();

    /**
     * A factory for blancoCg to be used internally.
     */
    private BlancoCgObjectFactory fCgFactory = null;

    /**
     * Source file information for blancoCg to be used internally.
     */
    private BlancoCgSourceFile fCgSourceFile = null;

    /**
     * Class information for blancoCg to be used internally.
     */
    private BlancoCgClass fCgClass = null;

    /**
     * Character encoding of auto-generated source files.
     */
    private String fEncoding = null;

    public void setEncoding(final String argEncoding) {
        fEncoding = argEncoding;
    }

    /**
     * Style of the source code generation destination directory
     */
    private boolean fTargetStyleAdvanced = false;
    public void setTargetStyleAdvanced(boolean argTargetStyleAdvanced) {
        this.fTargetStyleAdvanced = argTargetStyleAdvanced;
    }
    public boolean isTargetStyleAdvanced() {
        return this.fTargetStyleAdvanced;
    }

    /**
     * Auto-generates Java source code from intermediate XML files.
     *
     * @param argMetaXmlSourceFile
     *            An XML file containing meta-information about the ValueObject.
     * @param argDirectoryTarget
     *            Source code generation destination directory.
     * @throws IOException
     *             If an I/O exception occurs.
     */
    public void process(final File argMetaXmlSourceFile,
            final File argDirectoryTarget) throws IOException {
        final BlancoConstantsStructure[] structures = new BlancoConstantsXmlParser()
                .parse(argMetaXmlSourceFile);
        for (int index = 0; index < structures.length; index++) {
            // Generates Java source code from the obtained information.
            structure2Source(structures[index], argDirectoryTarget);
        }
    }

    /**
     * Outputs the Java source code based on the collected information.
     *
     * @param processStructure
     *            Processing structure.
     * @param directoryTarget
     *            Output destination folder.
     */
    public void structure2Source(
            final BlancoConstantsStructure processStructure,
            final File directoryTarget) {

        /*
         * The output directory will be in the format specified by the targetStyle argument of the ant task.
         * For compatibility, the output directory will be blanco/main if it is not specified.
         * by tueda, 2019/08/30
         */
        String strTarget = directoryTarget
                .getAbsolutePath(); // advanced
        if (!this.isTargetStyleAdvanced()) {
            strTarget += "/main"; // legacy
        }
        final File fileBlancoMain = new File(strTarget);

        fCgFactory = BlancoCgObjectFactory.getInstance();
        fCgSourceFile = fCgFactory.createSourceFile(processStructure
                .getPackage(), null);
        fCgSourceFile.setEncoding(fEncoding);
        fCgClass = fCgFactory.createClass(processStructure.getName()
                + BlancoStringUtil.null2Blank(processStructure.getSuffix()),
                BlancoStringUtil.null2Blank(processStructure.getDescription()));
        fCgSourceFile.getClassList().add(fCgClass);

        // Sets access to the class.
        fCgClass.setAccess(processStructure.getAccess());
        // Whether it is an abstract class or not.
        fCgClass.setAbstract(processStructure.getAbstract());

        // Inheritance
        if (BlancoStringUtil.null2Blank(processStructure.getExtends()).length() > 0) {
            fCgClass.getExtendClassList().add(
                    fCgFactory.createType(processStructure.getExtends()));
        }

        /* Sets the annotation for the class. */
        List<String> annotationList = processStructure.getAnnotationList();
        if (annotationList != null && annotationList.size() > 0) {
            fCgClass.getAnnotationList().addAll(processStructure.getAnnotationList());
            /* tueda DEBUG */
            System.out.println("/* tueda */ structure2Source : class annotation = " + processStructure.getAnnotationList().get(0));
        }

        /* Sets import for the class. */
        for (int index = 0; index < processStructure.getImportList()
                .size(); index++) {
            final String imported = (String) processStructure.getImportList()
                    .get(index);
            fCgSourceFile.getImportList().add(imported);
        }

        for (int indexField = 0; indexField < processStructure.getFieldList()
                .size(); indexField++) {
            BlancoConstantsFieldStructure fieldLook = (BlancoConstantsFieldStructure) processStructure
                    .getFieldList().get(indexField);
            final BlancoCgField field = fCgFactory.createField(fieldLook
                    .getName(), fieldLook.getType(), "");
            fCgClass.getFieldList().add(field);

            field.setAccess("public");
            field.setFinal(true);
            field.setStatic(true);

            if (fieldLook.getNo() != null) {
                field.getLangDoc().getDescriptionList().add(
                        fBundle.getXml2javaclassFieldNo(fieldLook.getNo()));
            }
            if (fieldLook.getDescription() != null) {
                field.getLangDoc().getDescriptionList().add(
                        fieldLook.getDescription());
            }

            if (processStructure.getAdjustConstValue() == false) {
                // Assigns as is.
                field.setDefault(fieldLook.getValue());
            } else {
                // The default value is written differently depending on the type.
                // If an unsupported type is given, an exception will be raised.
                if (fieldLook.getType().equals("java.lang.String")) {
                    field.setDefault("\""
                            + BlancoJavaSourceUtil
                                    .escapeStringAsJavaSource(fieldLook
                                            .getValue()) + "\"");
                } else if (fieldLook.getType().equals("boolean")
                        || fieldLook.getType().equals("short")
                        || fieldLook.getType().equals("int")
                        || fieldLook.getType().equals("long")) {
                    field.setDefault(fieldLook.getValue());
                } else if (fieldLook.getType().equals("java.lang.Boolean")
                        || fieldLook.getType().equals("java.lang.Integer")
                        || fieldLook.getType().equals("java.lang.Long")) {
                    field.setDefault("new "
                            + BlancoNameUtil.trimJavaPackage(fieldLook
                                    .getType()) + "(" + fieldLook.getValue()
                            + ")");
                } else if (fieldLook.getType().equals("java.lang.Short")) {
                    field.setDefault("new "
                            + BlancoNameUtil.trimJavaPackage(fieldLook
                                    .getType()) + "((short) "
                            + fieldLook.getValue() + ")");
                } else if (fieldLook.getType().equals("java.math.BigDecimal")) {
                    fCgSourceFile.getImportList().add("java.math.BigDecimal");
                    field.setDefault("new BigDecimal(\"" + fieldLook.getValue()
                            + "\")");
                } else if (fieldLook.getType().equals("java.util.ArrayList")) {
                    // In the case of ArrayList, it will adopt the given characters as is.
                    fCgSourceFile.getImportList().add("java.util.ArrayList");
                    field.setDefault(fieldLook.getValue());
                } else {
                    throw new IllegalArgumentException(fMsg.getMbctji04(
                            processStructure.getName(), fieldLook.getName(),
                            fieldLook.getValue(), fieldLook.getType()));
                }
            }
        }

        BlancoCgTransformerFactory.getJavaSourceTransformer().transform(
                fCgSourceFile, fileBlancoMain);
    }
}
