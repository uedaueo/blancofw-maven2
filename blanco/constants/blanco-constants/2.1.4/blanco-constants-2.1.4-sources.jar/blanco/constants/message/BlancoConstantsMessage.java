/*
 * このソースコードは blanco Frameworkによって自動生成されています。
 */
package blanco.constants.message;

/**
 * blancoConstantsが利用するメッセージ。
 */
public class BlancoConstantsMessage {
    /**
     * メッセージをプロパティファイル対応させるための内部的に利用するリソースバンドルクラス。
     */
    protected final BlancoConstantsMessageResourceBundle fBundle = new BlancoConstantsMessageResourceBundle();

    /**
     * メッセージ定義ID[BlancoConstants]、キー[MBCTJI01]の文字列を取得します。
     *
     * No.2:
     * 文字列[定数定義ID[{0}]のパッケージ名が指定されていません。]
     *
     * @param arg0 置換文字列{0}の値。
     * @return メッセージ文字列。
     */
    public String getMbctji01(final String arg0) {
        if (arg0 == null) {
            throw new IllegalArgumentException("The parameter [arg0] of the method [getMbctji01] has been given null. However, null cannot be given to this parameter.");
        }

        return "[MBCTJI01] " + fBundle.getMbctji01(arg0);
    }

    /**
     * メッセージ定義ID[BlancoConstants]、キー[MBCTJI02]の文字列を取得します。
     *
     * No.3:
     * 文字列[定数定義ID[{0}]のフィールド[{1}]の型が指定されていません。]
     *
     * @param arg0 置換文字列{0}の値。
     * @param arg1 置換文字列{1}の値。
     * @return メッセージ文字列。
     */
    public String getMbctji02(final String arg0, final String arg1) {
        if (arg0 == null) {
            throw new IllegalArgumentException("The parameter [arg0] of the method [getMbctji02] has been given null. However, null cannot be given to this parameter.");
        }
        if (arg1 == null) {
            throw new IllegalArgumentException("The parameter [arg1] of the method [getMbctji02] has been given null. However, null cannot be given to this parameter.");
        }

        return "[MBCTJI02] " + fBundle.getMbctji02(arg0, arg1);
    }

    /**
     * メッセージ定義ID[BlancoConstants]、キー[MBCTJI03]の文字列を取得します。
     *
     * No.4:
     * 文字列[定数定義ID[{0}]のフィールド[{1}]の値が指定されていません。]
     *
     * @param arg0 置換文字列{0}の値。
     * @param arg1 置換文字列{1}の値。
     * @return メッセージ文字列。
     */
    public String getMbctji03(final String arg0, final String arg1) {
        if (arg0 == null) {
            throw new IllegalArgumentException("The parameter [arg0] of the method [getMbctji03] has been given null. However, null cannot be given to this parameter.");
        }
        if (arg1 == null) {
            throw new IllegalArgumentException("The parameter [arg1] of the method [getMbctji03] has been given null. However, null cannot be given to this parameter.");
        }

        return "[MBCTJI03] " + fBundle.getMbctji03(arg0, arg1);
    }

    /**
     * メッセージ定義ID[BlancoConstants]、キー[MBCTJI04]の文字列を取得します。
     *
     * No.5:
     * 文字列[定数定義ID[{0}]のフィールド[{1}]の「値({2})」がセットされています。しかし「{3}」はサポートしません。]
     *
     * @param arg0 置換文字列{0}の値。
     * @param arg1 置換文字列{1}の値。
     * @param arg2 置換文字列{2}の値。
     * @param arg3 置換文字列{3}の値。
     * @return メッセージ文字列。
     */
    public String getMbctji04(final String arg0, final String arg1, final String arg2, final String arg3) {
        if (arg0 == null) {
            throw new IllegalArgumentException("The parameter [arg0] of the method [getMbctji04] has been given null. However, null cannot be given to this parameter.");
        }
        if (arg1 == null) {
            throw new IllegalArgumentException("The parameter [arg1] of the method [getMbctji04] has been given null. However, null cannot be given to this parameter.");
        }
        if (arg2 == null) {
            throw new IllegalArgumentException("The parameter [arg2] of the method [getMbctji04] has been given null. However, null cannot be given to this parameter.");
        }
        if (arg3 == null) {
            throw new IllegalArgumentException("The parameter [arg3] of the method [getMbctji04] has been given null. However, null cannot be given to this parameter.");
        }

        return "[MBCTJI04] " + fBundle.getMbctji04(arg0, arg1, arg2, arg3);
    }

    /**
     * メッセージ定義ID[BlancoConstants]、キー[MBCTJA01]の文字列を取得します。
     *
     * No.8:
     * 文字列[メタディレクトリ[{0}]が存在しません。]
     *
     * @param arg0 置換文字列{0}の値。
     * @return メッセージ文字列。
     */
    public String getMbctja01(final String arg0) {
        if (arg0 == null) {
            throw new IllegalArgumentException("The parameter [arg0] of the method [getMbctja01] has been given null. However, null cannot be given to this parameter.");
        }

        return "[MBCTJA01] " + fBundle.getMbctja01(arg0);
    }
}
