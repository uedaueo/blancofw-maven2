/*
 * blanco Framework
 * Copyright (C) 2004-2006 IGA Tosiki
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 */
package blanco.dbmetadata.csv;

import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;
import java.util.List;

import blanco.commons.util.BlancoStringUtil;
import blanco.dbmetadata.BlancoDbMetaDataTable;
import blanco.dbmetadata.BlancoDbMetaDataUtil;
import blanco.dbmetadata.valueobject.BlancoDbMetaDataColumnStructure;
import blanco.dbmetadata.valueobject.BlancoDbMetaDataTableStructure;

/**
 * Obtains meta information from the database and outputs it to CSV.
 * 
 * @author IGA Tosiki
 */
public class BlancoDbMetaDataMeta2Csv {
    /**
     * Obtains meta information of the database.
     * 
     * @param argJdbcDriverName
     *            JDBC driver name.
     * @param argJdbcUrl
     *            JDBC connection URL。
     * @param argJdbcUser
     *            JDBC connection user name.
     * @param argJdbcPassword
     *            JDBC connection password.
     * @param argSchema
     *            Schema name. If there is no specific value, specify null.
     * @param argTable
     *            Table name. If there is no specific value, specify null.
     * @throws SQLException
     *             If various exceptions occur.
     * @throws IOException
     * @throws ClassNotFoundException
     */
    public void process(final String argJdbcDriverName,
            final String argJdbcUrl, final String argJdbcUser,
            final String argJdbcPassword, final String argSchema,
            final String argTable, final File targetDir) throws SQLException,
            IOException, ClassNotFoundException {
        System.out.println("Database connection: Start: [" + argJdbcDriverName + "], ["
                + argJdbcUrl + "], [" + argJdbcUser + "]");
        final Connection conn = BlancoDbMetaDataUtil.connect(argJdbcDriverName,
                argJdbcUrl, argJdbcUser, argJdbcPassword);

        List<BlancoDbMetaDataTableStructure> listTables = null;

        try {
            // Sets auto-commit to OFF.
            conn.setAutoCommit(false);

            listTables = BlancoDbMetaDataTable.getTablesWithColumns(conn,
                    argSchema, argTable, new String[] { "TABLE" });
        } finally {
            // Performs post-processing.
            conn.rollback();
            conn.close();
            System.out.println("Database connection: End");
        }

        WriteCsvForMetaInfo.process(listTables, targetDir);

        WriteCsvForDataInput.process(listTables, targetDir);

        WriteCsvForMetaInfoAll.process(listTables, targetDir);
    }

    /**
     * Outputs general information about a table.
     * 
     * @param tableStructure
     * @param writer
     * @throws IOException
     */
    public static void writeTableInfo(
            final BlancoDbMetaDataTableStructure tableStructure,
            final BufferedWriter writer) throws IOException {
        writer.write("Table name,Type,Catalog,Schema,Remarks");
        writer.newLine();
        writer.write(tableStructure.getName());
        writer.write(",");
        writer.write(BlancoStringUtil.null2Blank(tableStructure.getType()));
        writer.write(",");
        writer.write(BlancoStringUtil.null2Blank(tableStructure.getCatalog()));
        writer.write(",");
        writer.write(BlancoStringUtil.null2Blank(tableStructure.getSchema()));
        writer.write(",");
        writer.write(BlancoStringUtil.null2Blank(tableStructure.getRemarks()));
        writer.newLine();
    }

    /**
     * Outputs the type name of an item.
     * 
     * @param columnStructure
     * @param writer
     * @throws IOException
     */
    public static void writeColumnTypeName(
            final BlancoDbMetaDataColumnStructure columnStructure,
            final BufferedWriter writer) throws IOException {
        writer.write(columnStructure.getTypeName());

        // Switches the size representation depending on the type.
        if (columnStructure.getColumnSize() < 0) {
            // If the size is less than 0, the size will not be displayed.
            // The specification was to return -1in the case of PostgreSQL.
        } else {
            switch (columnStructure.getDataType()) {
            case Types.NUMERIC:
            case Types.DECIMAL:
                // Displays including fractional size.
                writer.write(" (" + columnStructure.getColumnSize() + "."
                        + columnStructure.getDecimalDigits() + ")");
                break;
            case Types.BIT:
            case Types.TINYINT:
            case Types.SMALLINT:
            case Types.INTEGER:
            case Types.FLOAT:
            case Types.REAL:
            case Types.DOUBLE:
            case Types.DATE:
            case Types.TIME:
            case Types.TIMESTAMP:
            case Types.NULL:
            case Types.BOOLEAN:
                // It will not output anything about the size of the display.
                break;
            default:
                writer.write(" (" + columnStructure.getColumnSize() + ")");
                break;
            }
        }
    }
}
