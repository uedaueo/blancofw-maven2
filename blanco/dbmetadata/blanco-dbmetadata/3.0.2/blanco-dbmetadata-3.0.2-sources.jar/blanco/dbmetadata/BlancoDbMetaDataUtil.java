/*
 * blanco Framework
 * Copyright (C) 2004-2006 IGA Tosiki
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 */
package blanco.dbmetadata;

import java.net.URL;
import java.net.URLClassLoader;
import java.sql.Connection;
import java.sql.Driver;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Properties;

import blanco.dbmetadata.valueobject.BlancoDbMetaDataColumnStructure;

/**
 * A utility to obtain meta information from a database.
 * 
 * Contains basic methods.
 * 
 * @author IGA Tosiki
 */
public class BlancoDbMetaDataUtil {
    /**
     * Connects to the database based on the specified information.
     * 
     * It does not use DriverManager, but uses its own method for database connection.
     * This is a measure to ensure proper operation even when the class loader instance is different.
     * 
     * @param argJdbcDriverClassName
     *            JDBC driver class name.
     * @param argJdbcUrl
     *            JDBC connection URL.
     * @param argJdbcUser
     *            JDBC connection user name.
     * @param argJdbcPassword
     *            JDBC connection password.
     * @return Database connection.
     * @throws ClassNotFoundException
     *             If the class is not found.
     * @throws IllegalArgumentException
     *             If an exception occurs when connecting.
     */
    public static Connection connect(final String argJdbcDriverClassName,
            final String argJdbcUrl, final String argJdbcUser,
            final String argJdbcPassword) throws ClassNotFoundException {
        return connect(argJdbcDriverClassName, argJdbcUrl, argJdbcUser,
                argJdbcPassword, BlancoDbMetaDataUtil.class.getClassLoader());
    }

    /**
     * Connects to the database based on the specified information.
     * 
     * It does not use DriverManager, but uses its own method for database connection.
     * This is a measure to ensure proper operation even when the class loader instance is different.
     * 
     * @param argJdbcDriverClassName
     *            JDBC driver class name.
     * @param argJdbcUrl
     *            JDBC connection URL.
     * @param argJdbcUser
     *            JDBC connection user name.
     * @param argJdbcPassword
     *            JDBC connection password.
     * @param loader
     *            A class loader.
     * @return Database connection.
     * @throws ClassNotFoundException
     *             If the class is not found.
     * @throws IllegalArgumentException
     *             If an exception occurs when connecting.
     */
    @SuppressWarnings( { "unchecked" })
    public static Connection connect(final String argJdbcDriverClassName,
            final String argJdbcUrl, final String argJdbcUser,
            final String argJdbcPassword, final ClassLoader loader)
            throws ClassNotFoundException {
        Connection conn = null;
        Driver driver = null;
        Class driverClass = null;
        try {
            driverClass = loader.loadClass(argJdbcDriverClassName);
        } catch (ClassNotFoundException ex) {
            throw new ClassNotFoundException("Database connection: Failed to load  a JDBC driver class ["
                    + argJdbcDriverClassName + "]: " + ex.toString(),
                    ex);
        }

        try {
            driver = (Driver) driverClass.newInstance();
        } catch (InstantiationException e) {
            throw new IllegalArgumentException("Database connection: Failed to instantiate JDBC driver class ["
                    + argJdbcDriverClassName + "]: "
                    + e.toString());
        } catch (IllegalAccessException e) {
            throw new IllegalArgumentException("Database connection: An access violation occurred during instantiation of the JDBC driver class ["
                    + argJdbcDriverClassName + "]: "
                    + e.toString());
        }

        try {
            // Directly calls the Driver's connect() method without using the DriverManager.
            // This will work even if the class loader is different.
            final Properties info = new Properties();
            info.put("user", argJdbcUser);
            info.put("password", argJdbcPassword);
            conn = driver.connect(argJdbcUrl, info);
        } catch (SQLException ex) {
            throw new IllegalArgumentException("Database connection: JDBC connection failed: "
                    + ex.toString());
        }

        return conn;
    }

    /**
     * Creates a class loader loaded with JDBC driver class from the specified URI list.
     * 
     * Example code: urlArray[0] = jarFile.toURL();
     * 
     * @param urlArray
     *            List of URI to be read.
     * @param argJdbcDriverClassName
     *            Driver class name.
     * @return An instance of the class loader.
     * @throws ClassNotFoundException
     *             If the class is not found.
     */
    public static final ClassLoader loadDriverClass(final URL[] urlArray,
            final String argJdbcDriverClassName) throws ClassNotFoundException {
        try {
            final ClassLoader loader = new URLClassLoader(urlArray,
                    BlancoDbMetaDataUtil.class.getClassLoader());
            loader.loadClass(argJdbcDriverClassName);

            return loader;
        } catch (ClassNotFoundException e) {
            throw new ClassNotFoundException("Database connection: Failed to class-load of JDBC driver class["
                    + argJdbcDriverClassName + "]: "
                    + e.toString());
        }
    }

    /**
     * Replaces the JDBC data type with a Java string.
     * 
     * If [java.sql.Types.] if given forward, it becomes a Java JDBC constant.
     * 
     * @param argJdbcDataType
     *            Data type on JDBC.
     * @return A string on Java.
     */
    public final static String convertJdbcDataTypeToString(
            final int argJdbcDataType) {
        switch (argJdbcDataType) {
        case Types.BIT:
            return "BIT";
        case Types.TINYINT:
            return "TINYINT";
        case Types.SMALLINT:
            return "SMALLINT";
        case Types.INTEGER:
            return "INTEGER";
        case Types.BIGINT:
            return "BIGINT";
        case Types.FLOAT:
            return "FLOAT";
        case Types.REAL:
            return "REAL";
        case Types.DOUBLE:
            return "DOUBLE";
        case Types.NUMERIC:
            return "NUMERIC";
        case Types.DECIMAL:
            return "DECIMAL";
        case Types.CHAR:
            return "CHAR";
        case Types.VARCHAR:
            return "VARCHAR";
        case Types.LONGVARCHAR:
            return "LONGVARCHAR";
        case Types.NCHAR:
            return "NCHAR";
        case Types.NVARCHAR:
            return "NVARCHAR";
        case Types.LONGNVARCHAR:
            return "LONGNVARCHAR";
        case Types.DATE:
            return "DATE";
        case Types.TIME:
            return "TIME";
        case Types.TIMESTAMP:
            return "TIMESTAMP";
        case Types.BINARY:
            return "BINARY";
        case Types.VARBINARY:
            return "VARBINARY";
        case Types.LONGVARBINARY:
            return "LONGVARBINARY";
        case Types.NULL:
            return "NULL";
        case Types.OTHER:
            return "OTHER";
        case Types.JAVA_OBJECT:
            return "JAVA_OBJECT";
        case Types.DISTINCT:
            return "DISTINCT";
        case Types.STRUCT:
            return "STRUCT";
        case Types.ARRAY:
            return "ARRAY";
        case Types.BLOB:
            return "BLOB";
        case Types.CLOB:
            return "CLOB";
        case Types.REF:
            return "REF";
        case Types.DATALINK:
            return "DATALINK";
        case Types.BOOLEAN:
            return "BOOLEAN";
        case Types.ROWID:
            return "ROWID";
        default:
            // If no match is found, returns a blank.
            return "";
        }
    }

    /**
     * Replaces the JDBC data type string with Java Types.
     * 
     * @param argJdbcDataType
     *            A value that becomes a Java JDBC constant when [java.sql.Types.] is given forward.
     * @return A value of java.sql.Types. Integer.MIN_VALUE if no match is found.
     */
    public final static int convertJdbcDataType2Int(final String argJdbcDataType) {
        if (argJdbcDataType.equals("BIT")) {
            return Types.BIT;
        }
        if (argJdbcDataType.equals("TINYINT")) {
            return Types.TINYINT;
        }
        if (argJdbcDataType.equals("SMALLINT")) {
            return Types.SMALLINT;
        }
        if (argJdbcDataType.equals("INTEGER")) {
            return Types.INTEGER;
        }
        if (argJdbcDataType.equals("BIGINT")) {
            return Types.BIGINT;
        }
        if (argJdbcDataType.equals("FLOAT")) {
            return Types.FLOAT;
        }
        if (argJdbcDataType.equals("REAL")) {
            return Types.REAL;
        }
        if (argJdbcDataType.equals("DOUBLE")) {
            return Types.DOUBLE;
        }
        if (argJdbcDataType.equals("NUMERIC")) {
            return Types.NUMERIC;
        }
        if (argJdbcDataType.equals("DECIMAL")) {
            return Types.DECIMAL;
        }
        if (argJdbcDataType.equals("CHAR")) {
            return Types.CHAR;
        }
        if (argJdbcDataType.equals("VARCHAR")) {
            return Types.VARCHAR;
        }
        if (argJdbcDataType.equals("LONGVARCHAR")) {
            return Types.LONGVARCHAR;
        }
        if (argJdbcDataType.equals("NCHAR")) {
            return Types.NCHAR;
        }
        if (argJdbcDataType.equals("NVARCHAR")) {
            return Types.NVARCHAR;
        }
        if (argJdbcDataType.equals("LONGNVARCHAR")) {
            return Types.LONGNVARCHAR;
        }
        if (argJdbcDataType.equals("DATE")) {
            return Types.DATE;
        }
        if (argJdbcDataType.equals("TIME")) {
            return Types.TIME;
        }
        if (argJdbcDataType.equals("TIMESTAMP")) {
            return Types.TIMESTAMP;
        }
        if (argJdbcDataType.equals("BINARY")) {
            return Types.BINARY;
        }
        if (argJdbcDataType.equals("VARBINARY")) {
            return Types.VARBINARY;
        }
        if (argJdbcDataType.equals("LONGVARBINARY")) {
            return Types.LONGVARBINARY;
        }
        if (argJdbcDataType.equals("NULL")) {
            return Types.NULL;
        }
        if (argJdbcDataType.equals("OTHER")) {
            return Types.OTHER;
        }
        if (argJdbcDataType.equals("JAVA_OBJECT")) {
            return Types.JAVA_OBJECT;
        }
        if (argJdbcDataType.equals("DISTINCT")) {
            return Types.DISTINCT;
        }
        if (argJdbcDataType.equals("STRUCT")) {
            return Types.STRUCT;
        }
        if (argJdbcDataType.equals("ARRAY")) {
            return Types.ARRAY;
        }
        if (argJdbcDataType.equals("BLOB")) {
            return Types.BLOB;
        }
        if (argJdbcDataType.equals("CLOB")) {
            return Types.CLOB;
        }
        if (argJdbcDataType.equals("REF")) {
            return Types.REF;
        }
        if (argJdbcDataType.equals("DATALINK")) {
            return Types.DATALINK;
        }
        if (argJdbcDataType.equals("ROWID")) {
            return Types.ROWID;
        }
        if (argJdbcDataType.equals("BOOLEAN")) {
            return Types.BOOLEAN;
        }

        // If it is not determined.
        return Integer.MIN_VALUE;
    }

    /**
     * Replaces JDBC nullable with a Java string.
     * 
     * If [java.sql.ResultSetMetaData.] is given forward, becomes a Java JDBC constant.
     * 
     * @param argJdbcDataType
     *            Data type on JDBC.
     * @return Java string name.
     */
    public final static String convertJdbcNullableToString(
            final int argJdbcDataType) {
        switch (argJdbcDataType) {
        case ResultSetMetaData.columnNoNulls:
            return "columnNoNulls";
        case ResultSetMetaData.columnNullable:
            return "columnNullable";
        case ResultSetMetaData.columnNullableUnknown:
            return "columnNullableUnknown";
        default:
            // If no match is found, returns a blank.
            return "";
        }
    }

    /**
     * Pulls the data type from the type name in the database.
     * 
     * In ORACLE, when you specify the size of a TIMESTAMP type, it becomes OTHER.
     * In this case, the type name is obtained from the name.
     * 
     * Only perform this if it is OTHER or indefinite.
     * 
     * @param columnStructure
     *            Column structure.
     * @return If true, the result of the pull was updated. If false, nothing has been done.
     */
    public static final boolean mapTypeName2DataType(
            final BlancoDbMetaDataColumnStructure columnStructure) {

        // Gets the type name in the database.
        String wrkTypeName = columnStructure.getTypeName().toUpperCase();

        // Cuts off the size specification by "()".
        int indexOfTrim = wrkTypeName.indexOf('(');
        if (indexOfTrim > 0) {
            wrkTypeName = wrkTypeName.substring(0, indexOfTrim);
        }

        // Performs type name lookup using the JDBC type name string.
        final int jdbcDataType = convertJdbcDataType2Int(wrkTypeName);
        if (jdbcDataType != Integer.MIN_VALUE) {
            // Treats the derived data type as positive.
            columnStructure.setDataType(jdbcDataType);
            return true;
        }

        return false;
    }
}
