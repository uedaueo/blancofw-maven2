/*
 * blanco Framework
 * Copyright (C) 2004-2006 IGA Tosiki
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 */
package blanco.dbmetadata;

import java.io.ByteArrayInputStream;
import java.io.CharArrayReader;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

import blanco.dbmetadata.valueobject.BlancoDbMetaDataColumnStructure;

/**
 * A utility to issue SQL to a database and get meta information.
 *
 * @author IGA Tosiki
 */
public class BlancoDbMetaDataSql {
    /**
     * Issues SQL to a database and gets meta information.
     *
     * Strict SQL statement checking is not performed. Only the axquisition of meta information is performed.
     *
     * @throws SQLException
     *             This occurs when there is a flaw in the SQL statement.
     */
    public static List<BlancoDbMetaDataColumnStructure> getResultSetMetaData(
            final Connection conn, final String argSql) throws SQLException {
        // In SQL Server 2005, if you did not execute stmt.executeQuery(), it did not even need to set the SQL input parameters.
        // And the meta information could be obtained without executing stmt.executeQuery().

        return getResultSetMetaData(conn, argSql, null);
    }

    /**
     * Issues a SQL to the database and gets meta information.
     *
     * Issues a SQL statement to get the result set. If argSqlInParameter is set to a value, it will also try out the SQL statement.
     *
     * @param conn
     *            Database connection.
     * @param argSql
     *            SQL statement.
     * @param argSqlInParameter
     *            SQL input parameter. If null is given, strict SQL checks will be skipped.
     * @throws SQLException
     *             This occurs when there is a flaw in the SQL statement.
     */
    public static List<BlancoDbMetaDataColumnStructure> getResultSetMetaData(
            final Connection conn, final String argSql,
            final List<BlancoDbMetaDataColumnStructure> argSqlInParameter)
            throws SQLException {
        final List<BlancoDbMetaDataColumnStructure> result = new ArrayList<BlancoDbMetaDataColumnStructure>();

        final PreparedStatement stmt = conn.prepareStatement(argSql);

        ResultSet resultSet = null;
        try {
            if (argSqlInParameter != null) {
                // System.out.println("Sets the SQL input parameters in the SQL statement and then executes it: ["
                // + argSql + "]");

                bindSqlInParameter(stmt, argSqlInParameter);

                resultSet = stmt.executeQuery();
                // SQL runtime exceptions will be thrown as is.
            }

            ResultSetMetaData resultSetMetaData = null;
            if (resultSet != null) {
                // If there is a result set, uses it.
                // This is because for some JDBC drivers, the path obtained from stmt without getting the result set is not available.
                resultSetMetaData = resultSet.getMetaData();
            } else {
                resultSetMetaData = stmt.getMetaData();
            }

            if (resultSetMetaData == null) {
                throw new IllegalArgumentException(
                        "Meta information acquisition: Failed to get the result set meta information. Changes the SQL execution option to iterator.");
            }

            final int columnCount = resultSetMetaData.getColumnCount();
            for (int indexColumn = 1; indexColumn <= columnCount; indexColumn++) {
                final BlancoDbMetaDataColumnStructure columnStructure = parseResultSetMetaData(
                        resultSetMetaData, indexColumn);
                result.add(columnStructure);
            }
        } finally {
            if (resultSet != null) {
                // Gets the result set metadata before closing.
                // Otherwise, it was not able to get metadata in Postgre 8.1.
                resultSet.close();
                resultSet = null;
            }
            stmt.close();
        }

        return result;
    }

    /**
     * Expands ResultSetMetaData information to a structure.
     *
     * @param resultSetMetaData
     * @param indexColumn
     * @return
     * @throws SQLException
     */
    private static BlancoDbMetaDataColumnStructure parseResultSetMetaData(
            final ResultSetMetaData resultSetMetaData, final int indexColumn)
            throws SQLException {
        final BlancoDbMetaDataColumnStructure columnStructure = new BlancoDbMetaDataColumnStructure();
        // Before 2012.01.06, it was getColumnName, but this has been changed to support MySQL 5.1.
        columnStructure.setName(resultSetMetaData.getColumnLabel(indexColumn));
        columnStructure.setDataType(resultSetMetaData
                .getColumnType(indexColumn));
        columnStructure.setTypeName(resultSetMetaData
                .getColumnTypeName(indexColumn));
        if (columnStructure.getDataType() == Types.OTHER) {
            BlancoDbMetaDataUtil.mapTypeName2DataType(columnStructure);
        }

        columnStructure.setDataTypeDisplayName(BlancoDbMetaDataUtil
                .convertJdbcDataTypeToString(columnStructure.getDataType()));
        columnStructure.setColumnSize(resultSetMetaData
                .getPrecision(indexColumn));
        columnStructure.setDecimalDigits(resultSetMetaData
                .getScale(indexColumn));
        columnStructure.setNullable(resultSetMetaData.isNullable(indexColumn));
        columnStructure.setNullableDisplayName(BlancoDbMetaDataUtil
                .convertJdbcNullableToString(columnStructure.getNullable()));

        // Items that can be obtained only when SQL is executed.
        columnStructure.setWritable(resultSetMetaData.isWritable(indexColumn));

        return columnStructure;
    }

    /**
     * Binds SQL input parameters.
     *
     * @param stmt
     * @param argSqlInParameter
     * @throws SQLException
     * @throws IllegalArgumentException
     *             This occurs when the SQL input parameter is invalid.
     */
    private static void bindSqlInParameter(final PreparedStatement stmt,
            final List<BlancoDbMetaDataColumnStructure> argSqlInParameter)
            throws SQLException {
        if (argSqlInParameter == null) {
            // If the parameter is null, it is assumed that there are no SQL input parameter to be bound.
            return;
        }

        // Sets the SQL input parameters.
        int indexInParameter = 1;
        for (BlancoDbMetaDataColumnStructure columnStructure : argSqlInParameter) {

//            System.out.println("DbMetaData: name = " + columnStructure.getName() + ", type = " + columnStructure.getDataType());

            switch (columnStructure.getDataType()) {
            case Types.BIT:
            case Types.BOOLEAN:
                stmt.setBoolean(indexInParameter++, false);
                break;
            case Types.TINYINT:
                stmt.setByte(indexInParameter++, (byte) 0x00);
                break;
            case Types.SMALLINT:
                stmt.setShort(indexInParameter++, (short) 0);
                break;
            case Types.INTEGER:
                stmt.setInt(indexInParameter++, 0);
                break;
            case Types.BIGINT:
                stmt.setLong(indexInParameter++, 0);
                break;
            case Types.REAL:
                stmt.setFloat(indexInParameter++, 0);
                break;
            case Types.FLOAT:
            case Types.DOUBLE:
                stmt.setDouble(indexInParameter++, 0);
                break;
            case Types.NUMERIC:
            case Types.DECIMAL:
            // Given as "0". This is a JDK 1.5 measure.
                stmt.setBigDecimal(indexInParameter++, new BigDecimal("0"));
                break;
            case Types.CHAR:
            case Types.VARCHAR:
            case Types.LONGVARCHAR:
            case Types.NCHAR:
            case Types.NVARCHAR:
            case Types.LONGNVARCHAR:
                // For uniqueidentifier in SQL Server 2005, it is best to give null.
                stmt.setString(indexInParameter++, null);
                break;
            case Types.DATE:
                // We tentatively make it work the same way as TIMESTAMP.
            case Types.TIME:
                // We tentatively make it work the same way as TIMESTAMP.
            case Types.TIMESTAMP:
                stmt.setTimestamp(indexInParameter++, new Timestamp(0));
                break;
            case Types.BINARY:
            case Types.VARBINARY:
            case Types.LONGVARBINARY:
            case Types.BLOB: {
                byte[] dummy = "0".getBytes();
                stmt.setBinaryStream(indexInParameter++,
                        new ByteArrayInputStream(dummy), dummy.length);
            }
                break;
            case Types.JAVA_OBJECT:
                stmt.setObject(indexInParameter++, new Object());
                break;
            case Types.CLOB: {
                char[] dummy = new char[1];
                dummy[0] = '0';
                stmt.setCharacterStream(indexInParameter++,
                        new CharArrayReader(dummy), dummy.length);
            }
                break;
            case Types.OTHER: // This is used as a flag to skip the process when ITEMONLY is specified in DynamicClause.
                break;
            case Types.DISTINCT:
            case Types.STRUCT:
            case Types.ARRAY:
            case Types.NULL:
            case Types.REF:
            case Types.DATALINK:
            case Types.ROWID:// For now, it maps to outside of the support.
            default:
                throw new IllegalArgumentException(
                        "BlancoDbMetaDataSql: Binding of SQL input parameter ["
                                + columnStructure.getName()
                                + "]("
                                + BlancoDbMetaDataUtil
                                        .convertJdbcDataTypeToString(columnStructure
                                                .getDataType())
                                + "): The type of SQL input parameter ("
                                + columnStructure.getDataType()
                                + "/"
                                + BlancoDbMetaDataUtil
                                        .convertJdbcDataTypeToString(columnStructure
                                                .getDataType()) + ") that cannot be processed was specified.");
            }
        }
    }
}
