/*
 * blanco Framework
 * Copyright (C) 2004-2006 IGA Tosiki
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 */
package blanco.dbmetadata;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

import blanco.commons.util.BlancoStringUtil;
import blanco.dbmetadata.valueobject.BlancoDbMetaDataColumnStructure;
import blanco.dbmetadata.valueobject.BlancoDbMetaDataKeyStructure;
import blanco.dbmetadata.valueobject.BlancoDbMetaDataTableStructure;

/**
 * A utility to obtain meta information from a database.
 * 
 * Contains processing related to tables.
 * 
 * @author IGA Tosiki
 */
public class BlancoDbMetaDataTable {
    private static final boolean IS_REPORT_COLUMN_NOT_FOUND = false;

    /**
     * Gets all tables in the database with information such as item, primary key, and so on.
     * 
     * @param conn
     *            Database connection.
     * @param argSchema
     *            Schema name. If it is not specified, null is given.
     * @param argTable
     *            Table name. If it is not specified, null is given.
     * @param argTypes
     *            A list of types to get. All if it is null. Specify as in new String[] { "TABLE" }.
     * @return A list of table information.
     * @throws SQLException
     */
    public static List<BlancoDbMetaDataTableStructure> getTablesWithColumns(
            final Connection conn, final String argSchema,
            final String argTable, final String[] argTypes) throws SQLException {
        final DatabaseMetaData metadata = conn.getMetaData();

        // Gets table information.
        final List<BlancoDbMetaDataTableStructure> listTables = BlancoDbMetaDataTable
                .getTables(metadata, argSchema, argTable, argTypes);

        boolean isImportedKeysAvailable = true;
        boolean isExportedKeysAvailable = true;
        boolean isCrossReferenceKeysAvailable = true;

        // Gets all meta information about the table.
        for (int indexTable = 0; indexTable < listTables.size(); indexTable++) {
            final BlancoDbMetaDataTableStructure tableStructure = listTables
                    .get(indexTable);

            tableStructure.setColumns(BlancoDbMetaDataTable.getColumns(
                    metadata, tableStructure.getCatalog(), argSchema,
                    tableStructure.getName()));

            tableStructure.setPrimaryKeys(BlancoDbMetaDataTable.getPrimaryKeys(
                    metadata, tableStructure.getCatalog(), argSchema,
                    tableStructure.getName()));

            try {
                tableStructure.setImportedKeys(BlancoDbMetaDataTable
                        .getImportedKeys(metadata, tableStructure.getCatalog(),
                                argSchema, tableStructure.getName()));
            } catch (SQLException ex) {
                if (isImportedKeysAvailable) {
                    isImportedKeysAvailable = false;
                    System.out.println("An exception occurred when getting import key:" + ex.toString());
                }
            }

            try {
                tableStructure.setExportedKeys(BlancoDbMetaDataTable
                        .getExportedKeys(metadata, tableStructure.getCatalog(),
                                argSchema, tableStructure.getName()));
            } catch (SQLException ex) {
                if (isExportedKeysAvailable) {
                    isExportedKeysAvailable = false;
                    System.out.println("An exception occurred when getting export key:" + ex.toString());
                }
            }

            try {
                tableStructure.setCrossReferenceKeys(BlancoDbMetaDataTable
                        .getCrossReference(metadata, tableStructure
                                .getCatalog(), argSchema, tableStructure
                                .getName(), null, null, null));
            } catch (SQLException ex) {
                if (isCrossReferenceKeysAvailable) {
                    isCrossReferenceKeysAvailable = false;
                    System.out.println("An exception occurred when getting cross-reference:" + ex.toString());
                }
            } catch (NullPointerException ex) {
            	// for MySQL JDBC Driver
                if (isCrossReferenceKeysAvailable) {
                    isCrossReferenceKeysAvailable = false;
                    System.out.println("An exception occurred when getting cross-reference:" + ex.toString());
                }
            }
        }

        return listTables;
    }

    private static String getStringSafety(final ResultSet resultSet,
            final String fieldName) {
        try {
            return resultSet.getString(fieldName);
        } catch (SQLException ex) {
            if (IS_REPORT_COLUMN_NOT_FOUND) {
                System.out.println("An exception occurred when getting a string from ResultSet:"
                        + ex.toString());
            }
            return null;
        }
    }

    /**
     * Gets table list information from database meta information.
     * 
     * Skips the process if the table name contains "$".
     * 
     * @param metadata
     *            Database metadata.
     * @param argSchema
     *            Schema name. If it is not specified, null is given.
     * @param argTable
     *            Table name. If it is not specified, null is given.
     * @param argTypes
     *            A list of types to get. All if it is null. Specify as in new String[] { "TABLE" }.
     * @return A list of table information.
     * @throws SQLException
     */
    public static List<BlancoDbMetaDataTableStructure> getTables(
            final DatabaseMetaData metadata, final String argSchema,
            final String argTable, final String[] argTypes) throws SQLException {
        final List<BlancoDbMetaDataTableStructure> result = new ArrayList<BlancoDbMetaDataTableStructure>();

        final ResultSet resultSet = metadata.getTables(null, argSchema,
                argTable, argTypes);
        try {
            for (; resultSet.next();) {
                final BlancoDbMetaDataTableStructure tableStructure = new BlancoDbMetaDataTableStructure();

                tableStructure.setName(resultSet.getString("TABLE_NAME"));

                // if (tableStructure.getName().toLowerCase().startsWith("sys"))
                // {
                // continue;
                // }

                // System.out.println("Processes a table [" + tableStructure.getName() + "].");

                tableStructure.setType(resultSet.getString("TABLE_TYPE"));

                tableStructure.setCatalog(getStringSafety(resultSet,
                        "TABLE_CAT"));
                tableStructure.setSchema(getStringSafety(resultSet,
                        "TABLE_SCHEM"));
                tableStructure
                        .setRemarks(getStringSafety(resultSet, "REMARKS"));

                if (BlancoStringUtil.null2Blank(tableStructure.getName())
                        .length() == 0) {
                    // Skips if there is no table name.
                    continue;
                }
                if (BlancoStringUtil.null2Blank(tableStructure.getType())
                        .length() == 0) {
                    // Skips if there is no table type.
                    continue;
                }
                if (tableStructure.getName().indexOf('$') >= 0) {
                    // Skips if the table name contains "$".
                    continue;
                }

                result.add(tableStructure);
            }
        } finally {
            resultSet.close();
        }

        return result;
    }

    /**
     * Gets the column list information of a table from the database meta information.
     * 
     * @param metadata
     *            Database metadata.
     * @param argCat
     *            Catalog name. If it is not specified, null is given.
     * @param argSchema
     *            Schema name. If it is not specified, null is given.
     * @param argTableName
     *            Table name. If it is not specified, null is given.
     * @return The list of items.
     * @throws SQLException
     */
    public static List<BlancoDbMetaDataColumnStructure> getColumns(
            final DatabaseMetaData metadata, final String argCat,
            final String argSchema, final String argTableName)
            throws SQLException {
        final List<BlancoDbMetaDataColumnStructure> result = new ArrayList<BlancoDbMetaDataColumnStructure>();

        final ResultSet resultSet = metadata.getColumns(argCat, argSchema,
                argTableName, null);
        try {
            for (; resultSet.next();) {
                final BlancoDbMetaDataColumnStructure columnStructure = new BlancoDbMetaDataColumnStructure();
                columnStructure.setName(resultSet.getString("COLUMN_NAME"));
                columnStructure.setDataType(resultSet.getShort("DATA_TYPE"));
                columnStructure.setTypeName(getStringSafety(resultSet,
                        "TYPE_NAME"));
                if (columnStructure.getDataType() == Types.OTHER) {
                    BlancoDbMetaDataUtil.mapTypeName2DataType(columnStructure);
                }

                columnStructure.setDataTypeDisplayName(BlancoDbMetaDataUtil
                        .convertJdbcDataTypeToString(columnStructure
                                .getDataType()));
                try {
                    columnStructure.setColumnSize(resultSet
                            .getInt("COLUMN_SIZE"));
                } catch (SQLException ex) {
                    if (IS_REPORT_COLUMN_NOT_FOUND) {
                        System.out.println("An exception occurred when getting an int from a ResultSet:"
                                + ex.toString());
                    }
                }
                columnStructure.setBufferLength(getStringSafety(resultSet,
                        "BUFFER_LENGTH"));
                try {
                    columnStructure.setDecimalDigits(resultSet
                            .getInt("DECIMAL_DIGITS"));
                } catch (SQLException ex) {
                    if (IS_REPORT_COLUMN_NOT_FOUND) {
                        System.out.println("An exception occurred when getting an int from a ResultSet:"
                                + ex.toString());
                    }
                }
                try {
                    columnStructure.setNumPrecRadix(resultSet
                            .getInt("NUM_PREC_RADIX"));
                } catch (SQLException ex) {
                    if (IS_REPORT_COLUMN_NOT_FOUND) {
                        System.out.println("An exception occurred when getting an int from a ResultSet:"
                                + ex.toString());
                    }
                }
                try {
                    columnStructure.setNullable(resultSet.getInt("NULLABLE"));
                    columnStructure.setNullableDisplayName(BlancoDbMetaDataUtil
                            .convertJdbcNullableToString(columnStructure
                                    .getNullable()));
                } catch (SQLException ex) {
                    if (IS_REPORT_COLUMN_NOT_FOUND) {
                        System.out.println("An exception occurred when getting an int from a ResultSet:"
                                + ex.toString());
                    }
                }

                columnStructure
                        .setRemarks(getStringSafety(resultSet, "REMARKS"));
                columnStructure.setColumnDef(getStringSafety(resultSet,
                        "COLUMN_DEF"));

                try {
                    columnStructure.setSqlDataType(resultSet
                            .getInt("SQL_DATA_TYPE"));
                } catch (SQLException ex) {
                    if (IS_REPORT_COLUMN_NOT_FOUND) {
                        System.out.println("An exception occurred when getting an int from a ResultSet:"
                                + ex.toString());
                    }
                }
                try {
                    columnStructure.setSqlDatetimeSub(resultSet
                            .getInt("SQL_DATETIME_SUB"));
                } catch (SQLException ex) {
                    if (IS_REPORT_COLUMN_NOT_FOUND) {
                        System.out.println("An exception occurred when getting an int from a ResultSet:"
                                + ex.toString());
                    }
                }
                try {
                    columnStructure.setCharOctetLength(resultSet
                            .getInt("CHAR_OCTET_LENGTH"));
                } catch (SQLException ex) {
                    if (IS_REPORT_COLUMN_NOT_FOUND) {
                        System.out.println("An exception occurred when getting an int from a ResultSet:"
                                + ex.toString());
                    }
                }
                try {
                    columnStructure.setOrdinalPosition(resultSet
                            .getInt("ORDINAL_POSITION"));
                } catch (SQLException ex) {
                    if (IS_REPORT_COLUMN_NOT_FOUND) {
                        System.out.println("An exception occurred when getting an int from a ResultSet:"
                                + ex.toString());
                    }
                }
                columnStructure.setIsNullable(getStringSafety(resultSet,
                        "IS_NULLABLE"));
                columnStructure.setScopeCatlog(getStringSafety(resultSet,
                        "SCOPE_CATLOG"));
                columnStructure.setScopeSchema(getStringSafety(resultSet,
                        "SCOPE_SCHEMA"));
                columnStructure.setScopeTable(getStringSafety(resultSet,
                        "SCOPE_TABLE"));
                try {
                    columnStructure.setSourceDataType(resultSet
                            .getShort("SOURCE_DATA_TYPE"));
                } catch (SQLException ex) {
                    if (IS_REPORT_COLUMN_NOT_FOUND) {
                        System.out.println("An exception occurred when getting an int from a ResultSet:"
                                + ex.toString());
                    }
                }

                result.add(columnStructure);
            }
        } finally {
            resultSet.close();
        }
        return result;
    }

    /**
     * Gets the primary key information of a table fomr the database meta information.
     * 
     * @param metadata
     *            Database metadata.
     * @param argCat
     *            Catalog name. If it is not specified, null is given.
     * @param argSchema
     *            Schema name. If it is not specified, null is given.
     * @param argTableName
     *            Table name. If it is not specified, null is given.
     * @return The list of primary keys.
     * @throws SQLException
     */
    public static List<BlancoDbMetaDataKeyStructure> getPrimaryKeys(
            final DatabaseMetaData metadata, final String argCat,
            final String argSchema, final String argTableName)
            throws SQLException {
        final List<BlancoDbMetaDataKeyStructure> result = new ArrayList<BlancoDbMetaDataKeyStructure>();

        final ResultSet resultSet = metadata.getPrimaryKeys(argCat, argSchema,
                argTableName);
        try {
            for (; resultSet.next();) {
                final BlancoDbMetaDataKeyStructure primaryKeyStructure = new BlancoDbMetaDataKeyStructure();

                primaryKeyStructure.setPkcolumnName(resultSet
                        .getString("COLUMN_NAME"));
                primaryKeyStructure.setKeySeq(resultSet.getShort("KEY_SEQ"));
                primaryKeyStructure.setPkName(getStringSafety(resultSet,
                        "PK_NAME"));

                result.add(primaryKeyStructure);
            }
        } finally {
            resultSet.close();
        }
        return result;
    }

    /**
     * Gets information about primary key columns that refer to foreign key columns in a table from database meta information.
     * 
     * @param metadata
     *            Database metadata.
     * @param argCat
     *            Catalog name. If it is not specified, null is given.
     * @param argSchema
     *            Schema name. If it is not specified, null is given.
     * @param argTableName
     *            Table name. If it is not specified, null is given.
     * @return The list of primary keys.
     * @throws SQLException
     */
    public static List<BlancoDbMetaDataKeyStructure> getImportedKeys(
            final DatabaseMetaData metadata, final String argCat,
            final String argSchema, final String argTableName)
            throws SQLException {
        final List<BlancoDbMetaDataKeyStructure> result = new ArrayList<BlancoDbMetaDataKeyStructure>();

        final ResultSet resultSet = metadata.getImportedKeys(argCat, argSchema,
                argTableName);
        try {
            for (; resultSet.next();) {
                final BlancoDbMetaDataKeyStructure importedKeyStructure = getKeyStructureFromResultSet(resultSet);
                result.add(importedKeyStructure);
            }
        } finally {
            resultSet.close();
        }
        return result;
    }

    /**
     * Gets information about primary key columns that refer to foreign key columns in a table from database meta information.
     * 
     * @param metadata
     *            Database metadata.
     * @param argCat
     *            Catalog name. If it is not specified, null is given.
     * @param argSchema
     *            Schema name. If it is not specified, null is given.
     * @param argTableName
     *            Table name. If it is not specified, null is given.
     * @return The list of primary key columns.
     * @throws SQLException
     */
    public static List<BlancoDbMetaDataKeyStructure> getExportedKeys(
            final DatabaseMetaData metadata, final String argCat,
            final String argSchema, final String argTableName)
            throws SQLException {
        final List<BlancoDbMetaDataKeyStructure> result = new ArrayList<BlancoDbMetaDataKeyStructure>();

        final ResultSet resultSet = metadata.getExportedKeys(argCat, argSchema,
                argTableName);
        try {
            for (; resultSet.next();) {
                final BlancoDbMetaDataKeyStructure exportedKeyStructure = getKeyStructureFromResultSet(resultSet);
                result.add(exportedKeyStructure);
            }
        } finally {
            resultSet.close();
        }
        return result;
    }

    /**
     * Gets information about foreign key columns of a table from the database meta information.
     * 
     * @param metadata
     *            Database metadata.
     * @param argPrimaryCat
     *            Catalog name. If it is not specified, null is given.
     * @param argPrimarySchema
     *            Schema name. If it is not specified, null is given.
     * @param argPrimaryTableName
     *            Table name. If it is not specified, null is given.
     * @param argForeignCat
     *            Catalog name. If it is not specified, null is given.
     * @param argForeignSchema
     *            Schema name. If it is not specified, null is given.
     * @param argForeignTableName
     *            Table name. If it is not specified, null is given.
     * @return The list of primary key columns.
     * @throws SQLException
     */
    public static List<BlancoDbMetaDataKeyStructure> getCrossReference(
            final DatabaseMetaData metadata, final String argPrimaryCat,
            final String argPrimarySchema, final String argPrimaryTableName,
            final String argForeignCat, final String argForeignSchema,
            final String argForeignTableName) throws SQLException {
        final List<BlancoDbMetaDataKeyStructure> result = new ArrayList<BlancoDbMetaDataKeyStructure>();

        final ResultSet resultSet = metadata.getCrossReference(argPrimaryCat,
                argPrimarySchema, argPrimaryTableName, argForeignCat,
                argForeignSchema, argForeignTableName);
        try {
            for (; resultSet.next();) {
                final BlancoDbMetaDataKeyStructure exportedKeyStructure = getKeyStructureFromResultSet(resultSet);
                result.add(exportedKeyStructure);
            }
        } finally {
            resultSet.close();
        }
        return result;
    }

    /**
     * Gets the key structure from ResultSet.
     * 
     * Since the ResultSet for getImportedKeys, getExportedKeys, and etc. is the same, this is made common.
     * 
     * @param resultSet
     * @return
     * @throws SQLException
     */
    private static BlancoDbMetaDataKeyStructure getKeyStructureFromResultSet(
            final ResultSet resultSet) throws SQLException {
        final BlancoDbMetaDataKeyStructure keyStructure = new BlancoDbMetaDataKeyStructure();

        keyStructure.setPktableCat(resultSet.getString("PKTABLE_CAT"));
        keyStructure.setPktableSchem(resultSet.getString("PKTABLE_SCHEM"));
        keyStructure.setPktableName(resultSet.getString("PKTABLE_NAME"));
        keyStructure.setPkcolumnName(resultSet.getString("PKCOLUMN_NAME"));
        keyStructure.setFktableCat(resultSet.getString("FKTABLE_CAT"));
        keyStructure.setFktableSchem(resultSet.getString("FKTABLE_SCHEM"));
        keyStructure.setFktableName(resultSet.getString("FKTABLE_NAME"));
        keyStructure.setFkcolumnName(resultSet.getString("FKCOLUMN_NAME"));
        keyStructure.setKeySeq(resultSet.getShort("KEY_SEQ"));

        try {
            keyStructure.setUpdateRule(resultSet.getShort("UPDATE_RULE"));
        } catch (SQLException ex) {
            if (IS_REPORT_COLUMN_NOT_FOUND) {
                System.out.println("An exception occurred when getting short from ResultSet:"
                        + ex.toString());
            }
        }
        try {
            keyStructure.setDeleteRule(resultSet.getShort("DELETE_RULE"));
        } catch (SQLException ex) {
            if (IS_REPORT_COLUMN_NOT_FOUND) {
                System.out.println("An exception occurred when getting short from ResultSet:"
                        + ex.toString());
            }
        }
        keyStructure.setFkName(getStringSafety(resultSet, "FK_NAME"));
        keyStructure.setPkName(getStringSafety(resultSet, "PK_NAME"));
        try {
            keyStructure.setDeferrability(resultSet.getShort("DEFERRABILITY"));
        } catch (SQLException ex) {
            if (IS_REPORT_COLUMN_NOT_FOUND) {
                System.out.println("An exception occurred when getting short from ResultSet:"
                        + ex.toString());
            }
        }

        return keyStructure;
    }
}
